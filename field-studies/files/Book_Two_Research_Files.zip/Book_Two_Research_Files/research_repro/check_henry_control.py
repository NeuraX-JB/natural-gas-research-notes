"""Rebuild the Chapter 12 calendar control from the two displayed source series.

EIA historical spot observations, source T12:
https://www.eia.gov/dnav/ng/hist/rngwhhdD.htm
FRED daily history, source T7:
https://fred.stlouisfed.org/data/DHHNGSP

The values are the November 2–17, 2026 observations available at preparation.
The index disagreement for the one-row shift is intentionally artificial.
"""

import csv
from datetime import date
from decimal import Decimal
from pathlib import Path


def main():
    path = Path(__file__).with_name("henry_control.csv")
    with path.open(encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source))
    dates = [date.fromisoformat(row["observation_date"]) for row in rows]
    if len(set(dates)) != len(rows) or dates != sorted(dates):
        raise ValueError("Dates must be unique and ordered.")
    if len(rows) < 2:
        raise ValueError("At least two observations are needed.")
    eia = [Decimal(row["eia_dollars_per_mmbtu"]) for row in rows]
    fred = [Decimal(row["fred_dollars_per_mmbtu"]) for row in rows]
    if any(not number.is_finite() for number in eia + fred):
        raise ValueError("Source prices must be finite.")
    for title, left, right in [
        ("Same observation date", eia, fred),
        ("EIA date versus previous published FRED observation", eia[1:], fred[:-1]),
    ]:
        gaps = [a - b for a, b in zip(left, right)]
        total_abs = sum(abs(delta) for delta in gaps)
        print(title)
        print(f"Matched pairs: {len(gaps)}")
        print(f"Exact matches: {gaps.count(0)}")
        print(f"Sum of signed differences: {sum(gaps):.2f} dollars per MMBtu")
        print(f"Mean absolute difference: {total_abs / len(gaps):.5f} dollars per MMBtu")
        print(f"Maximum absolute difference: {max(abs(delta) for delta in gaps):.2f} dollars per MMBtu")
        print(f"Absolute cash discrepancy at 20,000 MMBtu per pair: {20000 * total_abs:,.2f} dollars")
        print()


if __name__ == "__main__":
    main()
