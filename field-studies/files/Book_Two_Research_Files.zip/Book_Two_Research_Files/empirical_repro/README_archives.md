# Verify the panel against the FERC archives

Use FERC's July 2024 archive editions for the 2022 and 2023 reporting years. On the legacy download page, locate each calendar year and download the **Master** and **Page 3** files from the **Delimited Comma** rows. The equivalent **Delimited Tab** files use the same layout. The corresponding source links are also listed as E1 to E4 in the book. [FERC Form 552 legacy downloads](https://www.ferc.gov/form-no-552-download-data)

Keep the verifier next to the distributed `panel_transactions.csv` and `panel_entities.csv`. From that directory run this command with Python 3.8 or newer, substituting the paths to your four downloads. The command works as one line on Windows, macOS or Linux.

```
python verify_ferc_archives.py --master-2022 "master2022.txt" --page3-2022 "page3_2022.txt" --master-2023 "master2023.txt" --page3-2023 "page3_2023.txt"
```

The verifier checks the reporting year, the selected filing and detail identifiers, the respondent and entity names, the master timestamps, all fourteen purchase and sale quantities, and the publisher-reporting and threshold flags included in the companion data. It compares every matching affiliate row in the raw page 3 file, including the absence of matching detail. The 2022 check includes ten main filings plus the additional Tenaska Gas Storage sensitivity filing. The 2023 check includes ten. The program prints counts without disclosing source contact details. A mismatch returns a nonzero exit code.

These checks use the position of fields in the published legacy text format. A portal export with different field names or order requires its own documented mapping. A newer vintage could contain corrections. Preserve both downloads and identify the changed filings before interpreting different results. This verification establishes that the companion is a faithful selection from the supplied archives. Publisher acceptance of individual trades remains unobserved.

To recompute the published percentages after verification, run `python replicate_panel.py`.
