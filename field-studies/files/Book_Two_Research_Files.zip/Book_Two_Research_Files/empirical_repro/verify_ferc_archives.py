"""Verify the selected Form 552 panel against the July 2024 public text archives."""
import argparse
import csv
import io
import sys
from collections import Counter
from decimal import Decimal, InvalidOperation
from pathlib import Path


HERE = Path(__file__).resolve().parent

# Zero-based positions in the 2022/23 legacy master export, which differs
# from the display order on the form. The annual ID is field 0.
MASTER_VOLUMES = {
    "total_purchase": 40, "total_sale": 41,
    "fixed_purchase": 44, "fixed_sale": 45,
    "daily_index_purchase": 46, "daily_index_sale": 47,
    "monthly_fixed_purchase": 49, "monthly_fixed_sale": 51,
    "monthly_index_purchase": 48, "monthly_index_sale": 50,
    "physical_basis_purchase": 42, "physical_basis_sale": 43,
    "trigger_purchase": 38, "trigger_sale": 39,
}
MASTER_TEXT = {"respondent_name": 12, "portal_timestamp": 52}
ENTITY_TEXT = {
    "listed_entity": 2, "legacy_reporter": 3, "daily_reporter": 4,
    "monthly_reporter": 5, "participates_purchases": 7,
    "participates_sales": 8,
}


class VerificationError(Exception):
    pass


def text_key(value):
    return " ".join(value.split())


def public_id(value):
    if not value.isascii() or not value.isdigit():
        raise VerificationError("Invalid numeric filing or detail identifier.")
    return value


def numeric(value):
    try:
        number = Decimal(value)
    except (InvalidOperation, ValueError):
        raise VerificationError("Invalid numeric volume in a selected record.") from None
    if not number.is_finite() or number < 0:
        raise VerificationError("Nonfinite or negative selected volume.")
    return number


def load_text(path):
    raw = path.read_bytes()
    if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
        return raw.decode('utf-16')
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp1252')


def archive_records(path, width):
    text = load_text(path)
    # Find the separator immediately after the first quoted or bare numeric ID.
    for delimiter in (',', '\t'):
        reader = csv.reader(io.StringIO(text, newline=''), delimiter=delimiter)
        first = next(reader, None)
        if first and first[0].isdigit() and len(first) in (width, width + 1):
            break
    else:
        raise VerificationError("Unrecognized archive format. Use the 2022/23 legacy comma or tab text file.")
    rows = []
    seen = set()
    for row in csv.reader(io.StringIO(text, newline=''), delimiter=delimiter):
        if not row:
            continue
        if len(row) == width + 1 and row[-1] == '':
            row.pop()
        if len(row) != width:
            raise VerificationError("Unexpected column count in an archive record.")
        rid = public_id(row[0])
        if rid in seen:
            raise VerificationError(f"Repeated source identifier {rid}.")
        seen.add(rid)
        rows.append(row)
    return rows


def panel_records(path, keys, required):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        if len(set(fields)) != len(fields) or not required.issubset(fields):
            raise VerificationError("Missing or repeated companion CSV columns.")
        rows = {}
        for row in reader:
            if None in row or any(row[field] is None for field in required):
                raise VerificationError("Malformed companion CSV row.")
            key = tuple(public_id(row[field]) for field in keys)
            if key in rows:
                raise VerificationError("Duplicate companion key.")
            rows[key] = row
    return rows


def verify_year(year, master_path, entities_path, panel, panel_entities):
    selected = {rid: record for (period, rid), record in panel.items() if period == year}
    expected_count = {'2022': 11, '2023': 10}[year]
    if len(selected) != expected_count:
        raise VerificationError(f"{year} companion filing count differs from the study design.")

    source = archive_records(master_path, 54)
    if any(row[7] != year for row in source):
        raise VerificationError(f"{year} master was supplied for a different reporting year.")
    master = {row[0]: row for row in source}
    for rid, record in selected.items():
        if rid not in master:
            raise VerificationError(f"{year} missing master filing {rid}.")
        raw = master[rid]
        for field, column in MASTER_TEXT.items():
            if text_key(record[field]) != text_key(raw[column]):
                raise VerificationError(f"{year} filing {rid} differs on {field}.")
        for field, column in MASTER_VOLUMES.items():
            if numeric(record[field]) != numeric(raw[column]):
                raise VerificationError(f"{year} filing {rid} differs on {field}.")

    source_details = archive_records(entities_path, 9)
    expected = {(rid, eid): r for (y, rid, eid), r in panel_entities.items() if y == year}
    if any(rid not in selected for rid, eid in expected):
        raise VerificationError(f"{year} detail row points to an unselected companion filing.")
    observed = {}
    for row in source_details:
        rid = public_id(row[1])
        if rid in selected:
            observed[rid, row[0]] = row
    if set(expected) != set(observed):
        missing = len(expected.keys() - observed.keys())
        extra = len(observed.keys() - expected.keys())
        raise VerificationError(f"{year} selected detail-key mismatch. Missing {missing}, additional {extra}.")
    for (rid, eid), record in expected.items():
        for field, column in ENTITY_TEXT.items():
            if text_key(record[field]) != text_key(observed[rid, eid][column]):
                raise VerificationError(f"{year} filing {rid}, detail {eid} differs on {field}.")

    counts = Counter(record['scope'] for record in selected.values())
    if counts['panel'] != 10 or counts['sensitivity'] != expected_count - 10:
        raise VerificationError(f"{year} unexpected main or sensitivity panel size.")
    # A filing with no matching source detail has unknown publisher status.
    known = {rid for rid, eid in observed}
    print(f"{year}: verified {len(selected)} filing records, {len(selected) * len(MASTER_VOLUMES)} "
          f"volume values, {len(observed)} detail rows. No matched detail for {len(set(selected) - known)} filing(s).")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for year in ('2022', '2023'):
        parser.add_argument(f'--master-{year}', required=True, type=Path)
        parser.add_argument(f'--page3-{year}', required=True, type=Path)
    args = parser.parse_args()
    panel = panel_records(HERE / 'panel_transactions.csv', ('year', 'record_id'),
                          {'year', 'record_id', 'scope'} | set(MASTER_TEXT) | set(MASTER_VOLUMES))
    entities = panel_records(HERE / 'panel_entities.csv', ('year', 'record_id', 'detail_id'),
                             {'year', 'record_id', 'detail_id'} | set(ENTITY_TEXT))
    if {year for year, rid in panel} != {'2022', '2023'} or set(y for y, rid, eid in entities) - {'2022', '2023'}:
        raise VerificationError("Unexpected companion years.")
    for year in ('2022', '2023'):
        verify_year(year, getattr(args, 'master_' + year), getattr(args, 'page3_' + year), panel, entities)
    print("All selected records matched.")


if __name__ == '__main__':
    try:
        main()
    except (VerificationError, UnicodeError, csv.Error, OSError) as error:
        if isinstance(error, VerificationError):
            message = str(error)
        else:
            message = "Could not read a required input. Check its path, encoding and format."
        print("Verification failed. " + message, file=sys.stderr)
        sys.exit(1)
