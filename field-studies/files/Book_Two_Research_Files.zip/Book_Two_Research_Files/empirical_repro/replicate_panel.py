"""Chapters 7 and 8. Run with Python 3.8+ from any directory."""
import csv
from collections import defaultdict
from decimal import Decimal as D
from pathlib import Path
from statistics import median

HERE=Path(__file__).resolve().parent
SIDES=('purchase','sale')
MEASURES=('total','fixed','daily_index','monthly_fixed','monthly_index','physical_basis','trigger')


def read(name):
    with (HERE/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))


def transaction_rows():
    data=read('panel_transactions.csv')
    ids=set()
    for row in data:
        key=(row['year'],row['record_id'])
        if key in ids:
            raise ValueError('Duplicated year/record identifier')
        ids.add(key)
        for q in MEASURES:
            for side in SIDES:
                k=q+'_'+side
                row[k]=D(row[k])
                if not row[k].is_finite() or row[k]<0:
                    raise ValueError('Invalid volume')
    panel=[r for r in data if r['scope']=='panel']
    labels={r['label'] for r in panel}
    assert len(labels)==10 and len(panel)==20
    assert {(r['label'],r['year']) for r in panel}=={(l,y) for l in labels for y in ('2022','2023')}
    return data,panel


def summarize(rows,side):
    f=sum(r['fixed_'+side] for r in rows)
    i=sum(r['daily_index_'+side] for r in rows)
    a=sum(r['total_'+side] for r in rows)
    return f,i,100*i/(i+f),i/f,100*i/a


def status(entities,ref):
    rows=[r for r in entities if r['year']=='2023' and r['record_id']==ref]
    flags={r['daily_reporter'] for r in rows}
    if flags=={'True'}:return 'all yes'
    if flags=={'False'}:return 'all no'
    if flags=={'True','False'}:return 'mixed'
    return 'unresolved'


def stats():
    data,panel=transaction_rows()
    entities=read('panel_entities.csv')
    print('Fixed next-day / daily-index TBtu, daily-index share of two lines, index/fixed, indexed share of line 1')
    for year in ('2022','2023'):
        rs=[r for r in panel if r['year']==year]
        for side in SIDES:
            f,i,s,q,a=summarize(rs,side)
            print(year,side,f,i,f'{s:.3f}%',f'{q:.4f}x',f'{a:.2f}%')
        eight=[r for r in rs if r['label'] not in ('BP','Shell')]
        print('Without the BP and Shell filings:',*(f'{summarize(eight,s)[2]:.3f}%' for s in SIDES))
        for r in rs:
            scores=[summarize([r],side)[2] for side in SIDES]
            print(r['label'],*[f'{n:.2f}' for n in scores])
        for side in SIDES:
            sh=[summarize([r],side)[2] for r in rs]
            loo=[summarize([p for p in rs if p!=r],side)[2] for r in rs]
            print(side,'mean / median / leave-one-out range',*(f'{v:.3f}' for v in (sum(sh)/len(sh),median(sh),min(loo),max(loo))))
    print('Change among firms whose two daily-category shares are measured in both years')
    for side in SIDES:
        def group(y):return {r['label']:r for r in panel if r['year']==y}
        a,b=group('2022'),group('2023')
        A,B=[sum(r['fixed_'+side]+r['daily_index_'+side] for r in g.values()) for g in (a,b)]
        within=weights=D(0); increases=0
        for label,r in a.items():
            t=b[label]
            va=r['fixed_'+side]+r['daily_index_'+side]; vb=t['fixed_'+side]+t['daily_index_'+side]
            sa=r['daily_index_'+side]/va; sb=t['daily_index_'+side]/vb
            within+=(va/A+vb/B)*(sb-sa)/2
            weights+=(sa+sb)*(vb/B-va/A)/2
            increases+=int(sb>sa)
        print(side,f'within {100*within:.4f}, weights {100*weights:.4f}, total {100*(within+weights):.4f} points, {increases}/10 higher')
        rs=[r for r in data if r['year']=='2022']
        print('Tenaska perimeter sensitivity 2022',side,f'{summarize(rs,side)[2]:.3f}%')
    print('2023 page 3 daily flag. Classify each filing before totaling.')
    groups=defaultdict(list)
    for r in panel:
        if r['year']=='2023':groups[status(entities,r['record_id'])].append(r)
    for k,rs in groups.items():
        print(k,len(rs),', '.join(r['label'] for r in rs))
        print('fixed purchase/sale: ',*(sum(r['fixed_'+s] for r in rs) for s in SIDES))
    for side in SIDES:
        allrs=[r for r in panel if r['year']=='2023']
        total=sum(r['fixed_'+side] for r in allrs)
        n=sum(r['fixed_'+side] for r in groups['all yes'])
        m=sum(r['fixed_'+side] for r in groups['all no'])
        print(side,'uniform-yes to possible yes-company allocation:',f'{n:.1f}',f'{total-m:.1f}','of',total,f'({100*n/total:.2f}% to {100*(total-m)/total:.2f}%)')
    print('2023 line 1 minus sum of lines 2–7 (TBtu)')
    for r in panel:
        if r['year']=='2023':
            print(r['label'],*(r['total_'+s]-sum(r[q+'_'+s] for q in MEASURES if q!='total') for s in SIDES))


if __name__=='__main__':
    stats()
