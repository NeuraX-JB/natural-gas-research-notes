"""Reproduce the three book figures with Matplotlib and Python 3.8 or newer.

Run python draw_figures.py --out figures to create the three PNGs. The input
values are printed in the book and pinned below with their source-register IDs.
"""
import argparse
from decimal import Decimal
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter


NAVY = "#203E54"
GOLD = "#996009"
PALE = "#F9F8F4"
GRID = "#D7DAD8"
TEXT = "#24333A"

# Published prices in USD/MMBtu, October 6 trade for October 7 flow.
# Source register [A5] and [A6], Platts correction notices, October 7, 2026.
REVISIONS = [
    ("Florida Gas zone 1", 2.240, 2.740, NAVY, "o", "-"),
    ("ONEOK Oklahoma", 2.520, 2.460, GOLD, "D", "--"),
]

# Fixed next-day volume and daily-index volume, TBtu, summed across 10 filings.
# Source register [E1] [E2], inputs in panel_transactions.csv, scope == panel.
PANEL = [
    ("Purchases", 2022, "1899.8", "7357.8"),
    ("Purchases", 2023, "1877.8", "7910.6"),
    ("Sales", 2022, "2099.1", "8124.1"),
    ("Sales", 2023, "2033.5", "8416.8"),
]

# Published low, midpoint and high. [C10] Gas Daily, April 3, 2019, pp. 2, 19.
WAHA = [
    ("Platts Waha", -6.600, -3.755, -0.500, NAVY, "o"),
    ("ICE Waha, buyer’s choice", -5.000, -3.380, -1.500, GOLD, "D"),
]


def style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9, "axes.labelsize": 8.5,
        "text.color": TEXT, "axes.labelcolor": TEXT, "xtick.color": TEXT,
        "ytick.color": TEXT, "axes.facecolor": PALE, "figure.facecolor": PALE,
        "axes.edgecolor": GRID, "axes.spines.top": False, "axes.spines.right": False,
        "axes.spines.left": False, "xtick.major.size": 0, "ytick.major.size": 0,
        "svg.fonttype": "none",
    })


def save(fig, out, name, description):
    fig.savefig(out / (name + ".png"), dpi=320, facecolor=PALE,
                metadata={"Title": name, "Description": description})
    plt.close(fig)


def spread(out):
    fig, ax = plt.subplots(figsize=(3.75, 2.34))
    fig.subplots_adjust(left=.16, right=.96, top=.74, bottom=.17)
    for label, original, revised, color, marker, line in REVISIONS:
        ax.plot([0, 1], [original, revised], label=label, marker=marker,
                linestyle=line, lw=2.0, ms=5, color=color, zorder=3)
        for x, y in [(0, original), (1, revised)]:
            shift = 7 if (label.startswith("ONEOK") and x == 0) or (not label.startswith("ONEOK") and x == 1) else -12
            ax.annotate(f"{y:.3f}", (x, y), xytext=(0, shift), textcoords="offset points",
                        ha="center", color=color, weight="bold", fontsize=9)
    ax.set_xlim(-.15, 1.15)
    ax.set_ylim(2.05, 2.90)
    ax.set_yticks([2.20, 2.40, 2.60, 2.80])
    ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f"{y:.2f}"))
    ax.set_xticks([0, 1], ["First published", "Corrected"])
    ax.grid(axis="y", color=GRID, linewidth=.65)
    ax.set_axisbelow(True)
    fig.text(.054, .945, "Daily midpoint   ·   $/MMBtu", fontsize=9, weight="bold")
    ax.legend(loc="lower center", bbox_to_anchor=(.51, 1.04), ncol=2, frameon=False,
              fontsize=8.2, handlelength=1.6, columnspacing=1, borderaxespad=0)
    save(fig, out, "spread", "Florida Gas zone 1 rose from 2.240 to 2.740 dollars per MMBtu. ONEOK Oklahoma fell from 2.520 to 2.460.")


def panel(out):
    fig, ax = plt.subplots(figsize=(3.75, 2.40))
    fig.subplots_adjust(left=.22, right=.90, top=.83, bottom=.18)
    y_positions = [3.4, 2.5, 1.0, .1]
    for (side, year, fixed, indexed), y in zip(PANEL, y_positions):
        ratio = Decimal(100) * Decimal(indexed) / (Decimal(fixed) + Decimal(indexed))
        x = float(ratio)
        color = NAVY if year == 2022 else GOLD
        ax.barh(y, x, height=.55, color=color, zorder=2)
        ax.text(x + 1.8, y, f"{x:.2f}%", va="center", fontsize=8.4,
                color=color, weight="bold")
    ax.set_yticks(y_positions, ["2022", "2023", "2022", "2023"], fontsize=8)
    ax.set_xticks([0, 25, 50, 75, 100], ["0", "25", "50", "75", "100%"], fontsize=8)
    ax.set_xlim(0, 100)
    ax.set_ylim(-.68, 4.0)
    for y, label in [(3.85, "Purchases"), (1.48, "Sales")]:
        ax.text(-.28, y, label, transform=ax.get_yaxis_transform(), fontweight="bold",
                fontsize=8.5, va="bottom")
    ax.grid(axis="x", color=GRID, linewidth=.65)
    ax.set_axisbelow(True)
    fig.text(.05, .945, "Daily-index share of the two categories", fontsize=9, weight="bold")
    save(fig, out, "panel", "Daily-index quantities as a share of daily-index plus fixed next-day quantities. Purchases 79.48% and 80.82%, sales 79.47% and 80.54%, in 2022 and 2023 respectively.")


def waha(out):
    fig, ax = plt.subplots(figsize=(3.75, 2.18))
    fig.subplots_adjust(left=.075, right=.955, top=.82, bottom=.28)
    for (label, low, middle, high, color, marker), y in zip(WAHA, [1, 0]):
        ax.hlines(y, low, high, color=color, lw=1.8)
        ax.vlines([low, high], y-.075, y+.075, color=color, lw=1.5)
        ax.scatter([middle], [y], color=color, marker=marker, s=29, zorder=3)
        ax.text(middle, y-.16, f"−{abs(middle):.3f}", ha="center", va="top",
                fontsize=8.5, fontweight="bold", color=color)
        ax.text(-6.8, y+.21, label, fontsize=8.5, ha="left", va="bottom", fontweight="bold")
    ax.set_xlim(-6.9, .25)
    ax.set_ylim(-.55, 1.55)
    ax.set_yticks([])
    ax.set_xticks([-6, -4, -2, 0], ["−6", "−4", "−2", "0"])
    ax.set_xlabel("Dollars per MMBtu", labelpad=5)
    ax.grid(axis="x", color=GRID, linewidth=.65)
    ax.set_axisbelow(True)
    fig.text(.06, .945, "Accepted price range and published midpoint", fontsize=9, weight="bold")
    save(fig, out, "waha", "Platts Waha ranged from minus 6.60 to minus 0.50 with midpoint minus 3.755. ICE Waha buyer’s choice ranged from minus 5.00 to minus 1.50 with midpoint minus 3.380.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path.cwd())
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    style()
    spread(args.out)
    panel(args.out)
    waha(args.out)
