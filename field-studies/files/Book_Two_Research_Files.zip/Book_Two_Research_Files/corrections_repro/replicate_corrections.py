"""Reproduce Chapter 13 from selected public Platts correction notices. Python 3.8+."""
from csv import DictReader
from datetime import date
from decimal import Decimal
from pathlib import Path
from statistics import mean, median

BASE = Path(__file__).resolve().parent
EXPECTED = {"texas", "pngts", "south", "city", "florida", "oklahoma", "northern"}


def load():
    records = {}
    with (BASE / "notice_sample.csv").open(encoding="utf-8", newline="") as file:
        for row in DictReader(file):
            key = row["record"]
            if key in records:
                raise ValueError(f"Duplicate location-event {key}")
            for k in ("midpoint_before", "midpoint_after"):
                row[k] = Decimal(row[k])
            for k in ("flow_start", "flow_end", "notice_date", "trade_date"):
                row[k] = date.fromisoformat(row[k])
            if not row["trade_date"] <= row["flow_start"] <= row["flow_end"]:
                raise ValueError(f"Invalid delivery dates at {key}")
            if row["notice_date"] < row["trade_date"]:
                raise ValueError(f"Invalid notice date at {key}")
            row["revision"] = row["midpoint_after"] - row["midpoint_before"]
            records[key] = row
    if set(records) != EXPECTED:
        raise ValueError("Unexpected event set.")
    return records


def main():
    records = load()
    print("Location, revision (USD/MMBtu), % of original price, covered flow days, calendar days from trade to notice")
    for row in records.values():
        days = (row["flow_end"] - row["flow_start"]).days + 1
        lag = (row["notice_date"] - row["trade_date"]).days
        percentage = 100 * row["revision"] / row["midpoint_before"]
        print(f'{row["location"]}: {row["revision"]:+.3f}, {percentage:+.2f}%, {days}, {lag}')
    absolute = [abs(row["revision"]) for row in records.values()]
    print(f'Median absolute {median(absolute):.3f}, mean {mean(absolute):.3f}')
    print(f'Share of total absolute change from largest: {100*max(absolute)/sum(absolute):.2f}%')
    oneok, fgt_zone1 = records["oklahoma"], records["florida"]
    if (oneok["trade_date"], oneok["flow_start"], oneok["flow_end"]) != (fgt_zone1["trade_date"], fgt_zone1["flow_start"], fgt_zone1["flow_end"]):
        raise ValueError("The paired comparison needs matched dates")
    basis = []
    for vintage in ("before", "after"):
        k = f"midpoint_{vintage}"
        basis.append(fgt_zone1[k] - oneok[k])
    print(f'Florida Gas zone 1 minus ONEOK Oklahoma: {basis[0]:+.3f} -> {basis[1]:+.3f}, change {basis[1]-basis[0]:+.3f} USD/MMBtu')
    for k in ("texas", "pngts", "city"):
        row = records[k]
        old_v = Decimal(row["volume_before_1000mmbtu_per_day"])
        new_v = Decimal(row["volume_after_1000mmbtu_per_day"])
        # Price times printed volume is in thousands of USD per flow day.
        # The scale cancels when we divide the difference by its volume difference.
        implied = (old_v*row["midpoint_before"] - new_v*row["midpoint_after"]) / (old_v-new_v)
        margin = Decimal(".0025")*(old_v+new_v)/abs(old_v-new_v)
        print(f'{k}: conditional implied price {implied:.4f}; price-rounding sensitivity +/-{margin:.4f} at fixed printed volumes')
    # The February trade covered only March 1 and 2. A generic three-day
    # weekend rule would add a fictitious February day.
    south = records["south"]
    south_days = (south["flow_end"] - south["flow_start"]).days + 1
    south_daily_adjustment = 5000 * south["revision"]
    print(f'El Paso South Mainline: {south_days} March flow days, correction on 5,000 MMBtu/day '
          f'{south_days * south_daily_adjustment:,.2f} USD. An extra February day would add '
          f'{south_daily_adjustment:,.2f} USD.')
    r = records['city']
    q = 10000 * ((r['flow_end']-r['flow_start']).days+1)
    print(f'Hypothetical 10,000 MMBtu each flow day, May package: {q:,} MMBtu, difference {q*r["revision"]:,.2f} USD')


if __name__ == "__main__":
    main()
