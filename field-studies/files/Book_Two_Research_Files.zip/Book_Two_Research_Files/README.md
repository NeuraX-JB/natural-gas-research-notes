# Who Sets the Price of Gas?

## Research files for Book Two

These files reproduce the book's Form 552 panel, Henry Hub date-alignment check, selected price corrections and three figures. Unzip the package and open a terminal in the directory containing this README. The three numerical studies run offline with Python 3.8 or newer and use the files beside each script. On Windows, use `py` if that is your Python launcher. On macOS and Linux, use `python3` if that is the installed command.

```sh
python empirical_repro/replicate_panel.py
python research_repro/check_henry_control.py
python corrections_repro/replicate_corrections.py
```

**Form 552, Chapters 7–8.** The matched panel contains ten named respondents for each of the 2022 and 2023 reporting years. The twenty main annual filing rows and one extra 2022 Tenaska Gas Storage row appear in `empirical_repro/panel_transactions.csv`. The extra row is marked for a sensitivity calculation. The companion `panel_entities.csv` contains 44 linked Page 3 rows, including 2022 records under that year's reporting convention. A blank field remains unobserved. Filing identifiers, affiliate coverage and the relevant year's form definitions matter when comparing reporting flags. Transaction quantities are in TBtu, or trillion British thermal units. Purchases and sales are separate sides. Each daily-index share uses daily-index volume divided by the sum of daily-index and next-day fixed-price volume, calculated separately by side. The main 2023 calculation gives 80.816% for purchases and 80.541% for sales. These ten respondents cannot establish a national market share, hub-level liquidity or which individual trades a publisher accepted.

**Archive verification.** To check all 294 volume entries and the Page 3 matches against FERC's files, download the four official 2022–2023 legacy archives listed under E1–E4, then follow `empirical_repro/README_archives.md`. The verifier supports the original comma- or tab-delimited layouts and runs offline once you have the four inputs.

**Calendar control, Chapter 12.** `research_repro/henry_control.csv` contains 12 EIA and FRED historical Henry Hub spot observations from November 2–17, 2026 in USD/MMBtu. The two releases share an underlying series. All twelve matched-date pairs agree. Shifting one series back by one published observation intentionally introduces a mean absolute difference of $0.08545/MMBtu across eleven pairs. This checks the effects of misalignment using a common series. It cannot test price discovery by independent publishers. See T7 and T12.

**Price revisions, Chapter 13.** `corrections_repro/notice_sample.csv` contains seven selected location-events from public Platts correction notices, each keyed to the source register. Prices are USD/MMBtu and reported quantities, where available, are in thousands of MMBtu per day. Empty volume and count cells mean that this sample has no value for those fields. On the common October 6 trade date, Florida Gas zone 1 minus ONEOK Oklahoma changed from −$0.280 to +$0.280/MMBtu between versions. One record is one location-event, even when its delivery package covers several days. The selected notices provide no denominator for estimating correction frequency in the broader market. Printed volumes and rounded prices limit inferences about individual trades.

**Figures.** To draw the three PNGs, install Matplotlib 3.5 or newer into the Python environment you use for this project and run the two commands below. Matplotlib is needed only for the figures. You may omit the installation step if Matplotlib is already available. The figure script includes the plotted inputs and their source codes. The figures cover the Florida–Oklahoma price spread, Form 552 daily-index shares, and the Waha price range.

```sh
python -m pip install "matplotlib>=3.5"
python figure_repro/draw_figures.py --out figures
```

**Source register.** Open `source_register.tsv` in a text editor or spreadsheet using tab as the field separator. Each record gives a book citation code, chapter group, title and public URL. Repeat URLs can support different cited definitions, pages or calculations. This research snapshot was prepared November 24, 2026. A later release of a public file may differ from the vintage named in the book.
