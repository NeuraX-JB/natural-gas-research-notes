from pathlib import Path
import sys
import numpy as np
import pandas as pd
def main(R):
 K=Path(__file__).resolve().parent;b=pd.read_csv(K/'bpa_days.csv.gz')
 b=b[(b.rows==288)&(b.min_core_readings==288)].copy();b['solar']=b.solar.fillna(0)
 b['gen']=b[['water','thermal','nuclear','wind','solar']].sum(axis=1)
 b['error']=b.load-b.gen+b.export;b.to_csv(R/'operator_clean_days.csv',index=False)
 d=pd.read_csv(R/'grid_days.csv').query("ba=='BPAT' and good").merge(b,on='day',suffixes=('_eia','_bpa'))
 cols=['water','load','gen','export','error'];a=[]
 for y,z in d.groupby('year'):
  for c in cols:
   delta=z[c+'_bpa']-z[c+'_eia'];a.append([y,c,len(z),z[c+'_bpa'].mean(),z[c+'_eia'].mean(),delta.mean(),delta.abs().mean(),z[c+'_bpa'].corr(z[c+'_eia'])])
 pd.DataFrame(a,columns=['year','variable','days','operator_mean','eia_mean','mean_difference','mean_absolute_difference','correlation']).to_csv(R/'operator_vs_eia.csv',index=False)
 p=pd.read_csv(R/'day_pairs.csv').query("ba=='BPAT' and load_tolerance==.03");bd=b.set_index('day');res=[]
 for row in p.itertuples():
  if row.lower_water_date not in bd.index or row.higher_water_date not in bd.index:continue
  dl=bd.loc[row.lower_water_date]-bd.loc[row.higher_water_date]
  res.append([row.year,row.lower_water_date,row.higher_water_date,row.water,row.ng,row.export,row.error]+[dl[c] for c in ['water','thermal','export','load','nuclear','wind','solar','error']])
 pd.DataFrame(res,columns=['year','low_day','high_day','eia_water','eia_gas','eia_export','eia_error','op_water','op_thermal','op_export','op_load','op_nuclear','op_wind','op_solar','op_error']).to_csv(R/'operator_pairs.csv',index=False)
 # Compare closest one, two and three earlier forecasts and sensitivity to removal of a test year.
 f=pd.read_csv(K/'forecast.csv');m=pd.read_csv(R/'monthly.csv');targets=m.query("scope=='NW3' and 5<=month<=8").groupby('year')[['hydro','gas','burn']].sum();v=[]
 for issue in (1,3,4):
  z=f[f.issue_month==issue].set_index('year').join(targets)
  for y in range(2018,2026):
   train=z[z.index<y];nearest=(train.median_kaf-z.loc[y].median_kaf).abs().sort_values(kind='stable')
   for k in (1,2,3):
    for target in ('hydro','gas','burn'):
     actual=z.loc[y,target];pred=train.loc[nearest.index[:k],target].mean();base=train[target].tail(5).mean();v.append([issue,y,k,target,actual,pred,abs(pred-actual),abs(base-actual)])
 pd.DataFrame(v,columns=['issue','year','neighbors','target','actual','estimate','absolute_error','baseline_error']).to_csv(R/'neighbor_sensitivity.csv',index=False)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'results')
