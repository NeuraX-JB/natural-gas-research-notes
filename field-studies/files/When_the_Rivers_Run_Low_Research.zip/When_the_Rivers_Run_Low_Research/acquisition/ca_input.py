from lxml import html
import pandas as pd,re
s=html.parse('raw/water_history.html').getroot().text_content();rows=[]
for l in s.splitlines():
 t=l.split()
 if len(t)==11 and re.fullmatch(r'\d{4}',t[0]) and t[5] in ('W','AN','BN','D','C') and t[10] in ('W','AN','BN','D','C') and int(t[0])>=1990:rows.append(t)
r=pd.DataFrame(rows,columns=['year','sac_oct_mar','sac_apr_jul','sac_wy','sac_index','sac_class','sj_oct_mar','sj_apr_jul','sj_wy','sj_index','sj_class'])
assert len(r)==36 and r.year.is_unique;r.to_csv('kit/runoff.csv',index=False)
