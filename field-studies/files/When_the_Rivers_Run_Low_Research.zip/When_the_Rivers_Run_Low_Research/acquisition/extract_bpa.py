import pandas as pd, numpy as np
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
cols={'load':'TOTAL BPA CONTROL AREA LOAD','water':'TOTAL HYDRO GENERATION','thermal':'TOTAL FOSSIL/BIOMASS GENERATION','nuclear':'TOTAL NUCLEAR GENERATION','wind':'TOTAL WIND GENERATION','solar':'TOTAL SOLAR GENERATION','export':'NET INTERCHANGE'}
def parse(y):
 p=next(Path('raw').glob(f'bpa_{y}.xl*'));x=pd.ExcelFile(p);out=[]
 for sh in x.sheet_names:
  if sh.lower()=='details':continue
  d=pd.read_excel(x,sheet_name=sh,header=None);head=d.index[d.iloc[:,0].astype(str).str.strip()=='Date/Time'][0];d.columns=[str(c).upper().strip() for c in d.loc[head]];d=d.iloc[head+1:]
  dates=pd.to_datetime(d.iloc[:,0],format='%m/%d/%y %H:%M',errors='coerce');a=pd.DataFrame({'day':dates.dt.normalize()})
  for k,s in cols.items():
   cs=[c for c in d if c.startswith(s) and ('FORECAST' not in c) and ('BASEPOINT' not in c)];a[k]=pd.to_numeric(d[cs[0]],errors='coerce') if cs else np.nan
  a=a[a.day.dt.year.eq(y)];out.append(a)
 v=pd.concat(out);g=v.groupby('day');m=g[list(cols)].mean();m['rows']=g.size();m['min_core_readings']=g[['load','water','thermal','nuclear','wind','export']].count().min(axis=1)
 print(y,len(v),len(m),flush=True);return m.reset_index()
if __name__=='__main__':
 with ProcessPoolExecutor(3) as pool:data=list(pool.map(parse,range(2019,2026)))
 pd.concat(data).to_csv('kit/bpa_days.csv.gz',index=False)
