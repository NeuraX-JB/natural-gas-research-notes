from pathlib import Path
from openpyxl import load_workbook
from collections import Counter
import pandas as pd
R=Path('raw'); K=Path('kit')
for name in ['generation_monthly','consumption_monthly','annual_generation_state','annual_consumption_state']:
 data=[];annual='annual' in name;w=load_workbook(R/(name+'.xlsx'),read_only=True,data_only=True)
 for sh in w:
  if 'prelim' in sh.title.lower() or 'notes' in sh.title.lower():continue
  for row in sh.values:
   if not isinstance(row[0],(int,float)):continue
   if annual:y,st,sect,fuel,val=row[:5];m=0
   else:y,m,st,sect,fuel,val=row[:6]
   if sect!='Total Electric Power Industry' or y>2025:continue
   if 'consumption' in name and not str(fuel).lower().startswith('natural gas'):continue
   data.append([int(y),int(m),st,str(fuel).strip(),val])
 df=pd.DataFrame(data,columns=['year','month','state','source','value']); print(name,len(df),df.source.unique(),df.state.unique(),flush=True)
 df.to_csv(K/(name+'.csv.gz'),index=False)
