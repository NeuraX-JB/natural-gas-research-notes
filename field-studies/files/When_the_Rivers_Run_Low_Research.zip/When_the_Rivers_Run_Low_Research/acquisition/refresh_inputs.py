"""Optional, heavy upstream refresh. Run in a new empty working directory."""
from pathlib import Path
import shutil, subprocess,sys
import pandas as pd
from urllib.request import Request,urlopen
HERE=Path(__file__).resolve().parent
def main():
 work=Path.cwd()
 if any(work.iterdir()):raise SystemExit('Choose a new empty working directory. This refresh creates raw/ and kit/ there.')
 (work/'kit').mkdir()
 for f in HERE.glob('*.py'):
  if f.name!='refresh_inputs.py':shutil.copy2(f,work/f.name)
 def run(s):subprocess.run([sys.executable,str(work/s)],cwd=work,check=True)
 for script in ('acquire.py','waterget.py','bpaget.py'):run(script)
 with urlopen(Request('https://cdec.water.ca.gov/reportapp/javareports?name=WSIHIST',headers={'User-Agent':'Western water research archive'}),timeout=90) as r:(work/'raw'/'water_history.html').write_bytes(r.read())
 for script in ('extract_state.py','extract_more.py','extract_bpa.py','ca_input.py'):run(script)
 print('Refreshed normalized inputs are in',work/'kit')
if __name__=='__main__':main()
