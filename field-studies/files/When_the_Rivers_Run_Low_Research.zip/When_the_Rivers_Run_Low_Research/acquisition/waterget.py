from acquire import *
def main():
 ce='https://www.energy.ca.gov/sites/default/files/2026-10/Total_System_Electric_Generation_2009-2025_with_totals_ada.xlsx'
 tasks=[('cec.xlsx',ce)]
 ls=links(U)
 for t,url in ls:
  if t in ('JAN','MAR','APR') and any(f'WY{str(y)[-2:]}' in url for y in range(2012,2026)):
   tasks.append((url.split('/')[-1],url))
 pd.DataFrame(tasks,columns=['file','url']).to_csv(R/'water_sources.csv',index=False)
 with ThreadPoolExecutor(8) as ex:list(ex.map(run,tasks))
if __name__=='__main__':main()
