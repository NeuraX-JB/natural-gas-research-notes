from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
import urllib.parse as up,hashlib,io,re,time
from lxml import html
import pandas as pd
BASE=Path(__file__).resolve().parent
R=BASE/'raw'; R.mkdir(exist_ok=True)
B='https://www.eia.gov/electricity/data/state/'
U='https://public.crohms.org/tmt/documents/WSF/Past-WY/index.html'
def get(url):
 for i in range(3):
  try:
   return urlopen(Request(url,headers={'User-Agent':'Natural gas hydrology research study'}),timeout=60).read()
  except Exception:
   if i==2:raise
   time.sleep(1+i)
def save(name,url):
 dest=R/name
 if not dest.exists():dest.write_bytes(get(url))
 print(name,dest.stat().st_size,flush=True)
 return dest.read_bytes()
def links(url):
 return [(a.text_content().strip(),up.urljoin(url,a.get('href'))) for a in html.fromstring(get(url)).xpath('//a[@href]')]
def run(t):
 try:
  if t[0]=='grid':
   y,p=t[1:];u=f'https://www.eia.gov/electricity/gridmonitor/sixMonthFiles/EIA930_BALANCE_{y}_{p}.csv';name=f'grid_{y}_{p}'
   if (R/(name+'.csv.gz')).exists():return
   b=get(u);w=pd.read_csv(io.BytesIO(b),encoding='cp1252',low_memory=False);w[w.iloc[:,0].isin(['CISO','BPAT'])].to_csv(R/(name+'.csv.gz'),index=False)
   (R/(name+'.sha')).write_text(hashlib.sha256(b).hexdigest()+'  '+u);print(name,flush=True)
  else:save(*t)
 except Exception as e:print('ERROR',t,repr(e),flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(6) as pool:
  list(pool.map(run,[(n+'.xlsx',B+n+'.xlsx') for n in ['generation_monthly','consumption_monthly','annual_generation_state','annual_consumption_state']]+[('grid',y,p) for y in range(2019,2026) for p in ('Jan_Jun','Jul_Dec')]))
