from acquire import *
u='https://transmission.bpa.gov/Business/Operations/Wind/default.aspx'
v=links(u);tasks=[]
for y in range(2019,2026):
 url=next(b for a,b in v if a==str(y));print(url,flush=True);tasks.append((f'bpa_{y}.'+url.split('.')[-1].lower(),url))
pd.DataFrame(tasks,columns=['file','url']).to_csv(R/'bpa_sources.csv',index=False)
with ThreadPoolExecutor(5) as ex:list(ex.map(run,tasks))
