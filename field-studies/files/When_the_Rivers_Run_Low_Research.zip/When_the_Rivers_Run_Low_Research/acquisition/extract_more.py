from pathlib import Path
import pandas as pd, re,subprocess
from openpyxl import load_workbook
R=Path('raw');K=Path('kit')
w=pd.read_excel(R/'cec.xlsx',header=1)

w=w[w.iloc[:,0].isin(['California','Northwest Imports','Southwest Imports','Northwest','Southwest'])].melt(id_vars=['Region','Fuel Type'],var_name='year',value_name='GWh')
w=w[pd.to_numeric(w.year,errors='coerce').between(2009,2025)].copy();w['year']=w.year.astype(int);w.to_csv(K/'cec.csv',index=False)
out=[]
for p in sorted(R.glob('grid*.csv.gz')):
 d=pd.read_csv(p,low_memory=False); raw={'ba':'Balancing Authority','day':'Data Date','hour':'Hour Number','utc_end':'UTC Time at End of Hour','load':'Demand (MW) (Adjusted)','gen':'Net Generation (MW) (Adjusted)','export':'Total Interchange (MW) (Adjusted)','ng':'Net Generation (MW) from Natural Gas (Adjusted)'}
 f=pd.DataFrame({k:d[c] for k,c in raw.items()})
 hydro=[i for i in d if 'from Hydropower' in i and i.endswith('(Adjusted)')];pump=[i for i in d if 'from Pumped Storage' in i and i.endswith('(Adjusted)')]
 assert len(hydro)==1
 f['hydro']=d[hydro[0]];f['pump']=d[pump[0]] if pump else float('nan');f['split']=int(bool(pump))
 f['water']=d[hydro+pump].sum(axis=1,min_count=1);f['day']=pd.to_datetime(f.day).dt.strftime('%Y-%m-%d');f['utc_end']=pd.to_datetime(f.utc_end,format='%m/%d/%Y %I:%M:%S %p').dt.strftime('%Y-%m-%dT%H:%M')
 out.append(f)
pd.concat(out).to_csv(K/'hourly.csv.gz',index=False)
fore=[]
for p in sorted(R.glob('WSF*.pdf')):
 t=subprocess.check_output(['pdftotext','-layout',str(p),'-']).decode().replace(chr(173),'-');y,m=map(int,re.search(r'WY(\d\d)_(\d\d)',p.name).groups())
 pages=[(i,s) for i,s in enumerate(t.split('\f'),1) if re.search('COLUMBIA.{0,8}THE DALLES|Water Supply Forecast - THE DALLES',s,re.I) and re.search('^\s*APR-AUG\s+\d+',s,re.M|re.I)]
 if not pages: print('NO PAGE',p.name);continue
 page,s=pages[0]; rows=re.findall(r'^\s*APR-AUG\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)',s,re.I|re.M); match=re.search('(?:10 [Dd]ays (?:of )?QPF|10 [Dd]ays of QPF|10 [Dd]ays QPF)',s,re.I)
 if not rows or not match:print('NO 10?',p.name,[l.strip() for l in s.splitlines() if 'qpf' in l.lower()][:3]);continue
 if not re.search('10 [Dd]ays (?:of )?QPF',s[:re.search(r'^\s*APR-AUG\s+\d+',s,re.M|re.I).start()],re.I):
  print('check placement',p.name)
 a,b,c,d,e=map(int,rows[0]);assert a<=b<=d and abs(b/e*100-c)<1
 fore.append((2000+y,m,page,a,b,c,d,e,p.name))
assert len(fore)==42, 'Expected exactly 42 eligible forecast packets'
pd.DataFrame(fore,columns=['year','issue_month','pdf_page','lower_kaf','median_kaf','percent_normal','upper_kaf','normal_kaf','file']).to_csv(K/'forecast.csv',index=False)
print('Forecasts',len(fore))
