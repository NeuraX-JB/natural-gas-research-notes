# When the Rivers Run Low

Research companion to Natural Gas Field Studies, volume 7. The study uses final calendar years through 2025. Run the replay first, then open the table for the chapter that interests you. The precomputed CSV files open directly in a spreadsheet.

## Replay from the frozen extracts

Python 3.12, pandas 2.2.3 and NumPy 2.x were used to prepare the study. Unzip the entire archive into one directory. From the directory containing this README, run the following commands.

```bash
python -m pip install -r requirements.txt
python replay.py
```

The program verifies the nine input hashes, writes a new directory named `replayed` and compares all 28 tables against the reference CSVs. To choose a different output directory, run `python replay.py --out my_results`. Annual and monthly input files contain federal source labels and original units. Most derived energy figures are in TWh, gas volumes in Bcf. CEC delivery data use GWh. Operator comparisons use average MW over equally long complete days. Forecast water volumes in the CSV are thousand acre-feet (KAF).

## Entries to investigate

|Question|Start here|
|---|---|
|What happened in California and the three-state Northwest in 2023?|Filter `annual.csv` by year and scope. Columns beginning with `d_` are current minus previous year.|
|Where did the lower Bonneville output appear?|Open `trade_directions.csv`, then `trade_direction_pairs.csv` and `operator_pairs.csv`. Pair differences are lower-water day less higher-water day.|
|Did a river signal beat a seasonal average or a trend?|Use `forecast_scores.csv`, `forecast_alternatives.csv`, `neighbor_sensitivity.csv` and `omission_test.csv`. Forecast errors have model-minus-actual sign.|
|What did a forecaster see in March or April?|Find `forecast.csv`. Open the matching packet via `sources.tsv` at its listed PDF page.|
|Did water and gas move in opposite directions in other states?|Use `directional_records.csv`, `calendar_test.csv` and `quarterly.csv`. Lower-quartile flags are based on the prior values for that calendar month.|
|What happens if the daily load match changes?|Filter `pair_summary.csv`, `pair_calendar.csv`, `pair_years.csv`, `day_pairs.csv`, `pair_hour_blocks.csv` and `pair_residual_checks.csv`.|
|Can a separate publication confirm a power balance?|Use `operator_vs_eia.csv`, `operator_clean_days.csv` and `grid_days.csv`. The federal and direct operator data come from the same underlying operating area.|
|Can I trace an annual discrepancy or separate output from intensity?|Open `crosscheck.csv`, `generation_and_intensity.csv` and the matching `monthly.csv` rows.|
|Which California runoff or imported energy series did the book use?|Open `california_water.csv`, `california_deliveries.csv`, `observed_water_correlations.csv` and `watersheds.csv`.|
|What was actually predicted?|Open `hindcast.csv` for the exact season, target and issue month. Each scored year has only earlier training years.|

## Definitions that affect the answer

- NW3 includes Washington, Oregon and Idaho. WEST11 contains those three states plus California, Montana, Wyoming, Colorado, New Mexico, Arizona, Nevada and Utah. US-TOTAL is EIA's national series including Alaska and Hawaii. California ISO and Bonneville are balancing areas. The CEC's Northwest and Southwest are its own import source regions.
- Annual source rows come from the annual workbook. Monthly and quarterly analyses use the monthly workbook. The same-month direction tests use 2005 onward so their comparison pairs remain on the same side of the 2004 CHP fuel-allocation change. Table gaps are monthly sum minus independently published annual value.
- Federal generation is the total electric power industry producer category. Only the conventional hydro fuel category enters the state panel. Missing individual generation categories for state periods with a reported total are treated as absent in the accounting. The physical fuel series uses natural gas in Mcf allocated to electricity. Broader gas deliveries to electric customers can differ. Inputs include all individual states and the federal aggregate. Do not sum rows containing nested aggregates.
- The three issued forecasts each year are January, March and April. Predictions all target later May–August electric outcomes. Use the first displayed ten-day precipitation ensemble on The Dalles page for the April–August volume. The term “ten-day” refers to the precipitation input. Some operating rules instead used five-day precipitation guidance. Exceedance 90 is the lower volume, exceedance 10 the upper. `runoff.csv` uses reconstructed observations, not the official classification a forecaster had in May.
- The grid extract uses EIA adjusted columns and the source's data date and hour number. Before 2025 water includes hydro and pumped storage. Beginning in 2025 the two separately reported components are added when at least one is observed. The combined value is missing when neither is observed. The residual is demand minus generation plus positive net exports. Other generation is the balance of net generation after gas and the combined water category.
- A federal day requires all 24 observations for all variables plus the stated intraday load screen. Within each month select top and bottom thirds by average water generation. Pair same-weekday-type dates greedily from the closest symmetric percentage difference in daily load, using each day once at a given tolerance. The flow direction may change inside a day. The matched date is not necessarily later than its reference.
- The BPA extract reads operator-local daily labels, with 288 five-minute readings and complete core series required for the cross-source pairs. Solar is available explicitly in the newer scheme. Where it is unavailable, it contributes zero to the reconstructed itemized generation total. This convention can affect the small reconstructed residual. The operator fossil/biomass line is broader than natural gas. The same dates, selected by the federal three-percent load rule, are reused in the operator series.
- The CEC workbook displays some import cells as dashes or blanks. Dashes contribute zero. Missing cells are not imputed as a positive fuel. Regional totals here sum published fuel entries, so final decimal precision can differ from printed regional totals. Large and small hydro are combined only when the calculation calls for all hydro.
- For the time-trend challenger, fit an expanding least-squares line to the earlier outcomes using calendar year. For the nearest-neighbor rules, rank earlier observations by absolute difference in forecast water volume. Ties retain the older row. The omission analysis removes one scored error from the average and does not retrain models. No forecast was evaluated against a Henry Hub price, and historical final electricity records do not prove the availability of every value on its original release day.

## Input provenance and optional refresh

`upstream_sources.tsv` records source URLs and SHA-256 values for original upstream files. `input_sha256.tsv` records the bytes of the normalized inputs used for the replay. Original annual forecast dates, archived issue links and page numbers are in the source register. This edition includes 42 forecast packets in its input provenance and the numeric rows extracted from them. The file also includes 14 federal half-year grid files and seven BPA workbooks. Five charts used in the book are in the figures folder.

For an optional download and fresh extraction, install `openpyxl`, `xlrd`, `lxml` and the command-line Poppler program `pdftotext` in addition to the main requirements. Use a new empty working directory and invoke `python /absolute/path/to/acquisition/refresh_inputs.py`. This requires internet access and substantial temporary disk space. New upstream releases can change source bytes and historical values. The default offline replay is the reference calculation for this edition. The acquisition scripts retain selected fields and dates, so the small companion does not redistribute every original workbook.
