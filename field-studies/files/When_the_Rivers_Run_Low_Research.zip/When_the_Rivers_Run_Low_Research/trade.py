from pathlib import Path
import sys,pandas as pd,numpy as np
def main(R):
 op=pd.read_csv(R/'operator_pairs.csv');b=pd.read_csv(R/'operator_clean_days.csv').set_index('day')
 for side,key in [('low','low_day'),('high','high_day')]:
  for col in ['export','water','thermal','wind','load']:
   op[side+'_'+col]=op[key].map(b[col])
 op['direction']=np.select([(op.low_export>=0)&(op.high_export>=0),(op.low_export<0)&(op.high_export<0),op.low_export<0],['export on both','import on both','to net import'],default='to net export')
 op['export_fell']=op.low_export<op.high_export
 op.to_csv(R/'trade_direction_pairs.csv',index=False)
 tab=op.groupby('direction').agg(pairs=('direction','size'),lower_exports=('export_fell','sum'),mean_water=('op_water','mean'),mean_exports=('op_export','mean'),mean_thermal=('op_thermal','mean'),mean_gas=('eia_gas','mean')).reset_index();tab.to_csv(R/'trade_directions.csv',index=False)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'results')
