from pathlib import Path
import sys,pandas as pd,numpy as np
def main(R):
 d=pd.read_csv(R/'hindcast.csv');alt=pd.read_csv(R/'forecast_alternatives.csv');d=d.merge(alt.drop(columns='actual'),on=['issue','year','target'])
 v=[]
 for (issue,t),g in d.groupby(['issue','target']):
  for method in ['water_model','one_analogue','trend','water_and_trend']:
   diff=(g.five_year-g.actual).abs()-(g[method]-g.actual).abs()
   loo=[diff.drop(i).mean() for i in diff.index];best=diff.idxmax();worst=diff.idxmin()
   v.append([issue,t,method,diff.mean(),min(loo),max(loo),int(g.loc[best,'year']),diff.loc[best],int(g.loc[worst,'year']),diff.loc[worst],int((diff>0).sum())])
 pd.DataFrame(v,columns=['issue','target','challenger','mean_gain','leave_one_out_low','leave_one_out_high','best_year','best_gain','worst_year','worst_gain','wins']).to_csv(R/'omission_test.csv',index=False)
 # Both correlations and year-to-year changes use measured final California runoff.
 c=pd.read_csv(R/'california_water.csv').sort_values('year')
 rows=[]
 for period,x in [('levels',c),('annual changes',c.select_dtypes('number').diff().dropna())]:
  for inp in ['sac_apr_jul','sj_apr_jul']:
   for target in ['hydro','gas','burn']:rows.append([period,inp,target,len(x),x[inp].corr(x[target])])
 pd.DataFrame(rows,columns=['scale','input','target','years','pearson_r']).to_csv(R/'observed_water_correlations.csv',index=False)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'results')
