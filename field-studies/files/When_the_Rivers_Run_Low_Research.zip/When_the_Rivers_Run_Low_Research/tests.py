"""Sensitivity checks and historical analogues, all chosen using earlier years."""
from pathlib import Path
import numpy as np
import pandas as pd
import sys
def main(R):
 m=pd.read_csv(R/'monthly.csv')
 rows=[]
 for scope in ['CA','NW3','WA','OR','ID','NY','AL','TN','WEST11','US-TOTAL']:
  a=m[(m.scope==scope)&(m.year>=2005)];base=a.d_burn.gt(0).mean()
  for k,b in [('all declines',a[a.d_hydro<0]),('all increases',a[a.d_hydro>0])]:
   rows.append([scope,k,len(b),int((b.d_burn>0).sum()),base,b.d_burn.mean(),b.d_burn.median(),b.d_hydro.mean()])
  for y in range(2010,2026):
   train=a[a.year<y];curr=a[a.year==y];thr=train.groupby('month').d_hydro.quantile(.25)
   for row in curr.itertuples():
    if row.d_hydro<=thr[row.month]:
     rows.append([scope,'lower quartile '+str(y),1,int(row.d_burn>0),base,row.d_burn,row.d_burn,row.d_hydro])
 pd.DataFrame(rows,columns=['scope','condition','n','burn_up','unconditional_up_rate','mean_d_burn','median_d_burn','mean_d_hydro']).to_csv(R/'directional_records.csv',index=False)
 # Nearest runoff-forecast analogue, defined in absolute water volume and never selected on realized gas burn.
 f=pd.read_csv(Path(__file__).resolve().parent/'forecast.csv')
 z=m[(m.scope=='NW3')&m.month.between(5,8)].groupby('year')[['hydro','burn','gas']].sum();ans=[]
 for issue in (1,3,4):
  w=f[f.issue_month==issue].set_index('year').join(z)
  for y in range(2018,2026):
   tr=w[w.index<y].copy();point=w.loc[y];near=(tr.median_kaf-point.median_kaf).abs().sort_values(kind='stable').index[0];prev=tr.iloc[-1]
   for target in ['hydro','gas','burn']:
    Y=tr[target].to_numpy();x=tr.median_kaf.to_numpy()/1000;time=tr.index.to_numpy()-2012
    fit=np.linalg.lstsq(np.column_stack([np.ones(len(x)),time,x]),Y,rcond=None)[0];trend=np.polyval(np.polyfit(time,Y,1),y-2012)
    ans.append([issue,y,target,near,point.median_kaf,tr.loc[near,'median_kaf'],point[target],tr.loc[near,target],trend,np.dot([1,y-2012,point.median_kaf/1000],fit)])
 t=pd.DataFrame(ans,columns=['issue','year','target','nearest_year','forecast_kaf','analogue_kaf','actual','one_analogue','trend','water_and_trend']);t.to_csv(R/'forecast_alternatives.csv',index=False)
 # Conditional CISO/BPAT comparison when the two dates have small observed accounting residuals.
 p=pd.read_csv(R/'day_pairs.csv').query('load_tolerance==.03')
 d=pd.read_csv(R/'grid_days.csv').set_index(['ba','day'])
 records=[]
 for row in p.itertuples():
  lo=d.loc[(row.ba,row.lower_water_date)];hi=d.loc[(row.ba,row.higher_water_date)]
  records.append(max(abs(lo.error/lo.load),abs(hi.error/hi.load)))
 p['max_error_fraction']=records;out=[]
 for ba,g in p.groupby('ba'):
  for threshold in (.01,.03,.05,.1,1e6):
   s=g[g.max_error_fraction<=threshold];w=-s.water.sum()
   out.append([ba,threshold,len(s),w,s.ng.sum()/w if w else np.nan,-s.export.sum()/w if w else np.nan,s.error.sum()/w if w else np.nan])
 pd.DataFrame(out,columns=['ba','max_residual_fraction','pairs','sum_hydro_gap_mw','gas_share','import_share','residual_share']).to_csv(R/'pair_residual_checks.csv',index=False)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'results')
