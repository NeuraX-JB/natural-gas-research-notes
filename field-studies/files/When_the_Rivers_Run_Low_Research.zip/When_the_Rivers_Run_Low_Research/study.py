"""Replay the tables in When the Rivers Run Low using only the frozen inputs."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
K=Path(__file__).resolve().parent
OUT=Path(sys.argv[1]) if __name__=='__main__' and len(sys.argv)>1 else K/'results'
OUT.mkdir(parents=True,exist_ok=True)
def save(d,name):
 d.to_csv(OUT/(name+'.csv'),index=False,float_format='%.8f')
def read(name):
 return pd.read_csv(K/(name+'.csv.gz'))
def shape(annual):
 g=read('annual_generation_state' if annual else 'generation_monthly')
 c=read('annual_consumption_state' if annual else 'consumption_monthly')
 keys=['state','year','month'];labels={'Total':'total','Hydroelectric Conventional':'hydro','Natural Gas':'gas','Nuclear':'nuclear','Pumped Storage':'pump','Solar Thermal and Photovoltaic':'solar','Wind':'wind','Coal':'coal'}
 for d in [g,c]:d['state']=d.state.str.strip().str.upper()
 g=g[g.source.isin(labels)&g.state.str.len().gt(0)].copy();g['source']=g.source.map(labels)
 assert not g.duplicated(keys+['source']).any()
 g=g.pivot(index=keys,columns='source',values='value').div(1e6);g=g[g.total.notna()]
 # An unlisted generating source for a state-month with a total contributes zero to the grouped accounting.
 g=g.fillna(0).reset_index();g['other']=g.total-g[['hydro','gas','nuclear','pump','solar','wind','coal']].sum(axis=1)
 c=c.rename(columns={'value':'burn'});g=g.merge(c[keys+['burn']],on=keys,how='left',validate='one_to_one');g['burn']/=1e6
 g['scope']=g['state'];parts=[g];regions={'NW3':['WA','OR','ID'],'WEST11':['WA','OR','ID','CA','MT','WY','CO','NM','AZ','NV','UT']}
 for scope,states in regions.items():
  z=g[g.state.isin(states)];assert z.groupby(['year','month']).size().eq(len(states)).all()
  z=z.drop(columns=['state','scope']).groupby(['year','month']).sum(min_count=len(states)).reset_index();z['scope']=scope;parts.append(z)
 return pd.concat(parts,ignore_index=True).drop(columns='state').sort_values(['scope','year','month'])
M=['hydro','gas','burn','total','coal','nuclear','solar','wind','pump','other']
def differences(d,group):
 d=d.sort_values(group+['year']).copy();delta=d.groupby(group)[M].diff(); prev=d.groupby(group).year.diff().eq(1);delta=delta.where(prev);return pd.concat([d,delta.add_prefix('d_')],axis=1)
def make():
 month=shape(False);annual=shape(True);annual=differences(annual,['scope']);month=differences(month,['scope','month'])
 save(annual,'annual');save(month,'monthly')
 q=month.copy();q['quarter']=(q.month-1)//3+1
 q=q.groupby(['scope','year','quarter'])[M].sum(min_count=3).reset_index();q=differences(q,['scope','quarter']);save(q,'quarterly')
 # An exact volume decomposition between consecutive years.
 a=annual[annual.scope.isin(['CA','NW3','WA','OR','ID','WEST11','US-TOTAL','NY','AL','TN'])].copy()
 a['intensity']=a.burn/a.gas
 a['prev_i']=a.groupby('scope').intensity.shift();a['volume_term']=a.d_gas*(a.intensity+a.prev_i)/2
 a['mix_term']=(a.intensity-a.prev_i)*(a.gas+(a.gas-a.d_gas))/2
 assert (a.d_burn-a.volume_term-a.mix_term).abs().max()<1e-8
 save(a,'generation_and_intensity')
 mo=month[month.year>=2005];cs=[]
 for (scope,m),z in mo.dropna(subset=['d_hydro','d_burn']).groupby(['scope','month']):
  dry=z[z.d_hydro<0];cs.append([scope,m,len(z),len(dry),int((dry.d_burn>0).sum()),dry.d_hydro.mean(),dry.d_burn.mean(),dry.d_burn.median(),z.d_hydro.corr(z.d_burn) if z.d_hydro.std()>0 and z.d_burn.std()>0 else np.nan])
 save(pd.DataFrame(cs,columns=['scope','month','n','hydro_declines','burn_up','mean_d_hydro','mean_d_burn','median_d_burn','corr']),'calendar_test')
 checks=month.groupby(['scope','year'])[M].sum(min_count=12).reset_index().merge(annual[['scope','year']+M],on=['scope','year'],suffixes=('_sum','_annual'))
 for c in M:checks[c+'_gap']=checks[c+'_sum']-checks[c+'_annual']
 save(checks,'crosscheck')
 # The ten-day-QPF median tracks the same forecast product through changing front-page conventions.
 w=pd.read_csv(K/'forecast.csv');h=month.query("scope=='NW3' and 5<=month<=8").groupby('year')[['hydro','burn','gas']].sum(min_count=4).reset_index()
 scores=[]
 for m in (1,3,4):
  z=w[w.issue_month==m].merge(h,on='year').sort_values('year')
  for year in range(2018,2026):
   train=z[z.year<year];test=z[z.year==year].iloc[0]; assert len(train)>=6
   for target in ['hydro','gas','burn']:
    pred=np.polyval(np.polyfit(train.median_kaf/1000,train[target],1),test.median_kaf/1000)
    scores.append([year,m,target,test[target],train[target].tail(5).mean(),train[target].mean(),train[target].iloc[-1],pred])
 f=pd.DataFrame(scores,columns=['year','issue','target','actual','five_year','expanding_mean','prior','water_model']);save(f,'hindcast')
 rows=[]
 for (m,t),z in f.groupby(['issue','target']):
  for method in ('five_year','expanding_mean','prior','water_model'):
   e=z[method]-z.actual;rows.append([m,t,method,len(z),e.abs().mean(),np.sqrt((e**2).mean()),e.mean(),(e.abs()<(z.five_year-z.actual).abs()).sum()])
 save(pd.DataFrame(rows,columns=['issue','target','method','years','mae','rmse','bias','wins_vs_five']),'forecast_scores')
 # Cases grouped by the two independent water regions.
 r=pd.read_csv(K/'runoff.csv');ca=month[month.scope.eq('CA') & month.month.between(4,7)].groupby('year')[M].sum(min_count=4).reset_index();ca=ca.merge(r,on='year');save(ca,'california_water')
 z=ca.merge(w[w.issue_month==4],on='year').merge(h,on='year',suffixes=('_ca','_nw'));save(z,'watersheds')
 c=pd.read_csv(K/'cec.csv');c['fuel']=c['Fuel Type'].replace({'Large Hydro':'hydro','Small Hydro':'hydro','Natural Gas':'gas','Solar':'solar','Wind':'wind','Nuclear':'nuclear'})
 c['GWh']=pd.to_numeric(c.GWh.astype('string').str.strip().replace('-', '0'),errors='raise')
 cec=c.groupby(['year','Region','fuel']).GWh.sum(min_count=1).unstack(fill_value=0).reset_index()
 cec['total']=cec.drop(columns=['year','Region']).sum(axis=1);save(cec,'california_deliveries')
 return month,annual
if __name__=='__main__': make()
