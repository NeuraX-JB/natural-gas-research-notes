"""Verify the frozen inputs, rebuild all results, and compare numeric tables."""
from pathlib import Path
import argparse,hashlib,subprocess,sys
import pandas as pd
K=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=K/'replayed');args=ap.parse_args()
 out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
 if out==(K/'results').resolve(): raise SystemExit('Choose an output directory separate from the published results.')
 for r in pd.read_csv(K/'input_sha256.tsv',sep='\t').itertuples():
  if hashlib.sha256((K/r.file).read_bytes()).hexdigest()!=r.sha256:raise ValueError('Frozen input digest mismatch: '+r.file)
 for script in ['study.py','grid.py','tests.py','operator_compare.py','robustness.py','trade.py']:
  subprocess.run([sys.executable,str(K/script),str(out)],check=True)
 tables=sorted((K/'results').glob('*.csv'))
 if {p.name for p in tables}!={p.name for p in out.glob('*.csv')}:raise ValueError('Published and reproduced result inventories differ')
 for p in tables:
  pd.testing.assert_frame_equal(pd.read_csv(p),pd.read_csv(out/p.name),rtol=1e-8,atol=1e-7)
 print(f'Reproduced {len(tables)} result tables from 9 verified inputs.')
if __name__=='__main__':main()
