from pathlib import Path
import sys
import numpy as np
import pandas as pd
K=Path(__file__).resolve().parent
fields=['load','gen','export','ng','water','other','error']
def main(out):
 h=pd.read_csv(K/'hourly.csv.gz',parse_dates=['day']); assert not h.duplicated(['ba','utc_end']).any()
 h['other']=h.gen-h.water-h.ng;h['error']=h.load-h.gen+h.export
 g=h.groupby(['ba','day']);d=g[fields].mean();d['hours']=g.size();d['valid']=g[fields].count().min(axis=1)
 d['shape_ok']=(g.load.min()>.45*g.load.median()) & (g.load.max()<2*g.load.median());d['good']=d.hours.eq(24)&d.valid.eq(24)&d.shape_ok;d=d.reset_index()
 d['year']=d.day.dt.year;d['month']=d.day.dt.month;d['weekend']=d.day.dt.dayofweek>=5
 d.to_csv(out/'grid_days.csv',index=False,float_format='%.8f')
 elig=d[d.good].copy(); rs=[]
 for tol in [.01,.03,.05]:
  for (ba,y,m),v in elig.groupby(['ba','year','month']):
   ordered=v.sort_values(['water','day']);n=len(ordered)//3;low=ordered.head(n);high=ordered.tail(n);edges=[]
   for a in low.itertuples():
    for b in high.itertuples():
     gap=abs(a.load-b.load)/((a.load+b.load)/2)
     if a.weekend==b.weekend and gap<=tol and a.water<b.water:edges.append((gap,a.day,b.day,a,b))
   used=set()
   for gap,da,db,a,b in sorted(edges,key=lambda e:e[:3]):
    if da in used or db in used:continue
    used.update([da,db]);rs.append([tol,ba,y,m,da,db,gap]+[getattr(a,c)-getattr(b,c) for c in fields])
 pairs=pd.DataFrame(rs,columns=['load_tolerance','ba','year','month','lower_water_date','higher_water_date','load_gap_fraction']+fields)
 pairs.to_csv(out/'day_pairs.csv',index=False,float_format='%.8f')
 assert (pairs.load-pairs.ng-pairs.water-pairs.other+pairs.export-pairs.error).abs().max()<1e-7
 def summ(x):
  water=-x.water.sum()
  return pd.Series(dict(n=len(x),mean_hydro_gap_mw=water/len(x),ng_share=x.ng.sum()/water,import_share=-x.export.sum()/water,other_share=x.other.sum()/water,load_term=-x.load.sum()/water,error_term=x.error.sum()/water,gas_up=(x.ng>0).mean(),median_ng_mw=x.ng.median()))
 for keys,name in [(['load_tolerance','ba'],'pair_summary'),(['load_tolerance','ba','year'],'pair_years'),(['load_tolerance','ba','month'],'pair_calendar')]:
  z=pairs.groupby(keys)[fields].apply(summ).reset_index();assert np.allclose(z[['ng_share','import_share','other_share','load_term','error_term']].sum(axis=1),1)
  z.to_csv(out/(name+'.csv'),index=False,float_format='%.8f')
 # Hour-label blocks use ordinary 24-observation days only. Each pair has both days and all hours.
 lookup=h.set_index(['ba','day','hour'])[fields].sort_index()
 byblock=[]
 for row in pairs[pairs.load_tolerance.eq(.03)].itertuples():
  v=lookup.loc[row.ba,row.lower_water_date]-lookup.loc[row.ba,row.higher_water_date]
  for i in range(4):
   a=v.loc[i*6+1:i*6+6].mean()
   byblock.append([row.ba,row.year,row.month,row.lower_water_date,row.higher_water_date,i+1]+a.to_list())
 b=pd.DataFrame(byblock,columns=['ba','year','month','low_day','high_day','block']+fields);b.to_csv(out/'pair_hour_blocks.csv',index=False,float_format='%.8f')
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
