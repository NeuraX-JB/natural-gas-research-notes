"""Reproduce the South Central working-gas study in Chapter 6, using Python 3.8+.

Run python replicate_weekly.py next to measure_rows.csv, or pass a CSV path.
The input is a fixed vintage of three EIA weekly stock series. Its unit column
records the source tables' unit. Numeric values alone cannot identify units.
"""

import argparse
import csv
import sys
from collections import namedtuple
from datetime import date, timedelta
from fractions import Fraction
from pathlib import Path
from statistics import median

Stocks = namedtuple("Stocks", "salt nonsalt region")
Week = namedtuple("Week", "day opening closing salt_draw nonsalt_draw region_draw")
WEEK = timedelta(days=7)
FIRST_WINTER = 2018
LAST_WINTER = 2025


def read_stocks(path):
    records = {}
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        expected = {"date", "salt", "nonsalt", "region", "unit"}
        if not reader.fieldnames or set(reader.fieldnames) != expected or len(reader.fieldnames) != len(expected):
            raise ValueError("The CSV must contain exactly date, salt, nonsalt, region, unit.")
        for line_number, row in enumerate(reader, 2):
            try:
                day = date.fromisoformat(row["date"])
                if day.weekday() != 4 or day in records:
                    raise ValueError("Date is not a Friday or appears more than once.")
                if row["unit"] != "Bcf":
                    raise ValueError("Expected the EIA stock unit Bcf.")
                if any(not row[key].isascii() or not row[key].isdigit() for key in ("salt", "nonsalt", "region")):
                    raise ValueError("Stocks must be nonnegative whole Bcf.")
                stocks = Stocks(*(int(row[key]) for key in ("salt", "nonsalt", "region")))
                if abs(stocks.salt + stocks.nonsalt - stocks.region) > 1:
                    raise ValueError("South Central stock differs from the class sum by more than 1 Bcf.")
                records[day] = stocks
            except (ValueError, AttributeError, TypeError) as error:
                raise ValueError(f"Invalid input at CSV line {line_number}: {error}") from error
    if not records:
        raise ValueError("Empty input.")
    cursor = min(records)
    while cursor <= max(records):
        if cursor not in records:
            raise ValueError(f"Gap in the supplied weekly stock history at {cursor}.")
        cursor += WEEK
    return records


def get_winter_weeks(stocks, year):
    start = date(year, 12, 1)
    day = start + timedelta(days=(4 - start.weekday()) % 7)
    weeks = []
    while day < date(year + 1, 3, 1):
        for endpoint in (day - WEEK, day):
            if endpoint not in stocks:
                raise ValueError(f"Missing required endpoint {endpoint} for the week ending {day}.")
        opening, closing = stocks[day - WEEK], stocks[day]
        if min(opening.salt, opening.nonsalt) <= 0:
            raise ValueError(f"Cannot compute a class fraction with a zero opening stock for {day}.")
        weeks.append(Week(day, opening, closing, opening.salt - closing.salt,
                          opening.nonsalt - closing.nonsalt, opening.region - closing.region))
        day += WEEK
    return weeks


def fractions(week):
    return Fraction(week.salt_draw, week.opening.salt), Fraction(week.nonsalt_draw, week.opening.nonsalt)


def common_draws(weeks):
    return [week for week in weeks if week.salt_draw > 0 and week.nonsalt_draw > 0]


def season_stats(weeks):
    paired = common_draws(weeks)
    gaps = [salt - nonsalt for salt, nonsalt in map(fractions, paired)]
    count_faster = sum(gap > 0 for gap in gaps)
    opposite = sum(week.salt_draw * week.nonsalt_draw < 0 for week in weeks)
    median_gap = f"{float(median(gaps) * 100):.2f}" if gaps else "NA"
    return (len(weeks), len(paired), count_faster, opposite, median_gap)


def bounds(opening, closing):
    # Independent rounding to whole Bcf puts each unrounded endpoint within
    # half a Bcf of its displayed level. Limit the lower closing stock to zero.
    low = 1 - Fraction(2 * closing + 1, 2 * opening - 1)
    high = 1 - Fraction(max(0, 2 * closing - 1), 2 * opening + 1)
    return low, high


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", nargs="?", type=Path, default=Path(__file__).with_name("measure_rows.csv"))
    args = parser.parse_args()
    stocks = read_stocks(args.csv)
    seasons = {year: get_winter_weeks(stocks, year) for year in range(FIRST_WINTER, LAST_WINTER + 1)}
    all_weeks = [week for winter in seasons.values() for week in winter]
    event_dates = {date(2021, 2, 19), date(2022, 12, 30)}

    print("Selected event weeks. Positive draws indicate a stock decline.")
    print("Week ending    salt Bcf    nonsalt Bcf    region Bcf    salt % of opening    nonsalt % of opening")
    for week in all_weeks:
        if week.day in event_dates:
            salt, nonsalt = fractions(week)
            print(f"{week.day} {week.salt_draw:11d} {week.nonsalt_draw:14d} {week.region_draw:13d}"
                  f" {float(100 * salt):20.2f} {float(100 * nonsalt):23.2f}")

    print("\nWinter       all    both draw    salt faster    opposite signs    median gap (points)")
    for label, weeks in [(f"{year}-{year + 1}", w) for year, w in seasons.items()] + [("Pooled", all_weeks)]:
        count, paired, faster, opposite, gap = season_stats(weeks)
        print(f"{label:10s} {count:5d} {paired:12d} {faster:14d} {opposite:17d} {gap:>22s}")
    paired = common_draws(all_weeks)
    absolute = sum(week.salt_draw > week.nonsalt_draw for week in paired)
    relative = season_stats(all_weeks)[2]
    without = season_stats([week for week in all_weeks if week.day not in event_dates])
    salt_built = sum(week.salt_draw < 0 < week.nonsalt_draw for week in all_weeks)
    nonsalt_built = sum(week.nonsalt_draw < 0 < week.salt_draw for week in all_weeks)
    print(f"\nLarger absolute salt draw among common draws: {absolute}/{len(paired)}")
    print(f"Larger percentage salt draw among common draws: {relative}/{len(paired)}")
    print(f"Larger percentage salt draw excluding the two selected dates: {without[2]}/{without[1]}")
    print(f"Opposite signs by class building: salt {salt_built}, nonsalt {nonsalt_built}")

    clear_salt = clear_nonsalt = 0
    for week in paired:
        salt = bounds(week.opening.salt, week.closing.salt)
        nonsalt = bounds(week.opening.nonsalt, week.closing.nonsalt)
        clear_salt += salt[0] > nonsalt[1]
        clear_nonsalt += nonsalt[0] > salt[1]
    ambiguous = len(paired) - clear_salt - clear_nonsalt
    print(f"Independent whole-Bcf rounding check: salt clearly faster {clear_salt},"
          f" nonsalt clearly faster {clear_nonsalt}, ambiguous {ambiguous}")
    print(f"Conservative salt-win bounds within the published paired set: "
          f"{clear_salt} to {clear_salt + ambiguous} of {len(paired)}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        sys.exit(f"Study input error: {error}")
