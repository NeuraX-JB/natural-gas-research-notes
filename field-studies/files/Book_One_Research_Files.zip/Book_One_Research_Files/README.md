# The Gas That Can Reach You
## Reproduction files for Chapters 6 and 13

Unzip this directory, open a terminal in it and run the following with Python 3.8 or newer. Both scripts use the standard library and the included data. On Windows you can use `py` in place of `python`.

```sh
python replicate_weekly.py
python replicate_monthly.py
```

**Chapter 6.** `measure_rows.csv` carries Friday stock observations for South Central salt, nonsalt and the published regional total, in whole Bcf. EIA sometimes rounds the component and regional totals independently. The working selection is December–February Fridays in the eight winters from 2018–19 through 2025–26. The other observations are retained so that the previous Friday can be recovered. See sources M8 through M10.

**Chapter 13.** `state_month_flows.csv` has all 240 Louisiana and Michigan state-month pairs for 2016–2025, in MMcf. Reported injections and withdrawals are both stored as positive volumes. A positive signed net in this study indicates withdrawals exceed injections. See A1 through A4. The chapter's published results use the supplied values. Historical EIA series can be revised, so record the retrieval date and keep a separate copy if you refresh the data.

The weekly script reproduces the two event comparisons, counts and rounding checks. The monthly script reproduces the full-period tables, calendar-month comparison, annual sensitivity and alternative intervals. `source_register.tsv` maps the book's citations to public records. The last file records which questions this volume answered and which lead is reserved for the next volume.

Research snapshot assembled November 24, 2026. Historical series are the versions observed during preparation. Neither dataset is a first-release archive.
