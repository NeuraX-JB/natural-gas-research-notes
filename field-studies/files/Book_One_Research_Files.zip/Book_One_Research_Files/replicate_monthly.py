"""Reproduce Chapter 13 from 240 EIA state-month pairs. Requires Python 3.8+."""
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean, median

BASE = Path(__file__).resolve().parent
STATES = ('Louisiana', 'Michigan')


def read_rows():
    pairs = {}
    with (BASE / 'state_month_flows.csv').open(newline='', encoding='utf-8') as source:
        for row in csv.DictReader(source):
            key = (row['state'], int(row['year']), int(row['month']))
            i, w = int(row['injections_MMcf']), int(row['withdrawals_MMcf'])
            if key in pairs or min(i, w) < 0:
                raise ValueError(f'Duplicate or invalid record: {key}')
            pairs[key] = (i, w)
    expected = {(s, y, m) for s in STATES for y in range(2016, 2026) for m in range(1, 13)}
    if set(pairs) != expected:
        raise ValueError('Expected twelve months per state-year, 2016–2025.')
    return pairs


def summarize(pairs):
    pairs = list(pairs)
    injections = sum(i for i, w in pairs)
    withdrawals = sum(w for i, w in pairs)
    gross = injections + withdrawals
    net_magnitude = sum(abs(w - i) for i, w in pairs)
    offset = gross - net_magnitude
    assert offset == sum(2 * min(i, w) for i, w in pairs)
    return injections, withdrawals, gross, net_magnitude, offset, 100 * offset / gross


def aggregate(pairs, level):
    totals = defaultdict(lambda: [0, 0])
    for (y, m), (i, w) in pairs.items():
        group = y if level == 'year' else 'whole period'
        totals[group][0] += i
        totals[group][1] += w
    return list(totals.values())


def main():
    all_pairs = read_rows()
    for state in STATES:
        pairs = {(y, m): value for (s, y, m), value in all_pairs.items() if s == state}
        i, w, g, n, offset, share = summarize(pairs.values())
        print(f'\n{state}  |  {len(pairs)} months')
        print(f'Injections {i/1000:,.3f}, withdrawals {w/1000:,.3f}, gross {g/1000:,.3f} Bcf')
        print(f'Sum of absolute monthly nets {n/1000:,.3f} Bcf, offset {offset/1000:,.3f} Bcf ({share:.1f}%)')
        print('Year, percent offset after monthly netting')
        for year in range(2016, 2026):
            print(year, f'{summarize(v for (y, m), v in pairs.items() if y == year)[-1]:.1f}')
        print('Calendar month, pooled percent offset')
        for month in range(1, 13):
            print(month, f'{summarize(v for (y, m), v in pairs.items() if m == month)[-1]:.1f}')
        for start in [2016, 2021]:
            sub = [v for (y, m), v in pairs.items() if start <= y < start + 5]
            print(f'{start}–{start+4} volume-weighted share {summarize(sub)[-1]:.1f}%')
        shares = [summarize([v])[-1] for v in pairs.values() if sum(v)]
        print(f'Mean and median monthly shares {mean(shares):.1f}% and {median(shares):.1f}%')
        for name, months in [('DJF', (12, 1, 2)), ('April–October', range(4, 11))]:
            sub = [v for (y, m), v in pairs.items() if m in months]
            print(f'{name} net withdrawal months: {sum(w > i for i, w in sub)}/{len(sub)}')
        for level in ('year', 'whole period'):
            print(f'Net separately within each {level}: {summarize(aggregate(pairs, level))[-1]:.1f}%')


if __name__ == '__main__':
    main()
