"""Reconstruct the voyage, calendar and gas-week accounts used by this edition."""
from pathlib import Path
import re,sys
import numpy as np
import pandas as pd
K=Path(__file__).resolve().parent
PORTS=['Sabine Pass','Corpus Christi','Cove Point','Cameron','Freeport','Elba Island','Calcasieu Pass','Plaquemines']
GROUP={'Sabine Pass':'Louisiana','Calcasieu Pass':'Louisiana','Cameron':'Louisiana','Plaquemines':'Louisiana','Corpus Christi':'Texas','Freeport':'Texas','Cove Point':'East','Elba Island':'East'}
def save(file,df,out):
 df.to_csv(out/(file+'.csv'),index=False,float_format='%.8f')
def getrows(v=2025):
 d=pd.read_csv(K/f'cargo_{v}.csv.gz',parse_dates=['date']);d['ship_key']=d.ship.str.upper().str.replace(r'[^A-Z0-9]','',regex=True);d['bcf']=d.mmcf/1000;d['domestic']=d.bcf.where(d.activity.eq('Exports'),0);d['reexport']=d.bcf.where(d.activity.eq('Re-Exports'),0);return d
def voyages(d):
 v=d.groupby(['terminal','date','ship_key'],sort=True).agg(ship=('ship','first'),rows=('mmcf','size'),destinations=('country','nunique'),companies=('company','nunique'),activities=('activity','nunique'),bcf=('bcf','sum'),domestic=('domestic','sum'),reexport=('reexport','sum')).reset_index()
 assert np.isclose(v.bcf.sum(),d.bcf.sum()) and np.allclose(v.bcf,v.domestic+v.reexport);return v
def build(out):
 d=getrows();v=voyages(d);save('departures',v,out)
 t=v.groupby(['terminal','date']).agg(bcf=('bcf','sum'),calls=('ship_key','size'),rows=('rows','sum'),domestic=('domestic','sum'),reexport=('reexport','sum')).reset_index()
 dates=pd.date_range('2016-01-01','2025-12-31');idx=pd.MultiIndex.from_product([PORTS,dates],names=['terminal','date']);daily=t.set_index(['terminal','date']).reindex(idx,fill_value=0).reset_index()
 ns=daily.groupby('date')[['bcf','calls','rows','domestic','reexport']].sum().reset_index();ns['terminal']='All eight'
 group=daily.copy();group['terminal']=group.terminal.map(GROUP);group=group.groupby(['terminal','date']).sum(numeric_only=True).reset_index()
 daily=pd.concat([daily,group,ns],ignore_index=True).sort_values(['terminal','date']);daily['month']=daily.date.dt.to_period('M').astype(str);daily['year']=daily.date.dt.year
 save('daily',daily,out)
 monthly=daily.groupby(['terminal','month']).agg(bcf=('bcf','sum'),calls=('calls','sum'),rows=('rows','sum'),active_days=('calls',lambda a:(a>0).sum()),days=('date','size'),domestic=('domestic','sum'),reexport=('reexport','sum')).reset_index()
 monthly['rate']=monthly.bcf/monthly.days;monthly['size']=monthly.bcf/monthly.calls.replace(0,np.nan)
 monthly['delta']=monthly.groupby('terminal').rate.diff();monthly['calls_delta']=monthly.groupby('terminal').calls.diff();save('monthly',monthly,out)
 year=daily.groupby(['terminal','year']).agg(bcf=('bcf','sum'),calls=('calls','sum'),rows=('rows','sum'),active_days=('calls',lambda x:(x>0).sum()),days=('date','size')).reset_index();save('annual',year,out)
 dc=d.assign(month=d.date.dt.to_period('M').astype(str));dest=dc.groupby(['country','month','terminal']).agg(bcf=('bcf','sum'),lines=('bcf','size')).reset_index();save('destinations',dest,out)
 # Compare full source editions over the identical historical dates by key and as volume, without editing the first edition.
 newer=getrows(2026);newer=newer[newer.date.dt.year<=2025];keys=['date','terminal','ship_key','country','activity'];rev=d.groupby(keys).bcf.sum().rename('first').to_frame().join(newer.groupby(keys).bcf.sum().rename('later'),how='outer').fillna(0).reset_index();rev['change']=rev.later-rev['first'];save('cargo_revisions',rev[rev.change.abs()>0.0000049],out)
 sm=pd.read_csv(K/'monthly_2025.csv.gz');sm['month']=sm.month.str[:7];sm=sm.groupby(['terminal','month']).mmcf.sum()/1000
 comp=monthly[monthly.terminal.isin(PORTS)].set_index(['terminal','month'])[['bcf']].join(sm.rename('published')).reset_index();comp['gap']=comp.bcf-comp.published;save('monthly_crosscheck',comp,out)
 # First and last three days of a month, and alternative artificial cutoff dates with equal lengths.
 cuts=[]
 for term,z in daily.groupby('terminal'):
  z=z.set_index('date').sort_index()
  for month,g in z.groupby('month'):
   first,last=g.index[0],g.index[-1];rec=[term,month,g.bcf.sum(),g.bcf.head(3).sum(),g.bcf.tail(3).sum()]
   for shift in [-3,3]:
    a,b=first+pd.Timedelta(days=shift),last+pd.Timedelta(days=shift)
    rec.append(z.loc[a:b,'bcf'].sum() if a>=z.index.min() and b<=z.index.max() else np.nan)
   cuts.append(rec)
 save('month_edges',pd.DataFrame(cuts,columns=['terminal','month','official','first3','last3','earlier_cut','later_cut']),out)
 # Completed interdeparture intervals; two departures on one date count as one active day.
 ints=[]
 for term,g in t.groupby('terminal'):
  g=g.sort_values('date');prior=None
  for r in g.itertuples():
   if prior is not None:ints.append([term,prior,r.date,(r.date-prior).days-1,r.calls,r.bcf])
   prior=r.date
 save('closed_gaps',pd.DataFrame(ints,columns=['terminal','previous','next','quiet_days','next_calls','next_bcf']),out)
 # Fuel codes are respondent-year amounts; only a named respondent is matched at seven exits.
 ids={'17673853LA':'Sabine Pass','17679610TX':'Corpus Christi','17674103LA':'Cameron','17680882LA':'Calcasieu Pass','17650729MD':'Cove Point','17673910TX':'Freeport','17682720LA':'Plaquemines'}
 fu=pd.read_csv(K/'fuel_176.csv.gz');fu['terminal']=fu.id.map(ids);fu=fu[fu.terminal.notna()];assert not fu.duplicated(['year','terminal']).any()
 fu=fu.merge(year,on=['terminal','year'],validate='one_to_one');fu['fuel_bcf']=fu.mcf/1e6;fu['fuel_per_export']=fu.fuel_bcf/fu.bcf.replace(0,np.nan);fu['fuel_share_proxy']=fu.fuel_bcf/(fu.fuel_bcf+fu.bcf).replace(0,np.nan);save('reported_fuel',fu,out)
 return daily
if __name__=='__main__':build(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
