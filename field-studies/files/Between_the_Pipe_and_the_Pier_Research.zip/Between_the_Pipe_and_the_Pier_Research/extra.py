from pathlib import Path
import sys,numpy as np,pandas as pd
from study import save,getrows,K,PORTS
def main(out):
 d=getrows();v=pd.read_csv(out/'departures.csv',parse_dates=['date'])
 # Company summary, compare quarter at matching physical locations, never convert corporate TBtu to Bcf.
 c=pd.read_csv(K/'issuer_quarters.csv');z=v[v.terminal.isin(['Corpus Christi','Sabine Pass'])].copy();z['quarter']=z.date.dt.to_period('Q').astype(str)
 q=z.groupby('quarter').agg(doe_calls=('ship_key','size'),doe_rows=('rows','sum'),doe_bcf=('bcf','sum')).reset_index();c=c.merge(q,on='quarter',validate='one_to_one');c['call_gap']=c.doe_calls-c.reported_cargoes;c['recognition_gap']=c.recognized_tbtu-c.loaded_tbtu;save('issuer_bridge',c,out)
 # Compare the directional readings of changing cargo size and departure frequency across adjacent operating months.
 m=pd.read_csv(out/'monthly.csv');bridge=[]
 for sc,g in m.groupby('terminal'):
  g=g.sort_values('month');old=None
  for r in g.itertuples():
   if old is not None and old.calls and r.calls:
    oldf=old.calls/old.days;newf=r.calls/r.days
    fr=(newf-oldf)*(r.size+old.size)/2;sz=(r.size-old.size)*(newf+oldf)/2;bridge.append([sc,r.month,old.rate,r.rate,r.rate-old.rate,fr,sz])
   old=r
 br=pd.DataFrame(bridge,columns=['scope','month','old_rate','rate','delta','frequency_term','size_term']);assert np.allclose(br.delta,br.frequency_term+br.size_term,atol=2e-8);save('size_frequency',br,out)
 # Importance of observing zero-departure days in only an already-operating terminal.
 dz=pd.read_csv(out/'daily.csv',parse_dates=['date']);records=[]
 for sc in PORTS:
  gr=dz[dz.terminal.eq(sc)].copy();gr=gr[gr.date>=gr[gr.calls>0].date.min()].reset_index(drop=True);gr['ahead']=gr.calls.rolling(7).sum().shift(-7)
  med=0;last=None
  for j,r in enumerate(gr.itertuples()):
   if r.calls>0:last=j
   if j<180 or pd.isna(r.ahead):continue
   age=j-last;records.append([sc,r.date,age,int(r.ahead),r.bcf])
 days=pd.DataFrame(records,columns=['terminal','date','quiet_age','next7_calls','same_day_bcf']);save('waiting_days',days,out)
 dd=days.copy();dd['age_band']=pd.cut(dd.quiet_age,[-1,0,2,6,13,9999],labels=['0','1–2','3–6','7–13','14+'])
 ag=dd.groupby(['terminal','age_band'],observed=True).agg(days=('date','size'),no_call_next_week=('next7_calls',lambda x:(x==0).sum()),mean_next_calls=('next7_calls','mean')).reset_index();save('waiting_outcomes',ag,out)
 # Voyage concentration by destination uses the original volume parcels.
 d['year']=d.date.dt.year
 rr=d.groupby(['year','terminal','country']).bcf.sum().reset_index();rr['annual_share']=rr.bcf/rr.groupby(['year','terminal']).bcf.transform('sum');save('port_routes',rr,out)
 # Sensitivity to moving the arbitrary weekly cut within exactly the same EIA printed weeks.
 national=dz.query("terminal=='All eight'").set_index('date');wk=pd.read_csv(out/'matched_weeks.csv',parse_dates=['end']).query("scope=='All eight'");shift=[]
 for dayshift in [-7,-3,-1,0,1,3,7]:
  vals=[]
  for r in wk.itertuples():
   b=r.end+pd.Timedelta(days=dayshift);v=national.loc[b-pd.Timedelta(days=6):b]
   vals.append(v.bcf.sum()/7 if len(v)==7 else np.nan)
  w=wk.copy();w['proxy']=vals;w['d_proxy']=w.groupby('run').proxy.diff();v=w.dropna(subset=['d_proxy','d_receipts'])
  shift.append([dayshift,len(v),v.proxy.corr(v.receipts),v.d_proxy.corr(v.d_receipts),(v.d_proxy-v.d_receipts).abs().mean()])
 save('clock_shift',pd.DataFrame(shift,columns=['days_shift','n','level_r','change_r','delta_mae']),out)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
