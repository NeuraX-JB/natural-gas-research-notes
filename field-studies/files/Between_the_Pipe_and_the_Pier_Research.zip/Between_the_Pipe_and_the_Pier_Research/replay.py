"""Reproduce every numerical table in a fresh output directory."""
from pathlib import Path
import argparse,hashlib
import pandas as pd
import study,weeks,extra,diagnostics,sensitivity,ledger_tests

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path,nargs='?',default=Path('replayed_results'));a=parser.parse_args();out=a.output.resolve()
 if out==study.K/'results':parser.error('Use a distinct output directory for validation.')
 out.mkdir(parents=True,exist_ok=True)
 for r in pd.read_csv(study.K/'input_sha256.tsv',sep='\t').itertuples():
  if hashlib.sha256((study.K/r.file).read_bytes()).hexdigest()!=r.sha256:raise ValueError('Input hash mismatch: '+r.file)
 study.build(out)
 for module in [weeks,extra,diagnostics,sensitivity,ledger_tests]:module.main(out)
 expected=sorted((study.K/'results').glob('*.csv'))
 assert {p.name for p in expected}=={p.name for p in out.glob('*.csv')},'Different result sets'
 for p in expected:
  pd.testing.assert_frame_equal(pd.read_csv(p),pd.read_csv(out/p.name),check_dtype=False,rtol=1e-7,atol=1e-7)
 print(f'Reproduced {len(expected)} tables from the verified numerical extracts.')
if __name__=='__main__':main()
