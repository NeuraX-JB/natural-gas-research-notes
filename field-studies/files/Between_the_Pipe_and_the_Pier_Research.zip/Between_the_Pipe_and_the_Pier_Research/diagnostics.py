"""Directional counts and matched shipping-capacity comparisons."""
from pathlib import Path
import sys
import pandas as pd,numpy as np
from study import save,K
def main(out):
 w=pd.read_csv(out/'matched_weeks.csv');m=pd.read_csv(out/'monthly_receipts.csv');res=[]
 for scope in ['All eight','Texas','Louisiana','East']:
  for label,z in [('week',w[w.scope==scope]),('month',m[(m.scope==scope)&m.complete].rename(columns={'d_receipt_rate':'d_receipts','d_cargo_rate':'d_cargo','receipt_rate':'receipts','cargo_rate':'cargo'}))]:
   z=z.copy();p=z.dropna(subset=['d_receipts','d_cargo']);u=p[p.d_cargo < -1e-7];dn=int((u.d_receipts< -1e-7).sum());flat=int((u.d_receipts.abs()<=1e-7).sum());up=len(u)-dn-flat
   res.append([scope,label,len(z),len(p),len(u),dn,flat,up,z.receipts.corr(z.cargo),p.d_receipts.corr(p.d_cargo),z.receipts.sub(z.cargo).mean()])
 save('direction',pd.DataFrame(res,columns=['scope','period','levels','pairs','cargo_down','also_down','flat','up','level_r','change_r','mean_gap']),out)
 x=w[(w.scope=='All eight')&(w.ship_window_matches==1)&w.capacity_bcf.notna()&w.tracked_ships.notna()].copy();x['cargo_bcf']=7*x.cargo;x['capacity_minus_filed']=x.capacity_bcf-x.cargo_bcf;x['count_difference']=x.tracked_ships-x.calls;save('capacity_comparison',x[['end','capacity_bcf','cargo_bcf','capacity_minus_filed','tracked_ships','calls','count_difference']],out)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
