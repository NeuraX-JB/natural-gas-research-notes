"""Download into a new research directory. Never replace the edition's packaged data."""
from pathlib import Path
import argparse,csv,hashlib,urllib.request,time,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from functools import partial
A=Path(__file__).resolve().parent
def fetch(dest,rec):
 p=dest/'raw'/rec['file'];p.parent.mkdir(parents=True,exist_ok=True)
 for attempt in range(3):
  try:
   req=urllib.request.Request(rec['url'],headers={'User-Agent':'Natural Gas Research / public data consultation'})
   with urllib.request.urlopen(req,timeout=45) as response:b=response.read()
   if hashlib.sha256(b).hexdigest()!=rec['sha256']:return(rec['file'],'changed upstream')
   p.write_bytes(b);return(rec['file'],'verified')
  except Exception as e:
   if attempt<2:time.sleep(attempt+1)
   else:return(rec['file'],str(e))
def main():
 par=argparse.ArgumentParser(description=__doc__);par.add_argument('new_directory',type=Path);a=par.parse_args();dest=a.new_directory.resolve();dest.mkdir(parents=True,exist_ok=False);(dest/'kit').mkdir()
 with (A.parent/'upstream_sources.tsv').open() as f:recs=list(csv.DictReader(f,delimiter='\t'))
 with ThreadPoolExecutor(4) as ex:results=list(ex.map(partial(fetch,dest),recs))
 with (dest/'fetch_status.tsv').open('w') as f:
  writer=csv.writer(f,delimiter='\t');writer.writerow(['file','status']);writer.writerows(results)
 if any(s!='verified' for _,s in results):sys.exit('Retrieved files differ or could not be fetched. See fetch_status.tsv. The packaged numerical replay remains available.')
 for p in ['extract.py','week_extract.py','issuer_extract.py']:subprocess.run([sys.executable,str(A/p)],cwd=dest,check=True)
 print('Re-extracted the edition inputs in',dest/'kit')
if __name__=='__main__':main()
