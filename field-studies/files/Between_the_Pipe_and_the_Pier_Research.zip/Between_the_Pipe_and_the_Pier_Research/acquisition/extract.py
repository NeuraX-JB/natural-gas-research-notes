from pathlib import Path
import pandas as pd,numpy as np,zipfile,re
from lxml import html
R=Path('raw');K=Path('kit')
PORTS={'Sabine Pass, LA':'Sabine Pass','Corpus Christi, TX':'Corpus Christi','Cameron, LA':'Cameron','Cameron (Calcasieu Pass), LA':'Calcasieu Pass','Freeport, TX':'Freeport','Cove Point, MD':'Cove Point','Elba Island, GA':'Elba Island','Plaquemines, LA':'Plaquemines'}
def norm(s):return ' '.join(str(s).split())
def main():
 for y in [2025,2026]:
  d=pd.read_excel(R/f'doe{y}_3.xlsx',sheet_name=1)
  d.columns=['date','company','docket','term','activity','gas','supplier','mode','ship','port','country','mmcf','contiguous']
  d=d[(d['mode']=='Vessel')&d.port.isin(PORTS)&d.activity.isin(['Exports','Re-Exports'])].copy()
  assert d[['date','ship','mmcf']].notna().all().all() and (d.mmcf>0).all()
  d['terminal']=d.port.map(PORTS);d.ship=d.ship.map(norm);d.country=d.country.map(norm);d['row_id']=d.index+2
  d.to_csv(K/f'cargo_{y}.csv.gz',index=False)
  s=pd.read_excel(R/f'doe{y}_1.xlsx',sheet_name=1);s.columns=['month','activity','mode','gas','port','mmcf','price','contiguous']
  s=s[s.port.isin(PORTS)&s.activity.isin(['Exports','Re-Exports'])&s['mode'].eq('Vessel')&s.gas.eq('LNG')].copy();s['terminal']=s.port.map(PORTS);s.to_csv(K/f'monthly_{y}.csv.gz',index=False)
 z=zipfile.ZipFile(R/'ng176.zip');d=pd.read_csv(z.open('all_data_176.csv'),encoding='latin1',low_memory=False);names=pd.read_csv(z.open('all_company_176.csv'),encoding='latin1');d=d.merge(names,left_on='ID',right_on='COMPANY_ID');d=d[(d.YEAR>=2016)&(d.ATYPE=='VL')&(d.LINE==1240)]
 d[['YEAR','ID','AREA1','NAME1','VALUE']].rename(columns={'YEAR':'year','ID':'id','AREA1':'state','NAME1':'company','VALUE':'mcf'}).to_csv(K/'fuel_176.csv.gz',index=False)
if __name__=='__main__':main()
