from pathlib import Path
from lxml import html
import re,datetime as dt,pandas as pd,numpy as np
R=Path('raw');K=Path('kit')
def norm(s):return ' '.join(s.replace('–','-').replace('—','-').replace('‑','-').split())
def cells(tr):return [norm(c.text_content()) for c in tr.xpath('./td|./th')]
def num(s):
 try:return float(s.replace(',',''))
 except:return np.nan
def dtstr(s):return pd.to_datetime(s).strftime('%Y-%m-%d')
def regional(text,loc):
 # Only explicit levels. Do not infer a level from the week-over-week change.
 back=re.search(r'([0-9]+(?:\.\d+)?) (?:Bcf/d|billion cubic feet per day) '+loc,text,re.I)
 if back:return float(back[1])
 m=re.search(loc,text,re.I)
 if not m:return np.nan
 seg=re.split(r'(?<=[A-Za-z0-9)])\. (?=[A-Z])|,? (?:while |and )?(?:natural gas )?deliveries to terminals|, (?:and|while) ',text[m.end():],maxsplit=1,flags=re.I)[0][:250].split(';')[0]
 hits=re.findall(r'(?:\bto |\bat |\baverag(?:ed|ing) )([0-9]+(?:\.\d+)?) (?:billion cubic feet per day|Bcf/d)',seg,re.I)
 return float(hits[0]) if hits else np.nan
def parse(p):
 d=html.parse(str(p));release=p.stem;end=pd.Timestamp(release)-pd.Timedelta(days=1)
 if end.dayofweek!=2:end=end-pd.Timedelta(days=(end.dayofweek-2)%7)
 txt=norm(d.getroot().text_content());mt=re.search(r'(?:for (?:the )?week ending (?:Wednesday,? )?)([A-Za-z]+ \d{1,2},? 20\d\d)',txt,re.I)
 if mt:end=pd.Timestamp(mt[1])
 row={'release':release,'end':end.strftime('%Y-%m-%d'),'start':(end-pd.Timedelta(days=6)).strftime('%Y-%m-%d'),'table_date':False}
 for tr in d.xpath('//tr'):
  cs=cells(tr)
  if not cs:continue
  if len(cs)>=4 and re.fullmatch('LNG pipeline receipts|LNG exports|Deliveries to LNG terminals|LNG export terminals',cs[0],flags=re.I):
   row.update(receipts=num(cs[1]),previous=num(cs[2]),year_ago=num(cs[3]),row_label=cs[0])
   tbl=norm(tr.xpath('ancestor::table[1]')[0].text_content());md=re.search(r'Gas Week\s*:\s*\(?\s*(\d{1,2}/\d{1,2}/\d{2,4})\s*-\s*(\d{1,2}/\d{1,2}/\d{2,4})',tbl,re.I)
   if md:row.update(start=dtstr(md[1]),end=dtstr(md[2]),table_date=True)
 # Prefer the smallest relevant paragraph/list block to tolerate malformed HTML nesting.
 texts=[norm(z.text_content()) for z in d.xpath('//li|//p')]
 delivery=[t for t in texts if re.match('Pipeline receipts:',t,re.I)]
 if delivery:
  t=min(delivery,key=len);row['louisiana']=regional(t,'in South Louisiana');row['texas']=regional(t,'in South Texas');row['east']=regional(t,'outside (?:of )?the Gulf Coast')
  # An issue can print a narrative and a table with conflicting levels. Keep both as published.
  opening=re.split(r'\. (?=[A-Z])',t.replace('U.S.', 'United States'),maxsplit=1)[0].split('according to')[0];hits=re.findall(r'(?:averag(?:ed|ing)|to average|to|at) ([0-9]+(?:\.\d+)?) Bcf/d',opening,re.I);row['narrative_us']=float(hits[-1]) if hits and re.search(r'(?:U\.S\.|United States) LNG (?:export )?terminals',opening,re.I) and float(hits[-1])>=5 else np.nan
  for key in ['louisiana','texas','east']:
   if abs(row.get('narrative_us',np.nan)-row.get('receipts',np.nan))>.21:row[key]=np.nan
 ships=[t for t in texts if re.search('carrying capacity|carrying-capacity|combined capacit|combined LNG capacity|combined cargo capacity',t,re.I) and re.search('departed|left the United States|shipped',t,re.I) and len(t)<5400]
 if ships:
  t=min(ships,key=len)
  # Select a capacity associated with departing ships only.
  mt=re.search(r'(?:combined|aggregate|total) (?:LNG[- ]?)?(?:(?:carrying|cargo)[- ]?)?capacity of ([\d,.]+) (?:billion cubic feet|Bcf)',t,re.I)
  if not mt:mt=re.search(r'(?:(?:LNG[- ])?carrying capacity) of ([\d,.]+) (?:billion cubic feet|Bcf)',t,re.I)
  if mt:
   row['capacity']=num(mt[1]);before=re.split(r'(?<=week)\.\s+|(?<=period)\.\s+|(?<=ago)\.\s+',t[:mt.start()],flags=re.I)[-1]
   nums={'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9,'ten':10,'eleven':11,'twelve':12,'thirteen':13,'fourteen':14,'fifteen':15,'sixteen':16,'seventeen':17,'eighteen':18,'nineteen':19,'twenty':20,'thirty':30,'forty':40,'fifty':50}
   before=re.sub(r'\b(twenty|thirty|forty|fifty) (one|two|three|four|five|six|seven|eight|nine)\b',r'\1-\2',before,flags=re.I)
   g=re.search(r'(?<![\w-])([A-Za-z]+(?:-[A-Za-z]+)?|\d+)\s+(?:LNG |liquefied natural gas )?(?:vessels?|tankers?|carriers?|cargoes|ships?)\b',before,re.I)
   if g and not re.search(r'\bby (?:one|two|three|four|five|six|seven|eight|nine|ten|[0-9]+) (?:LNG )?(?:vessels?|cargoes?)',g.string[:g.end()],re.I):
    val=g[1].lower();n=int(val) if val.isdigit() else sum(nums.get(k,0) for k in val.split('-'));row['tracked_ships']=n if n>0 else np.nan
   m=re.search(r'between ([A-Z][a-z]+ \d{1,2}) and ([A-Z][a-z]+ \d{1,2}|\d{1,2})(?!\d)',t,re.I)
   if m:
    try:
     en=pd.Timestamp(row['end']);a=pd.Timestamp(m[1]+', '+str(en.year));ee=m[2] if not m[2].isdigit() else m[1].split()[0]+' '+m[2];b=pd.Timestamp(ee+', '+str(en.year))
     if a>b:a-=pd.DateOffset(years=1)
     row['ship_window_matches']=int((en-b).days==0 and (b-a).days==6)
    except ValueError:pass
 return row
if __name__=='__main__':
 rows=[parse(p) for p in sorted((R/'weeks').glob('*.html'))]
 d=pd.DataFrame(rows);d.to_csv(K/'weekly.csv',index=False);print(d.groupby(d.release.str[:4]).agg({i:'count' for i in ['end','receipts','capacity','texas','tracked_ships']}));print(d.row_label.value_counts())
