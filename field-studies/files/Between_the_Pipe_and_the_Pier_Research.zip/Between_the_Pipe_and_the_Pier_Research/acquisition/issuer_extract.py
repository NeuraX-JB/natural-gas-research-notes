from pathlib import Path
from lxml import html
import re,pandas as pd,numpy as np
R=Path('raw')
def numstr(z):return re.findall(r'\(\s*[\d,]+\s*\)|[\d,]+|[—–]',z)
def numbers(z):return [int(v.strip('() ').replace(',','')) if re.search(r'\d',v) else 0 for v in numstr(z)]
out=[]
for p in sorted((R/'issuer').glob('*.html')):
 if p.stem[:4]<'2019':continue
 d=html.parse(str(p)); trs=[' '.join(t.text_content().split()) for t in d.xpath('//tr')];cnt=next(int(re.search(r'Number of cargoes\s+(\d+)',s,re.I)[1]) for s in trs if re.search(r'^Number of cargoes\s+\d+',s,re.I))
 tbl=next(t for t in d.xpath('//table') if any(' '.join(r.text_content().split()).startswith('Volumes loaded during the current period') for r in t.xpath('./tr|./tbody/tr')))
 trs=[' '.join(r.text_content().split()) for r in tbl.xpath('.//tr')];head=' '.join(trs[:next(i for i,t in enumerate(trs) if t.startswith('Volumes loaded during'))]);commission='Commissioning' in head;total=bool(re.search(r'Commissioning\s+Total',head,re.I))
 outrow=[p.stem,cnt]
 for label in ['Volumes loaded during the current period','Volumes loaded during the prior period','Less: volumes loaded during the current period','Total volumes recognized in the current period']:
  s=next(t for t in trs if t.lower().startswith(label.lower()));nums=numbers(s);value=nums[2] if total else sum(nums[:2]) if commission else nums[0];outrow.append(value)
 out.append(outrow)
d=pd.DataFrame(out,columns=['quarter','reported_cargoes','loaded_tbtu','opening_transit_tbtu','closing_transit_tbtu','recognized_tbtu']);d['rounding']=d.recognized_tbtu-d.loaded_tbtu-d.opening_transit_tbtu+d.closing_transit_tbtu
print(d.to_string(index=False));assert d.rounding.abs().max()<=2;assert len(d)==28
d.to_csv('kit/issuer_quarters.csv',index=False)
