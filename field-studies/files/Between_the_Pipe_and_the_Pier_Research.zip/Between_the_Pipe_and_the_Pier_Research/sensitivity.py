"""Sharp conditional bounds for monthly receipt changes when only weekly means are observed."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import save,K
def main(out):
 w=pd.read_csv(out/'matched_weeks.csv',parse_dates=['start','end']).query("scope=='All eight'").reset_index(drop=True);m=pd.read_csv(out/'monthly_receipts.csv').query("scope=='All eight' and complete").copy();m=m.dropna(subset=['d_cargo_rate','d_receipt_rate'])
 records=[]
 for r in m.itertuples():
  now=pd.Period(r.month,'M');prev=now-1;spread=0
  for a in w[(w.end>=prev.start_time)&(w.start<=now.end_time)].itertuples():
   months=pd.date_range(a.start,a.end).to_period('M');weights=np.sort(np.where(months==now,1/now.days_in_month,np.where(months==prev,-1/prev.days_in_month,0)))
   spread+=a.receipts*(weights[-3:].sum()-weights[:3].sum())
  for bound in [0,.05,.10,.20,.50]:
   lo=r.d_receipt_rate-bound*spread;hi=r.d_receipt_rate+bound*spread
   records.append([r.month,r.d_cargo_rate,r.d_receipt_rate,bound,lo,hi,'down' if hi < -1e-7 else 'up' if lo>1e-7 else 'ambiguous'])
 save('month_edge_bounds',pd.DataFrame(records,columns=['month','d_cargo','d_receipts','daily_bound','low','high','direction']),out)
 rows=[]
 for year,z in [('all',w)]+[(str(yr),w[w.end.dt.year!=yr]) for yr in sorted(w.end.dt.year.unique())]:
  for threshold in [0,.25,.5,1,2]:
   sub=z[z.d_cargo< -threshold-1e-7];rows.append([year,threshold,len(sub),int((sub.d_receipts < -1e-7).sum()),int((sub.d_receipts.abs()<=1e-7).sum()),int((sub.d_receipts>1e-7).sum())])
 save('decline_sensitivity',pd.DataFrame(rows,columns=['excluded_end_year','minimum_cargo_drop','weeks','receipts_down','unchanged','up']),out)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
