"""Compare destination attribution rules and identify non-overlapping quiet episodes."""
from pathlib import Path
import sys
import pandas as pd,numpy as np
from study import getrows,save,K
def main(out):
 keys=['terminal','date','ship_key'];d=getrows()
 levels=d.groupby(keys+['country']).bcf.sum().reset_index()
 g=levels.groupby(keys).agg(n_destinations=('country','size'),ship_bcf=('bcf','sum')).reset_index()
 j=levels.merge(g,on=keys)
 largest=j.sort_values(keys+['bcf','country'],ascending=[True,True,True,False,True]).drop_duplicates(keys)
 a=j.groupby('country').agg(reported=('bcf','sum'),departures=('date','size'));a['shared_bcf']=j[j.n_destinations>1].groupby('country').bcf.sum();a['whole_ship_bcf']=largest.groupby('country').ship_bcf.sum();a=a.fillna(0);a['change']=a.whole_ship_bcf-a.reported
 assert abs(a.change.sum())<1e-6
 save('destination_attribution',a.reset_index().sort_values('reported',ascending=False),out)
 dd=pd.read_csv(out/'waiting_days.csv')
 rr=[]
 for term,c in dd.groupby('terminal'):
  for age in [3,7,14,28]:
   sub=c[c.quiet_age==age];rr.append([term,age,len(sub),int(sub.next7_calls.eq(0).sum()),sub.next7_calls.mean()])
 save('independent_gap_crossings',pd.DataFrame(rr,columns=['terminal','days_since_departure','distinct_crossings','future_seven_quiet','mean_next_week_calls']),out)
 x=pd.read_csv(out/'matched_weeks.csv').query("scope=='All eight'").copy();x['year']=x.end.str[:4]
 sub=x[x.end>='2022-01-01'].dropna(subset=['d_receipts','d_cargo']);assert len(sub)>0
 a=pd.read_csv(out/'monthly_receipts.csv').query("scope=='All eight' and complete").dropna(subset=['d_receipt_rate','d_cargo_rate']);q=a[a.month>='2022-01'].copy()
 rr=[[ 'weekly',len(sub),sub.d_receipts.corr(sub.d_cargo),(sub.d_cargo<0).sum(),((sub.d_cargo<0)&(sub.d_receipts< -1e-7)).sum() ],['monthly',len(q),q.d_receipt_rate.corr(q.d_cargo_rate),(q.d_cargo_rate<0).sum(),((q.d_cargo_rate<0)&(q.d_receipt_rate< -1e-7)).sum()]]
 save('late_sample',pd.DataFrame(rr,columns=['period','comparisons','change_r','declines','also_down']),out)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
