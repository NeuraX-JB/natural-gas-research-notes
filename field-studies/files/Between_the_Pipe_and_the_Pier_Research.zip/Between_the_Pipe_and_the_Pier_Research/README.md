# Between the Pipe and the Pier

Research companion for Natural Gas Field Studies, Book 8. Observation window January 2016 through December 2025 for cargoes, with a later DOE vintage used only to test revisions. Results and inputs are ordinary CSV or gzipped CSV, suitable for a spreadsheet, Python or DuckDB.

## Run the study

Use Python 3.11 or later with pandas and NumPy installed. From the unpacked directory run the following commands.

```sh
python -m pip install -r requirements.txt
python replay.py replayed_results
```

The runner verifies the seven numerical input hashes, reconstructs every table, and compares the rebuilt files with the published results. No network or API key is needed to replay after the dependencies are available. A different directory from the published results is required for the verification. Floating-point tolerance accommodates numerical-library differences.

## Where to begin

| File in results | What to read |
| --- | --- |
| direction.csv | Weekly and monthly cargo declines, including separately identified flat receipt estimates |
| month_edge_bounds.csv | Sharp conditional bounds for monthly receipt changes, preserving every weekly total |
| walkforward_scores.csv | Average misses, bias and paired win counts for the six methods |
| matched_weeks.csv | Current-week receipt estimate, prior-week reprint, retrospective cargo, revisions and actual published dates |
| monthly_receipts.csv | Days covered and complete-month flag. Only complete months get a receipt rate |
| closed_gaps.csv | Whole dates between consecutive active shipping dates, excluding open-ended intervals |
| waiting_outcomes.csv | Calendar-date-weighted outcomes by quiet age and terminal |
| independent_gap_crossings.csv | Distinct exact age crossings with seven subsequent observable days |
| cargo_revisions.csv | Historical keyed differences between the two DOE editions |
| issuer_bridge.csv | 28 quarters of recognized and loaded volumes, transit terms, DOE counts and reported counts |
| reported_fuel.csv | Named EIA-176 respondents and annual LNG fuel proxies |
| destination_attribution.csv | Reported parcel totals and the alternative largest-destination whole-ship allocation |

## Numerical fields and boundaries

Volumes in the DOE extracts are MMcf, millions of cubic feet of gas equivalent. Divide by 1,000 for Bcf. EIA-176 uses Mcf, thousands of cubic feet. Divide by one million for Bcf. Rates are Bcf/d. Company energy figures are TBtu. Hours of loading, actual inlet meters, supply contract covers and cargo-specific heat contents are unavailable in these extracts. Positive changes mean later minus earlier, except for explicit residuals such as the inlet-minus-cargo gap or later DOE vintage minus earlier vintage.

Cargo includes exports plus re-exports under vessel mode at the eight mapped U.S. exits. Separate activities stay in the parcel extracts. Grouping by exit, departure date and uppercased alphanumeric ship name yields named departure proxies. Sector and regional totals are separate aggregate levels. Do not sum national, regional and terminal rows together. Raw DOE row identifiers are retained for traceability within a specific edition. They are unstable as cross-vintage identifiers.

The national EIA current-week consumption-table field is used exactly as printed. Regional levels are limited to explicit values identified in narrative text. Missing levels remain missing. A numeric narrative national level conflicting with the table by over 0.21 Bcf/d suppresses those regional observations. Shipping capacity and tracked count come from a different passage. Capacity comparisons require that passage to give a complete seven-day interval ending on the same date as the table. Missing publication dates and missing previous weeks break comparisons. Week and month summary tables are based on different observation sets.

The 2025 DOE edition supplies features even in lagged tests. Those features are retrospective and have no certified first-seen timestamp. Persistence uses the prior independently printed receipt estimate. Models fit on up to the latest 52 eligible earlier pairs with at least 26. All six methods are scored on the same targets. Region-month sample sizes can be extremely small. Month-edge envelopes are scenario assumptions, not observed bounds. Distinct quiet crossings are eligible only after a 180-day startup history with seven later days present.

## Provenance and optional online extraction

sources.tsv contains the book’s numbered reading references. upstream_sources.tsv provides the hashes and source URLs for 435 weekly pages, four DOE workbooks, 28 issuer releases and the EIA-176 respondent archive. Re-fetches may encounter updated pages or annual files. The packaged numerical extracts allow this edition to be replayed independently of those changes. The company reports and weekly narratives are linked at their original publishers.

For an optional re-fetch, install the additional packages in acquisition/requirements.txt and run `python acquisition/refetch.py new_raw_run` from this directory. This creates a new folder, logs failures and publisher changes, and only re-extracts if all downloaded inputs match. For source inspection, the original workbook importer, weekly parser and issuer parser are included in acquisition/. Acquisition is optional and distinct from the offline numerical replay.

## Other output tables

departures, daily, monthly, annual, destinations and port_routes contain dated cargo and country accounts. monthly_crosscheck compares detailed DOE sums with the same edition’s summary. size_frequency gives the exact midpoint frequency and cargo-size decomposition. month_edges changes the calendar cutoff while keeping window length. waiting_days has the underlying eligible calendar dates and future call counts. horizon_scores and blocks hold the nonoverlapping horizon tests. clock_shift offsets shipping windows relative to reported receipt dates. walkforward contains each dated target and candidate. capacity_comparison compares estimated carrying capacity with filed volume. decline_sensitivity progressively raises the required cargo decline and reruns counts after excluding each target year. late_sample restricts the comparisons to targets in 2022 or later. For a positive current level and a calendar change, the previous value can come from the preceding year at a January boundary.
