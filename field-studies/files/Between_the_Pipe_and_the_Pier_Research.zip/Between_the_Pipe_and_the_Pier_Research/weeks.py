"""Join the same seven delivery dates, retain revisions and test competing signals."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import save,K
def main(out):
 daily=pd.read_csv(out/'daily.csv',parse_dates=['date'])
 w=pd.read_csv(K/'weekly.csv',parse_dates=['start','end','release']).sort_values('end')
 # Use the explicit printed table window for the receipts experiment.
 w=w[w.table_date.eq(True)&w.receipts.notna()&w.end.sub(w.start).dt.days.eq(6)].copy()
 w=w.drop_duplicates(['end'],keep='first');w['run']=w.end.diff().dt.days.ne(7).cumsum()
 dd=daily.set_index(['terminal','date']);cross=[]
 for r in w.itertuples():
  if r.start.year<2016 or r.end.year>2025:continue
  for s,c in [('All eight','receipts'),('Texas','texas'),('Louisiana','louisiana'),('East','east')]:
   val=getattr(r,c,np.nan)
   if pd.isna(val):continue
   v=dd.loc[s].loc[r.start:r.end]
   cross.append([s,r.release,r.start,r.end,val,r.previous if s=='All eight' else np.nan,v.bcf.sum()/7,v.calls.sum(),v.rows.sum(),r.capacity if s=='All eight' else np.nan,r.tracked_ships if s=='All eight' else np.nan,r.ship_window_matches if s=='All eight' else np.nan])
 x=pd.DataFrame(cross,columns=['scope','release','start','end','receipts','prior_reprint','cargo','calls','rows','capacity_bcf','tracked_ships','ship_window_matches'])
 x=x.sort_values(['scope','end']);x['run']=x.groupby('scope').end.transform(lambda v:v.diff().dt.days.ne(7).cumsum())
 for col in ['receipts','cargo','calls']:x['d_'+col]=x.groupby(['scope','run'])[col].diff()
 x['revision']=x.prior_reprint-(x.receipts-x.d_receipts);x['gap']=x.receipts-x.cargo
 save('matched_weeks',x,out)
 # Only covered dates contribute; a cross-month week's average is assigned uniformly to its seven days.
 dated=[]
 for r in x.itertuples():
  for day in pd.date_range(r.start,r.end):dated.append([r.scope,day,r.receipts,r.end])
 da=pd.DataFrame(dated,columns=['scope','date','receipt_rate','week_end']);da['month']=da.date.dt.to_period('M').astype(str);assert not da.duplicated(['scope','date']).any()
 mt=da.groupby(['scope','month']).agg(receipt_bcf=('receipt_rate','sum'),covered_days=('date','size')).reset_index();mt['days']=pd.PeriodIndex(mt.month,freq='M').days_in_month;mt['complete']=mt.days==mt.covered_days
 cargo=pd.read_csv(out/'monthly.csv').rename(columns={'terminal':'scope','bcf':'cargo_bcf'});mt=mt.merge(cargo[['scope','month','cargo_bcf','calls']],on=['scope','month']);mt['receipt_rate']=mt.receipt_bcf/mt.days;mt.loc[~mt.complete,'receipt_rate']=np.nan;mt['cargo_rate']=mt.cargo_bcf/mt.days;mt['period']=pd.PeriodIndex(mt.month,freq='M').astype('int64')
 for key in ['receipt_rate','cargo_rate']:mt['d_'+key]=mt.groupby('scope')[key].diff().where(mt.groupby('scope').period.diff().eq(1)&mt.complete&mt.groupby('scope').complete.shift().eq(True))
 save('monthly_receipts',mt,out)
 scores=[];bins=[]
 for sc,gr in x.groupby('scope'):
  for window in (1,2,4,8):
   for phase in range(window):
    v=[]
    for _,rr in gr.groupby('run'):
     z=rr.iloc[phase:].copy();z['block']=np.arange(len(z))//window
     ag=z.groupby('block').agg(end=('end','max'),n=('end','size'),receipts=('receipts','mean'),cargo=('cargo','mean'),calls=('calls','sum'));ag=ag[ag.n==window].copy()
     for name in ['cargo','receipts','calls']:ag['d_'+name]=ag[name].diff()
     v.append(ag)
    h=pd.concat(v);z=h.dropna(subset=['d_receipts','d_cargo']);nz=z[(z.d_receipts.abs()>1e-8)&(z.d_cargo.abs()>1e-8)]
    if len(z)<2:continue
    scores.append([sc,window,phase,len(h),len(z),len(nz),h.receipts.corr(h.cargo),z.d_receipts.corr(z.d_cargo),((nz.d_receipts*nz.d_cargo)>0).mean(),(z.d_receipts-z.d_cargo).abs().mean()])
    if phase==0:
     for rr in z.itertuples():bins.append([sc,window,rr.end,rr.cargo,rr.receipts,rr.d_cargo,rr.d_receipts,rr.calls])
 save('horizon_scores',pd.DataFrame(scores,columns=['scope','weeks','phase','blocks','comparisons','nonzero','level_r','change_r','sign_agreement','change_mae']),out);save('blocks',pd.DataFrame(bins,columns=['scope','weeks','end','cargo','receipts','d_cargo','d_receipts','calls']),out)
 # Walk-forward. Same-week DOE cargo is eventually known. Only methods labeled lagged exclude current cargo.
 national=x[x.scope=='All eight'].sort_values('end').copy();national['prior_r']=national.groupby('run').receipts.shift();national['prior_d_c']=national.groupby('run').d_cargo.shift()
 preds=[]
 for row in national[national.end.dt.year>=2022].itertuples():
  train=national[national.end<row.end].dropna(subset=['d_receipts','prior_d_c','d_cargo']).tail(52)
  if len(train)<26 or pd.isna(row.prior_d_c) or pd.isna(row.prior_r):continue
  slope,p0=np.polyfit(train.prior_d_c,train.d_receipts,1);s2,p2=np.polyfit(train.d_cargo,train.d_receipts,1)
  ratio=train.receipts.sum()/train.cargo.sum();bias=(train.receipts-train.cargo).mean()
  vals=[row.prior_r,row.prior_r+p0+slope*row.prior_d_c,row.cargo,row.cargo*ratio,row.cargo+bias,row.prior_r+p2+s2*row.d_cargo]
  preds.append([row.end,row.receipts,len(train),*vals])
 pred=pd.DataFrame(preds,columns=['end','actual','training_pairs','persistence','lagged_change','cargo_raw','cargo_ratio','cargo_offset','contemporaneous_change'])
 save('walkforward',pred,out)
 summ=[]
 for period,sub in [('all',pred)]+[(str(y),g) for y,g in pred.groupby(pred.end.dt.year)]:
  for method in pred.columns[3:]:
   e=sub[method]-sub.actual;summ.append([period,method,len(e),e.abs().mean(),np.sqrt((e**2).mean()),e.mean(),int((e.abs()<(sub.persistence-sub.actual).abs()-1e-10).sum())])
 save('walkforward_scores',pd.DataFrame(summ,columns=['period','method','n','mae','rmse','bias','wins_vs_persistence']),out)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
