"""Compare timing, spreadsheet units, summer baselines and the three household populations."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import K,read,put
def main(out):
 s=pd.read_csv(out/'state_months.csv');y=pd.read_csv(out/'state_years.csv');r=read('method_comparison.csv');r['days']=pd.PeriodIndex(r.month,freq='M').days_in_month;r['difference']=r.sendout_bcf-r.reported_bcf;r['diff_rate']=r.difference/r.days
 offer=read('supply.csv.gz');offer['official_bcf']=offer.mmcf/1000
 r=r.merge(offer[['state','month','official_bcf']],on=['state','month'],how='left');r.loc[r.sector=='commercial','official_bcf']=np.nan
 r['official_minus_sendout']=r.official_bcf-r.sendout_bcf
 put(out,'methods',r)
 annual=r.groupby(['state','sector']).agg(months=('difference','count'),signed_bcf=('difference','sum'),gross_bcf=('difference',lambda s:s.abs().sum()),high=('difference','max'),low=('difference','min')).reset_index();annual['within_year_offset']=1-annual.signed_bcf.abs()/annual.gross_bcf.replace(0,np.nan);put(out,'method_year',annual)
 w=read('degree_days.csv.gz');w=w[w.weighting=='StatesCONUS'].pivot(index='date',columns='area',values='hdd');w.index=pd.to_datetime(w.index)
 dr=[];fit=[]
 for (st,sec),g in r[r.state.isin(w.columns)].groupby(['state','sector']):
  g=g.dropna(subset=['sendout_bcf','reported_bcf']).sort_values('month')
  if len(g)!=12:continue
  for shift in [0,3,7,10,14,21,28]:
   z=[]
   for t in g.itertuples():
    period=pd.Period(t.month,'M');a=period.start_time.normalize()-pd.Timedelta(days=shift);b=a+pd.Timedelta(days=t.days-1);x=w[st].loc[a:b];assert len(x)==t.days and x.notna().all();z.append(x.mean())
   X=np.column_stack([np.ones(len(z)),z]);idx=np.arange(len(z))
   for target in ['sendout_bcf','reported_bcf']:
    yv=(g[target]/g.days).to_numpy();e=[]
    for j,mm in enumerate(g.month):
     keep=idx!=j;B=np.linalg.lstsq(X[keep],yv[keep],rcond=None)[0];f=X[j]@B;e.append(f-yv[j]);dr.append([st,sec,target,shift,mm,yv[j],f,z[j]])
    e=np.array(e);fit.append([st,sec,target,shift,len(e),abs(e).mean(),np.sqrt((e**2).mean()),abs(e).mean()/yv.mean()])
 put(out,'timing_months',pd.DataFrame(dr,columns=['state','sector','target','shift','month','actual_rate','estimated_rate','hdd_per_day']))
 fs=pd.DataFrame(fit,columns=['state','sector','target','shift','months','mae','rmse','relative_mae']);put(out,'timing_scores',fs)
 best=fs.sort_values(['state','sector','target','mae','shift']).drop_duplicates(['state','sector','target']);put(out,'timing_minima',best)
 ge=read('geographies.csv').dropna(subset=['division']);hh=pd.read_csv(out/'household_estimates.csv');hh=hh[hh.level=='state_postal'].rename(columns={'key':'state'})
 f=pd.read_csv(out/'summer_floor.csv').query('year==2020').merge(hh[['state','total_bcf','heat_bcf','heat_bcf_se','water_bcf','other_bcf','gas_homes_million','main_gas_million','sample_n']].rename(columns={'total_bcf':'recs_bcf'}),on='state')
 for x in ['jja','ja','jas']:f[x+'_difference']=f[x+'_heat_bcf']-f.heat_bcf
 # Share comparison distinguishes estimated end-use mix from the different survey total.
 f['utility_heat_share']=f.jja_heat_bcf/f.total_bcf;f['survey_heat_share']=f.heat_bcf/f.recs_bcf;f['share_gap_pp']=(f.utility_heat_share-f.survey_heat_share)*100;put(out,'floor_vs_survey',f)
 a=read('acs.csv').merge(read('customers.csv.gz'),on=['year','state'],how='left');a['account_minus_primary']=a.customers-a.gas_primary;a['primary_share']=a.gas_primary/a.occupied;a['electric_share']=a.electric_primary/a.occupied;put(out,'customer_populations',a)
 # National totals and signed calendar differences must preserve how geographic additions offset.
 z=r[r.state.isin(ge.state)].groupby(['month','sector']).agg(n=('difference','count'),net=('difference','sum'),gross=('difference',lambda x:x.abs().sum()),sum_sendout=('sendout_bcf','sum'),sum_reported=('reported_bcf','sum')).reset_index();z['opposing_offset']=(z.gross-z.net.abs())/2;put(out,'spatial_offset',z)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
