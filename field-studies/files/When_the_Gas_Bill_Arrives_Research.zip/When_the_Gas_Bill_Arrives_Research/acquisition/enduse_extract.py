from pathlib import Path
import pandas as pd,numpy as np
R=Path('raw');K=Path('kit');rows=[]
for num,lab in [(11,'all'),(12,'heat'),(13,'water')]:
 workbook=pd.ExcelFile(R/f'recs_m{num}.xlsx');d=pd.read_excel(workbook,sheet_name='physical units',header=None)
 for i in range(4,len(d)):
  if pd.isna(d.iloc[i,1]) or not isinstance(d.iloc[i,0],str):continue
  area=d.iloc[i,0].strip()
  for j in range(2,15):
   v=d.iat[i,j];status='numeric' if isinstance(v,(int,float)) and pd.notna(v) else str(v).strip()
   rows.append([area,lab,j-2,pd.to_numeric(v,errors='coerce'),status])
pd.DataFrame(rows,columns=['area','end_use','month_number','bcf','status']).to_csv(K/'recs_monthly_2020.csv',index=False)
