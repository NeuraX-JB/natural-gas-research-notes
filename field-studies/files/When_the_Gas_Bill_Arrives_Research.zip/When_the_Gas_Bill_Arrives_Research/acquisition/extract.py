from pathlib import Path
import pandas as pd,numpy as np,re,calendar,xlrd
R=Path('raw');K=Path('kit')
DIV={1:'CT ME MA NH RI VT',2:'NJ NY PA',3:'IL IN MI OH WI',4:'IA KS MN MO NE ND SD',5:'DE FL GA MD NC SC VA WV',6:'AL KY MS TN',7:'AR LA OK TX',8:'AZ CO ID MT NV NM UT WY',9:'CA OR WA'}
NAMES=['New England','Middle Atlantic','East North Central','West North Central','South Atlantic','East South Central','West South Central','Mountain','Pacific']
STATES='AL Alabama|AK Alaska|AZ Arizona|AR Arkansas|CA California|CO Colorado|CT Connecticut|DE Delaware|DC District of Columbia|FL Florida|GA Georgia|HI Hawaii|ID Idaho|IL Illinois|IN Indiana|IA Iowa|KS Kansas|KY Kentucky|LA Louisiana|ME Maine|MD Maryland|MA Massachusetts|MI Michigan|MN Minnesota|MS Mississippi|MO Missouri|MT Montana|NE Nebraska|NV Nevada|NH New Hampshire|NJ New Jersey|NM New Mexico|NY New York|NC North Carolina|ND North Dakota|OH Ohio|OK Oklahoma|OR Oregon|PA Pennsylvania|RI Rhode Island|SC South Carolina|SD South Dakota|TN Tennessee|TX Texas|UT Utah|VT Vermont|VA Virginia|WA Washington|WV West Virginia|WI Wisconsin|WY Wyoming|PR Puerto Rico'
FIPS='01 02 04 05 06 08 09 10 11 12 13 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 44 45 46 47 48 49 50 51 53 54 55 56 72'.split()
def write(n,d):d.to_csv(K/n,index=False,compression='infer')
def wide(n,key):
 a=pd.read_excel(R/(n+'.xls'),sheet_name=1,header=None);codes=[('US' if '_NUS_' in s else re.search(r'_S([A-Z]{2})_',s)[1]) if n=='customers' else re.search('N3010([A-Z]{2})2',s)[1] for s in a.iloc[1,1:]]
 d=a.iloc[3:].copy();d.columns=['date',*codes];d['date']=pd.to_datetime(d.date);d['year']=d.date.dt.year;d=d[(d.year>=2000)&(d.year<=2025)]
 d['month']=d.date.dt.strftime('%Y-%m');d=d.melt(id_vars=['month','year'],value_vars=codes,var_name='state',value_name=key);d[key]=pd.to_numeric(d[key],errors='coerce');return d.drop(columns=['year' if n=='supply' else 'month'])
def main():
 st=pd.DataFrame([s.split(' ',1) for s in STATES.split('|')],columns=['state','name']);st['fips']=FIPS;st['division']=st.state.map({s:i for i,ss in DIV.items() for s in ss.split()});st['division_name']=st.division.map(dict(enumerate(NAMES,1)));write('geographies.csv',st)
 for n,key in [('supply','mmcf'),('annual','mmcf'),('customers','customers')]:write(n+'.csv.gz',wide(n,key))
 ww=[]
 for path in sorted(R.glob('cpc_*.txt')):
  kind=path.stem.split('_')[-1];d=pd.read_csv(path,sep='|',skiprows=3,dtype={'Region':str});d=d.rename(columns={'Region':'area'}).melt(id_vars='area',var_name='date',value_name='hdd').dropna(subset=['hdd']);d=d[d.date.str.fullmatch(r'\d{8}')];d['date']=pd.to_datetime(d.date,format='%Y%m%d');d['weighting']=kind;ww.append(d)
 w=pd.concat(ww);assert not w.duplicated(['weighting','area','date']).any();print('HDD min max',w.hdd.min(),w.hdd.max());w=w[w.hdd.between(0,130)].copy();write('degree_days.csv.gz',w.sort_values(['weighting','area','date']))
 wb=xlrd.open_workbook(str(R/'methods.xls'),formatting_info=True);rows=[]
 for idx,sector in [(1,'residential'),(2,'commercial')]:
  sheet=wb.sheet_by_index(idx);hdr=pd.read_excel(R/'methods.xls',sheet_name=idx,header=None)
  for j in range(1,len(hdr.columns),2):
   month=pd.to_datetime(str(hdr.iat[2,j]).replace('Febuary','February')).strftime('%Y-%m')
   for i in range(4,len(hdr)):
    area=str(hdr.iat[i,0]).strip().replace('US Total','US')
    if month<'2025-01' or month>'2025-12':continue
    vals=[]
    for k in [j,j+1]:
     raw=pd.to_numeric(hdr.iat[i,k],errors='coerce')
     if pd.notna(raw):
      fmt=wb.format_map[wb.xf_list[sheet.cell_xf_index(i,k)].format_key].format_str
      assert fmt.endswith(','),(fmt,area,month)
     vals.append(raw/1e6)
    rows.append([area,month,sector,*vals])
 write('method_comparison.csv',pd.DataFrame(rows,columns=['state','month','sector','sendout_bcf','reported_bcf']))
 ac=[]
 for p in sorted(R.glob('acs_*.dat')):
  yr=int(p.stem[-4:]);d=pd.read_csv(p,sep='|');d=d[d.GEO_ID.str.fullmatch('0400000US[0-9]{2}|0100000US')].copy()
  d['state']=d.GEO_ID.str[-2:].map(dict(zip(FIPS,st.state))).fillna('US');d['year']=yr
  fields=['B25040_'+x for x in ['E001','M001','E002','M002','E004','M004']];a=d[['state','year']+fields].copy();a.columns=['state','year','occupied','moe_occupied','gas_primary','moe_gas','electric_primary','moe_electric'];ac.append(a)
 write('acs.csv',pd.concat(ac))
 fields=['state_postal','REGIONC','TYPEHUQ','YEARMADERANGE','EQUIPM','FUELHEAT','USENG','UGWARM','UGWATER','UGCOOK','HDD65','TOTSQFT_EN','CUFEETNG','CUFEETNGSPH','CUFEETNGWTH','CUFEETNGOTH','BTUNG','BTUNGSPH','NWEIGHT']+[f'NWEIGHT{i}' for i in range(1,61)]
 s=pd.read_csv(R/'recs20.csv',usecols=fields);write('homes_2020.csv.gz',s[fields])
if __name__=='__main__':main()
