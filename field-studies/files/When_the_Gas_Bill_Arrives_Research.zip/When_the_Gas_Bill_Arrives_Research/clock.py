"""Reveal the target month's observed degree days progressively, holding model coefficients fixed."""
from pathlib import Path
import sys,calendar,numpy as np,pandas as pd
from study import read,put,K
def main(out):
 raw=read('degree_days.csv.gz');raw=raw[raw.weighting=='StatesCONUS'].copy()
 raw['month']=raw.date.str[:7];raw['day']=raw.date.str[-2:].astype(int)
 daily=raw.pivot(index=['area','month'],columns='day',values='hdd')
 series=pd.read_csv(out/'state_months.csv');allrecs=[];windows=[]
 for st,g in series.groupby('state'):
  g=g.sort_values('month').reset_index(drop=True);dates=g.month.to_list();nd=g.days.to_numpy();mo=g.season_month.to_numpy();h=g.hd.to_numpy();yp=g.rate.to_numpy()
  vals=daily.loc[st].reindex(dates).to_numpy();lag=np.r_[np.nan,h[:-1]];X=np.column_stack([h,lag])
  for t in range(132,len(g)):
   for length in [36,60,120]:
    ix=np.arange(t-length-2,t-2);ms=mo[ix];same=ms==mo[t];dy=yp[ix].copy();dx=X[ix].copy()
    for m in range(1,13):
     ok=ms==m;dy[ok]-=dy[ok].mean();dx[ok]-=dx[ok].mean(axis=0)
    coef=np.linalg.lstsq(dx,dy,rcond=None)[0];base=yp[ix][same].mean();cx=X[ix][same].mean(axis=0)
    pred=lambda hh:max(0,base+coef@([hh,lag[t]]-cx));windows.append([st,dates[t],length,yp[t],base,pred(h[t])])
    if length!=60:continue
    prev=t-12*np.arange(1,6);mat=vals[prev,:nd[t]];count=np.isfinite(mat).sum(axis=0)
    normal=np.divide(np.nansum(mat,axis=0),count,out=np.zeros(nd[t]),where=count>0)
    if np.any(count==0):normal[count==0]=normal[27]
    for cut in [0,7,14,21,99]:
     k=min(cut,nd[t]);hh=(vals[t,:k].sum()+normal[k:].sum())/nd[t]
     allrecs.append([st,dates[t],cut,yp[t],pred(hh),hh])
 x=pd.DataFrame(allrecs,columns=['state','month','elapsed_days','actual','estimate','hdd_day_used']);put(out,'weather_clock_states',x)
 n=x.groupby(['elapsed_days','month'])[['actual','estimate']].sum().reset_index();put(out,'weather_clock_national',n)
 p=pd.DataFrame(windows,columns=['state','month','training_months','actual','seasonal','weather']);agg=p.groupby(['training_months','month'])[['actual','seasonal','weather']].sum().reset_index();put(out,'training_windows',agg)
 r=[]
 for (cut),z in n.groupby('elapsed_days'):
  for season,sub in [('all',z),('winter',z[z.month.str[-2:].isin(['11','12','01','02','03'])])]:
   e=sub.estimate-sub.actual;r.append([cut,season,len(e),e.abs().mean(),np.sqrt(np.mean(e**2)),e.mean()])
 put(out,'weather_clock_scores',pd.DataFrame(r,columns=['elapsed_days','season','months','mae','rmse','bias']))
 # End of month must equal the independently implemented state weather plus lag model.
 old=pd.read_csv(out/'national_predictions.csv').query("scale=='state'").sort_values('month')
 assert np.allclose(old.pop_lag,n[n.elapsed_days==99].sort_values('month').estimate,atol=1e-7)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
