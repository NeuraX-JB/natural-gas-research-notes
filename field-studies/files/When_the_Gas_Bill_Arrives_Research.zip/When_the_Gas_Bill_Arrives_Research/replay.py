"""Repeat the numerical study and compare every output with the one used in the book."""
from pathlib import Path
import argparse,hashlib
import pandas as pd
import study,homes,timing,enduses,analogs,clock,slopes,paired

def main():
 pa=argparse.ArgumentParser(description=__doc__);pa.add_argument('output',nargs='?',type=Path,default=Path('replayed_results'));args=pa.parse_args();dest=args.output.resolve()
 if dest==study.K/'results':pa.error('Choose a different output directory for verification.')
 dest.mkdir(parents=True,exist_ok=True)
 for r in pd.read_csv(study.K/'input_sha256.tsv',sep='\t').itertuples():
  assert hashlib.sha256((study.K/r.file).read_bytes()).hexdigest()==r.sha256, r.file
 for module in [study,homes,timing,enduses,analogs,clock,slopes,paired]:module.main(dest)
 gold=sorted((study.K/'results').glob('*.csv'));assert {q.name for q in gold}=={q.name for q in dest.glob('*.csv')}
 for p in gold:
  pd.testing.assert_frame_equal(pd.read_csv(p),pd.read_csv(dest/p.name),check_dtype=False,atol=1e-7,rtol=1e-7)
 print(f'Reproduced {len(gold)} result tables from nine verified numerical extracts.')
if __name__=='__main__':main()
