"""Weighted household end uses, sampling errors, and a common-support vintage comparison."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import read,put,K
W=['NWEIGHT']+[f'NWEIGHT{i}' for i in range(1,61)]
def estimate(x):
 x=np.asarray(x);return (x[0],np.sqrt(59/60*np.sum((x[1:]-x[0])**2))) if np.isfinite(x).all() else (x[0],np.nan)
def main(out):
 d=read('homes_2020.csv.gz');g=read('geographies.csv').dropna(subset=['division']);d['scope']=np.where(d.state_postal.isin(g.state),'48 states','Other');d['group']=np.select([d.FUELHEAT==1,d.UGWARM==1,d.USENG==1],['Main gas heat','Other main fuel, gas heat also used','Gas use without gas space heating'],default='No natural gas')
 d['form']=d.TYPEHUQ.map({1:'Mobile',2:'Detached',3:'Attached',4:'Apartment, 2–4 units',5:'Apartment, 5+ units'})
 d['vintage']=pd.cut(d.YEARMADERANGE,[0,2,5,7,9],labels=['Before 1960','1960–1989','1990–2009','2010–2020']).astype(str)
 d['size_band']=pd.cut(d.TOTSQFT_EN,[-1,999,1499,1999,2499,3499,99999],labels=['Under 1,000','1,000–1,499','1,500–1,999','2,000–2,499','2,500–3,499','3,500+']).astype(str)
 d['weather_band']=pd.cut(d.HDD65,[-1,1499,2999,4499,5999,7499,99999],labels=['Under 1,500','1,500–2,999','3,000–4,499','4,500–5,999','6,000–7,499','7,500+']).astype(str)
 cols=['homes_million','gas_homes_million','main_gas_million','total_bcf','heat_bcf','water_bcf','other_bcf','heat_share','mcf_per_gas_home','heat_mcf_per_gas_home','mean_hdd','mean_sqft']
 rows=[]
 def report(level,name,sub):
  w=sub[W].to_numpy();ng=(sub.USENG.to_numpy()==1);main=sub.FUELHEAT.to_numpy()==1
  values=sub[['CUFEETNG','CUFEETNGSPH','CUFEETNGWTH','CUFEETNGOTH']].to_numpy().T@w/1e7
  n=w.sum(axis=0);users=w[ng].sum(axis=0);main_n=w[main].sum(axis=0)
  ratio=lambda a,b:np.divide(a,b,out=np.full(61,np.nan),where=b!=0)
  ts=[n/1e6,users/1e6,main_n/1e6,*values,ratio(values[1],values[0]),ratio(values[0]*1e6,users),ratio(values[1]*1e6,users),ratio(sub.HDD65.to_numpy()@w,n),ratio(sub.TOTSQFT_EN.to_numpy()@w,n)]
  rows.append([level,str(name),len(sub),*sum((list(estimate(t)) for t in ts),[])])
 report('universe','US',d);report('universe','48 states',d[d.scope=='48 states'])
 for level in ['state_postal','REGIONC','group','form','vintage','size_band','weather_band']:
  for name,sub in d.groupby(level):report(level,name,sub)
 for keys,sub in d.groupby(['REGIONC','group']):report('region_group',' / '.join(keys),sub)
 for level in ['form','vintage','size_band','weather_band']:
  for keys,sub in d[d.FUELHEAT==1].groupby(['REGIONC',level]):report('main_gas_'+level,' / '.join(keys),sub)
 result=pd.DataFrame(rows,columns=['level','key','sample_n',*[k for c in cols for k in [c,c+'_se']]]);put(out,'household_estimates',result)
 # Distinguish common support from the full cohort difference. Fixed strata selected on unweighted samples.
 c=d[(d.FUELHEAT==1)&(d.TYPEHUQ==2)&((d.YEARMADERANGE<=3)|(d.YEARMADERANGE>=7))].copy();c['cohort']=np.where(c.YEARMADERANGE<=3,'before 1970','2000 onward');allrows=[];matched=[]
 for weather_width,area_width,min_n in [(1500,750,3),(1500,750,5),(1000,500,3),(2000,1000,5)]:
  c['weather']=(c.HDD65//weather_width).astype(int);c['size']=(c.TOTSQFT_EN//area_width).astype(int);den=np.zeros(61);old=np.zeros(61);new=np.zeros(61);nold=nnew=0;nc=0
  for (region,h,f),s in c.groupby(['REGIONC','weather','size']):
   aa=s[s.cohort=='before 1970'];bb=s[s.cohort=='2000 onward']
   if min(len(aa),len(bb))<min_n:continue
   def calc(z):
    w=z[W].to_numpy();weight=w.sum(axis=0);return weight,(z.CUFEETNGSPH.to_numpy()/10@w)/weight
   wa,ma=calc(aa);wb,mb=calc(bb);ww=wa+wb;nc+=1;nold+=len(aa);nnew+=len(bb);den+=ww;old+=ma*ww;new+=mb*ww
   matched.append([weather_width,area_width,min_n,region,int(h)*weather_width,int(f)*area_width,len(aa),len(bb),ww[0],ma[0],mb[0]])
  def crude(cohort):
   s=c[c.cohort==cohort];return (s.CUFEETNGSPH.to_numpy()/10@s[W].to_numpy())/s[W].sum().to_numpy()
  A=old/den;B=new/den;ca=crude('before 1970');cb=crude('2000 onward')
  allrows.append([weather_width,area_width,min_n,nc,nold,nnew,den[0]/1e6,ca[0],cb[0],*estimate(cb-ca),A[0],B[0],*estimate(B-A)])
 put(out,'matched_homes',pd.DataFrame(allrows,columns=['hdd_width','sqft_width','min_each','cells','n_old','n_new','represented_million','crude_old','crude_new','crude_difference','crude_se','common_old','common_new','common_difference','common_se']))
 put(out,'home_cells',pd.DataFrame(matched,columns=['hdd_width','sqft_width','min_each','region','hdd_floor','sqft_floor','n_old','n_new','pooled_weight','old_heat_mcf','new_heat_mcf']))
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
