from pathlib import Path
import sys,pandas as pd,numpy as np
from study import read,put,K
def main(out):
 d=read('recs_monthly_2020.csv');w=d.pivot(index=['area','month_number'],columns='end_use',values='bcf').reset_index();w['other']=w['all']-w.heat-w.water
 p=w[w.month_number>0].copy();p['days']=pd.PeriodIndex('2020-'+p.month_number.astype(str).str.zfill(2),freq='M').days_in_month
 rec=[]
 for area,g in p.groupby('area'):
  total=w[(w.area==area)&w.month_number.eq(0)].iloc[0];summ=g[g.month_number.isin([6,7,8])];rows=[area,total['all'],total.heat,total.water,summ.heat.sum(min_count=3)]
  if len(summ)==3 and not summ[['all','heat']].isna().any().any():
   total_floor=total['all']-summ['all'].sum()/92*366
   summer_heat_penalty=-summ.heat.sum()/92*366
   nonheat_term=total['all']-total.heat-(summ['all']-summ.heat).sum()/92*366
   assert np.isclose(total_floor-total.heat,nonheat_term+summer_heat_penalty)
   rows.extend([total_floor,total_floor-total.heat,summer_heat_penalty,nonheat_term])
  else:rows.extend([np.nan]*4)
  rec.append(rows)
 put(out,'survey_monthly',w);put(out,'within_survey_floor',pd.DataFrame(rec,columns=['area','annual_total','annual_heat','annual_water','summer_heat','jja_proxy','proxy_error','summer_heat_effect','nonheat_season_effect']))
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
