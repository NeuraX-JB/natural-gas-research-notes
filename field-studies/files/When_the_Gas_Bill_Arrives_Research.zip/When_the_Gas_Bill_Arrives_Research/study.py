"""Rebuild the monthly state, divisional and 48-state residential gas experiments."""
from pathlib import Path
import sys,numpy as np,pandas as pd
K=Path(__file__).resolve().parent
def read(n):return pd.read_csv(K/n)
def put(out,n,d):d.to_csv(out/(n+'.csv'),index=False,float_format='%.9f')
def monthly_weather():
 w=read('degree_days.csv.gz');w['month']=w.date.str[:7];w['day']=w.date.str[-2:].astype(int)
 ag=w.groupby(['weighting','area','month']).agg(hdd=('hdd','sum'),n=('hdd','size'),peak=('hdd','max'),cold_days=('hdd',lambda s:(s>=30).sum())).reset_index()
 ag['days']=pd.PeriodIndex(ag.month,freq='M').days_in_month;ag.loc[ag.days!=ag.n,['hdd','peak','cold_days']]=np.nan
 return ag
def prepare(out):
 g=read('geographies.csv').dropna(subset=['division']);g['division']=g.division.astype(int).astype(str)
 w=monthly_weather();put(out,'weather_months',w)
 s=read('supply.csv.gz').merge(g[['state','division']],on='state');s['bcf']=s.mmcf/1000
 s=s.merge(w[w.weighting=='StatesCONUS'].drop(columns='weighting'),left_on=['state','month'],right_on=['area','month'],validate='one_to_one');s['rate']=s.bcf/s.days;s['hd']=s.hdd/s.days;s['year']=s.month.str[:4].astype(int);s['season_month']=s.month.str[-2:].astype(int)
 put(out,'state_months',s)
 def aggregate(group,scope):
  sizes=g.groupby('division').size() if group=='division' else None
  a=s.groupby([group,'month'],as_index=False).agg(bcf=('bcf','sum'),n=('bcf','count'))
  assert (a.n==(a[group].map(sizes) if sizes is not None else 48)).all()
  a=a.rename(columns={group:'area'});q=w[w.weighting.isin(['Population','UtilityGas'])].pivot(index=['area','month'],columns='weighting',values='hdd').reset_index()
  a=a.merge(q,on=['area','month'],validate='one_to_one');a['scale']=scope;a['days']=pd.PeriodIndex(a.month,freq='M').days_in_month;a['rate']=a.bcf/a.days
  return a
 s['national']='CONUS';a=aggregate('national','national');b=aggregate('division','division');c=s[['month','state','bcf','hdd','days','rate']].rename(columns={'state':'area','hdd':'Population'});c['scale']='state';c['UtilityGas']=np.nan;d=pd.concat([a,b,c],ignore_index=True)
 for key in ['Population','UtilityGas']:d[key]=d[key]/d.days
 return s,d
def train_forecasts(out,d):
 pred=[]
 for (sc,area),g in d.groupby(['scale','area']):
  g=g.sort_values('month').reset_index(drop=True);assert len(g)==312
  y=g.rate.to_numpy();nmo=g.month.str[-2:].astype(int).to_numpy();gas=g.UtilityGas.to_numpy();pop=g.Population.to_numpy()
  for t in range(132,len(g)):
   ix=np.arange(t-62,t-2);assert len(ix)==60;ms=nmo[ix];same=ms==nmo[t];base=y[ix][same].mean()
   def calc(X):
    if not np.isfinite(X[ix]).all() or not np.isfinite(X[t]).all():return np.nan
    dy=y[ix].copy();dx=X[ix].copy()
    for mo in range(1,13):
     sel=ms==mo;dy[sel]-=dy[sel].mean();dx[sel]-=dx[sel].mean(axis=0)
    coef=np.linalg.lstsq(dx,dy,rcond=None)[0];return max(0,base+(X[t]-X[ix][same].mean(axis=0))@coef)
   p=calc(pop[:,None]);pu=calc(gas[:,None]) if sc!='state' else np.nan
   lag=np.column_stack([pop,np.r_[np.nan,pop[:-1]]]);pl=calc(lag)
   if sc!='state':
    gp=np.column_stack([gas,np.r_[np.nan,gas[:-1]]]);gl=calc(gp)
   else:gl=np.nan
   pred.append([sc,area,g.month[t],int(g.days[t]),y[t],base,p,pu,pl,gl])
 pr=pd.DataFrame(pred,columns=['scale','area','month','days','actual','seasonal','pop','gas','pop_lag','gas_lag']);put(out,'predictions',pr)
 # Summing a 48-state or nine-division model must preserve geographic coverage.
 cols=['actual','seasonal','pop','gas','pop_lag','gas_lag'];sumrows=[]
 for sc,g in pr.groupby('scale'):
  n={'state':48,'division':9,'national':1}[sc]
  a=g.groupby('month')[cols].sum(min_count=n).reset_index();a['scale']=sc;sumrows.append(a)
 totals=pd.concat(sumrows);pp=totals.pivot(index='month',columns='scale',values='actual');assert np.nanmax(np.ptp(pp.values,axis=1))<1e-6
 put(out,'national_predictions',totals)
 scores=[]
 def score(sg,label,sector):
  for filt,sub in [('all',sg),('winter',sg[sg.month.str[-2:].isin(['11','12','01','02','03'])]),('warm',sg[~sg.month.str[-2:].isin(['11','12','01','02','03'])])]:
   for co in cols[1:]:
    h=sub.dropna(subset=[co,'actual','seasonal']);e=h[co]-h.actual
    if h.empty:continue
    scores.append([label,sector,filt,co,len(h),e.abs().mean(),(e**2).mean()**.5,e.mean(),(h.seasonal-h.actual).abs().mean(),(e.abs()<(h.seasonal-h.actual).abs()-1e-9).sum()])
 for (sc,area),g in pr.groupby(['scale','area']):score(g,sc,str(area))
 for sc,g in totals.groupby('scale'):score(g,'summed',sc)
 put(out,'scores',pd.DataFrame(scores,columns=['scale','area','season','model','months','mae','rmse','bias','paired_base_mae','wins']))
 return pr,totals
def annual_study(out,s):
 a=read('annual.csv.gz').rename(columns={'mmcf':'annual_mmcf'});c=read('customers.csv.gz');m=s.groupby(['state','year']).agg(monthly_bcf=('bcf','sum'),days=('days','sum'),annual_hdd=('hdd','sum'),winter_bcf=('bcf',lambda g:g[s.loc[g.index,'season_month'].isin([1,2,3,11,12])].sum())).reset_index();m=m.merge(a,how='left',on=['state','year']).merge(c,on=['state','year'],how='left');m['annual_bcf']=m.annual_mmcf/1000;m['check']=m.monthly_bcf-m.annual_bcf;m['mcf_per_consumer']=m.annual_bcf*1e6/m.customers
 put(out,'state_years',m)
 de=[]
 for state,g in m.groupby('state'):
  for start,end in [(2000,2010),(2010,2020),(2000,2024),(2015,2024),(2020,2024)]:
   a=g[g.year==start].iloc[0];b=g[g.year==end].iloc[0];base=(b.customers-a.customers)*(b.mcf_per_consumer+a.mcf_per_consumer)/2e6;intens=(b.mcf_per_consumer-a.mcf_per_consumer)*(a.customers+b.customers)/2e6
   de.append([state,start,end,a.customers,b.customers,a.mcf_per_consumer,b.mcf_per_consumer,b.annual_bcf-a.annual_bcf,base,intens,b.annual_hdd-a.annual_hdd])
 q=pd.DataFrame(de,columns=['state','start','end','customers_start','customers_end','intensity_start','intensity_end','delta_bcf','count_effect','intensity_effect','hdd_change']);assert np.allclose(q.delta_bcf,q.count_effect+q.intensity_effect);put(out,'volume_decomposition',q)
 # Stretch summer gas rates over a full year as a deliberately simplified end-use proxy.
 floor=[]
 for (st,year),g in s.groupby(['state','year']):
  b=g.bcf.sum();h={}
  for label,mos in [('jja',[6,7,8]),('ja',[7,8]),('jas',[7,8,9])]:
   f=g[g.season_month.isin(mos)];h[label]=b-f.bcf.sum()/f.days.sum()*g.days.sum()
  floor.append([st,year,b,*h.values()])
 put(out,'summer_floor',pd.DataFrame(floor,columns=['state','year','total_bcf','jja_heat_bcf','ja_heat_bcf','jas_heat_bcf']))
def main(out):
 out.mkdir(parents=True,exist_ok=True);s,d=prepare(out);train_forecasts(out,d);annual_study(out,s)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
