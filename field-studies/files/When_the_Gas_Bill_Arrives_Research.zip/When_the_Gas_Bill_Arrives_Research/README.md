# When the Gas Bill Arrives

Book Nine of Natural Gas Field Studies. This companion contains nine numerical source extracts, the original study programs and thirty-one result tables. The book and the computations use data available by November 24, 2026. The main utility and weather study ends in December 2025. No energy-market API key is required.

## Reproduce the results

Use Python 3.11 or later. From inside this unpacked directory, run the following commands.

```sh
python -m pip install -r requirements.txt
python replay.py replayed_results
```

After the dependencies are installed the replay runs offline. The runner verifies the nine input fingerprints, rebuilds all result tables in the specified directory and compares them to those used for publication. A small numerical tolerance accommodates floating-point libraries. The companion retains complete outputs. No need to install plotting or spreadsheet software to reproduce the calculations. The largest data set contains public anonymized household survey fields and weights.

## Start with a research question

| Question | Result files under results/ |
| --- | --- |
| How much did the U.S. residential figure change under the two 2025 methods? | methods.csv for state, month and sector. method_year.csv for signed and gross sums. spatial_offset.csv for offsetting state movements |
| How much does the time of the weather observation matter? | weather_clock_scores.csv, weather_clock_national.csv and weather_clock_states.csv |
| What is gained by state detail, gas-weighted weather, or the previous month’s temperature? | scores.csv, predictions.csv and national_predictions.csv. paired_uncertainty.csv, paired_by_year.csv and training_windows.csv for sensitivity |
| Which lag best fits reporting in a given state? | timing_scores.csv, timing_months.csv and timing_minima.csv |
| Are fewer cubic feet per customer evidence of less response to cold? | state_years.csv, volume_decomposition.csv, period_slopes.csv and two_month_response.csv |
| How do a customer and a gas-heated household differ? | customer_populations.csv, household_estimates.csv and household_fields.csv in the main directory for RECS definitions |
| How does a summer-baseline shortcut perform? | summer_floor.csv, floor_vs_survey.csv, survey_monthly.csv and within_survey_floor.csv |
| Does the newer-homes gap survive grouping by geography, weather and floor area? | matched_homes.csv and home_cells.csv |
| Where did similar national HDD conceal different demand? | weather_analogs.csv (filter disjoint), winter_scores.csv |
| Which raw months and weather observations underlie the experiments? | state_months.csv and weather_months.csv. For daily weather see degree_days.csv.gz in the main directory |

## Geographic scope and time basis

The EIA and ACS U.S. rows use the publisher's full national coverage. The 48-state experiments sum the contiguous states and exclude the District of Columbia. NOAA supplies 48 state rows in its state population product. NOAA national and divisional indexes retain their published geographic, population and home heating fuel weights. NOAA's separate division products are not state-level gas-weighted observations. The survey can be summarized for all U.S. homes or the comparable 48-state boundary. 2020 household end-use tables are retrospective estimates, released later. There are 14,976 contiguous-state months over 2000–2025. The primary model test covers exactly 180 months starting in January 2011.

Gas deliveries are Bcf per month, with monthly rates divided by actual calendar days. The natural gas comparison workbook's raw numeric entries use a trailing comma in the Excel display format. Raw value / 1,000,000 gives Bcf; the comparison extracts already carry Bcf. The ordinary EIA volume extracts are MMcf as stored. A million Mcf is one Bcf. Annual EIA average customer counts run through 2024 in the workbook used. ACS includes one-year estimates and their reported margins. Gas primary means the fuel the household uses most for heating. It omits gas used only for other purposes.

RECS CUFEET gas quantities are in hundreds of cubic feet, so divide by ten for Mcf per home. BTU energy fields in the public microdata are in thousands of Btu. Infer end-use volumes by weighting sampled records with NWEIGHT. The sixty jackknife weights give sampling standard errors, with (59/60) times the sum of squared differences against the full estimate for the variance. Small subgroups can have undefined replicate statistics. The point estimate is retained if possible. The matched-cohort strata are fixed across replicates. No causal retrofit or efficiency estimate is computed.

## Methods and timing

The paired-method experiment uses the 2025 residential and commercial sheets of the same EIA workbook. A positive adjustment means sendout less reported. The timing lines fit a separate intercept and weather slope to eleven months of a completed year and test the twelfth. A positive shift measures weather that many days **earlier** than the gas month. The minimum is selected over seven candidates. It is an explanatory diagnostic, not independent validation of the selected offset.

Primary forward-order fits use 60 training months ending three months before the target. Month effects and coefficients are calculated from training data only. Selectable models use realized current-month HDD per day and, where specified, prior-month HDD per day. Each geometry uses its own coefficients. A summed national error adds signed state or division errors before taking an absolute value. Some source vintages and immediate daily availability cannot be verified retrospectively. These are conditional hindcasts, not proof of real-time trading performance.

The staged clock fills future dates with means from the same dates in the previous five calendar years. The complete-month cutoff is coded 99 and clips to month length. The existing first-day baseline is one estimate per target, with zero target dates observed. The weather model includes prior-month weather at all stages. It does not use a commercial forecast, ECMWF or GFS. Missing official values are never replaced by a model estimate for scoring. The year-block comparison uses a NumPy random generator seeded with 2409 for 20,000 draws of fifteen calendar years, resampling paired errors but leaving the original predictions fixed.

Aligned goal for slopes: within-calendar-month differences remove the simple January-versus-July seasonal relationship. period_slopes.csv gives single-current-month responses; the per-consumer entry has Mcf units per HDD, so multiply by 1,000 for cubic feet. two_month_response.csv already reports cubic feet. A sustained change in both weather rates activates both fitted terms. The 2001–2009 and 2015–2024 comparison straddles the EIA measurement change; 2011–2017 and 2018–2024 do not.

## Primary data and optional re-extraction

sources.tsv lists the referenced publications, definitions and case studies. upstream_sources.tsv lists the URLs, byte sizes and SHA-256 fingerprints of the four EIA delivery/customer/comparison workbooks, 2020 RECS CSV and codebook, 78 NOAA daily files, four ACS table files and three monthly RECS physical-unit tables. The 2020 monthly RECS source flags are retained in recs_monthly_2020.csv. Asterisk denotes below displayed precision; Q denotes suppression. The within-survey decomposition requires complete numeric inputs. Basic data-quality checks verify that monthly weather covers every date and that the 48 state delivery sums and divisional sums agree.

For an optional source refresh, install acquisition/requirements.txt, then run `python acquisition/refetch.py new_raw_run` from the unpacked directory. This independently fetches verified source bytes in a new directory and runs both importers if every downloaded file matches. Public workbooks change over time. An upstream hash mismatch is documented in the new folder and does not prevent an offline replay of the edition you received. Refreshing numerical extracts regenerates gzip metadata, so their decompressed numerical content is the meaningful comparison to the packaged extracts. Keep a new research vintage separate from this edition.
