"""Separate same-month and trailing temperature responses on explicitly defined periods."""
from pathlib import Path
import sys,pandas as pd,numpy as np
from study import K,put
def main(out):
 s=pd.read_csv(out/'state_months.csv').merge(pd.read_csv(out/'state_years.csv')[['state','year','customers']],on=['state','year']);s=s.sort_values(['state','month']);s['lag']=s.groupby('state').hd.shift();s['intensity_day']=s.rate*1e6/s.customers
 rr=[]
 for st,g in s.groupby('state'):
  for start,end in [(2001,2009),(2011,2017),(2018,2024),(2015,2024)]:
   q=g[g.year.between(start,end)].copy();cols=['hd','lag','intensity_day'];m=q[cols]-q.groupby('season_month')[cols].transform('mean');x=m[['hd','lag']].to_numpy();y=m.intensity_day.to_numpy();b=np.linalg.lstsq(x,y,rcond=None)[0]*1000;one=1000*np.dot(x[:,0],y)/np.dot(x[:,0],x[:,0]);rr.append([st,start,end,len(y),one,*b,b.sum()])
 put(out,'two_month_response',pd.DataFrame(rr,columns=['state','start','end','months','single_cuft','current_cuft','prior_cuft','sustained_cuft']))
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
