"""Year-block bootstrap of paired absolute-error advantages, conditional on the fixed hindcasts."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import K,put
def main(out):
 p=pd.read_csv(out/'national_predictions.csv');n=p[p.scale=='national'].set_index('month');s=p[p.scale=='state'].set_index('month');g=p[p.scale=='division'].set_index('month');actual=n.actual
 curves={'seasonal':n.seasonal,'national population':n['pop'],'national gas weights':n.gas,'division gas weights':g.gas,'state population':s['pop'],'state plus lag':s.pop_lag,'division gas plus lag':g.gas_lag}
 comparisons=[('seasonal','state plus lag'),('national population','national gas weights'),('national gas weights','division gas weights'),('division gas weights','state population'),('state population','state plus lag'),('division gas plus lag','state plus lag')]
 rng=np.random.default_rng(2409);ix=rng.integers(0,15,size=(20000,15));rows=[];yy=[]
 for first,next_ in comparisons:
  d=(curves[first]-actual).abs()-(curves[next_]-actual).abs();by=d.groupby(d.index.str[:4]).mean();assert len(by)==15 and len(d)==180
  boot=by.to_numpy()[ix].mean(axis=1);quant=np.quantile(boot,[.025,.975])
  rows.append([first,next_,d.mean(),*quant,(d>1e-9).sum(),(by>1e-9).sum(),len(d),len(by)])
  for yr,v in by.items():yy.append([first,next_,yr,v])
 put(out,'paired_uncertainty',pd.DataFrame(rows,columns=['baseline','candidate','average_advantage','p025','p975','months_better','years_better','n_months','n_years']));put(out,'paired_by_year',pd.DataFrame(yy,columns=['baseline','candidate','year','advantage']))
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
