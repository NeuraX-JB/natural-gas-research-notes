"""Same-calendar-month matching and score stability across winters."""
from pathlib import Path
import sys,numpy as np,pandas as pd
from study import K,put
def main(out):
 p=pd.read_csv(out/'national_predictions.csv');piv=p.pivot(index='month',columns='scale',values='actual');n=p[p.scale=='national'].set_index('month').copy();n['state_lag']=p[p.scale=='state'].set_index('month').pop_lag
 w=pd.read_csv(out/'weather_months.csv',dtype={'area':str});w=w[(w.area=='CONUS')&(w.weighting=='Population')].set_index('month');n['hddday']=w.hdd/w.days;n['yr']=n.index.str[:4].astype(int);n['mo']=n.index.str[-2:]
 sp=pd.read_csv(out/'predictions.csv').query("scale=='state'").pivot(index='month',columns='area',values='pop_lag');s=pd.read_csv(out/'state_months.csv').pivot(index='month',columns='state',values='rate')
 candidates=[]
 for i,a in n.iterrows():
  for j,b in n[(n.mo==a.mo)&(n.yr>a.yr)&(n.yr<=a.yr+5)].iterrows():
   dh=b.hddday-a.hddday
   if abs(dh)>.5:continue
   ds=s.loc[j]-s.loc[i];dsp=sp.loc[j]-sp.loc[i];st=ds.abs().idxmax()
   candidates.append([i,j,dh,b.actual-a.actual,b['pop']-a['pop'],b.state_lag-a.state_lag,st,ds[st],dsp[st]])
 c=pd.DataFrame(candidates,columns=['first','second','hdd_difference','actual_difference','national_pop_difference','state_lag_difference','largest_state','largest_change','estimated_state_change'])
 c['abs_hdd']=c.hdd_difference.abs();c=c.sort_values(['abs_hdd','first','second']);used=set();ch=[]
 for r in c.itertuples():
  keep=r.first not in used and r.second not in used;ch.append(keep)
  if keep:used.update([r.first,r.second])
 c['disjoint']=ch;put(out,'weather_analogs',c)
 n['season']=np.where(n.mo.astype(int)>=11,n.yr+1,n.yr);rows=[]
 for season,g in n[n.mo.isin(['11','12','01','02','03'])].groupby('season'):
  if len(g)!=5:continue
  for name in ['seasonal','pop','gas','gas_lag','state_lag']:
   e=g[name]-g.actual;row=g.iloc[e.abs().argmax()];rows.append([season,name,len(e),e.abs().mean(),e.mean(),row.name,e.loc[row.name],np.dot(e,w.loc[g.index,'days']),np.dot(g.actual,w.loc[g.index,'days'])])
 put(out,'winter_scores',pd.DataFrame(rows,columns=['ending_year','model','months','mae','bias','largest_month','largest_error','season_volume_error','observed_bcf']))
 # Compare actual late vs early state response with fixed seasonal effects and known, contemporaneous weather.
 s=pd.read_csv(out/'state_months.csv');s=s.merge(pd.read_csv(out/'state_years.csv')[['state','year','customers']],on=['state','year'])
 resp=[]
 for st,g in s.groupby('state'):
  for start,end in [(2000,2009),(2011,2020),(2015,2024)]:
   t=g[g.year.between(start,end)].copy();t['per']=t.rate*1e6/t.customers;t['raw']=t.rate
   for metric in ['per','raw']:
    x=t.hd-t.groupby('season_month').hd.transform('mean');y=t[metric]-t.groupby('season_month')[metric].transform('mean');slope=np.dot(x,y)/np.dot(x,x);res=y-slope*x;resp.append([st,start,end,metric,len(t),slope,np.sqrt(np.mean(res**2)),np.std(x)])
 put(out,'period_slopes',pd.DataFrame(resp,columns=['state','start','end','target','months','slope','residual_rmse','hdd_sd']))
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else K/'results')
