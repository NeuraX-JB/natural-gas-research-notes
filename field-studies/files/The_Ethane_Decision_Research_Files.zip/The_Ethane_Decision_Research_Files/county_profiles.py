"""Calculate county-specific comparisons for the five-state USGS casebook."""
from pathlib import Path
from itertools import combinations
import numpy as np,pandas as pd
from study import geo,ROOT,H,SHR
STATES=['WEST VIRGINIA','OHIO','PENNSYLVANIA','KENTUCKY','NEW YORK']
def sig(z):return f'{z:+.2f}'
def number(z):return f'{z:.2f}'.rstrip('0').rstrip('.')
def proper(s):return str(s).title()
def make():
    allrows=geo();good=allrows[allrows.keep].copy()
    good['ratio']=good.C2/good.C3
    start={s:[] for s in STATES}
    for state in STATES:
        state_set=good[good.STATE.eq(state)]
        st=state.title();state_m=state_set.C2.median()
        for county,subset in state_set.groupby('COUNTY'):
            g=subset.sort_values('OBJECTID').copy()
            if len(g)<5:continue
            n=len(g);place=proper(county);x=g.C2;y=g.C3;q1,med,q3=x.quantile([.25,.5,.75]);m3=y.median()
            entire=allrows[allrows.STATE.eq(state)&allrows.COUNTY.eq(county)]
            omitted=len(entire)-n
            lo=g.iloc[x.to_numpy().argmin()];hi=g.iloc[x.to_numpy().argmax()]
            gid=lambda a:str(int(a.ID))
            pairs=[]
            for i,j in combinations(g.itertuples(),2):
                a,b=sorted((i,j),key=lambda z:z.C2)
                dist=200*abs(a.C3-b.C3)/(a.C3+b.C3)
                pairs.append((dist,b.C2/a.C2,a,b))
            near=min(pairs,key=lambda t:(t[0],-t[1]));eligible=[p for p in pairs if p[0]<=10];choice=max(eligible,key=lambda z:z[1]) if eligible else near
            dist,factor,a,b=choice
            tight=len(eligible);cnt=len(pairs);state_rank=100*(state_set.C2<=med).mean()
            sections=[]
            k=(sum(map(ord,county))+n)%4
            intros=[
            f'{place} contributes {n} complete, screened composition records out of {len(entire)} retrieved for the county. Read them as observations made for different purposes. The middle ethane reading is {med:.2f} mole percent, compared with {state_m:.2f} in the eligible {st} archive. At that county median, {state_rank:.0f}% of individual state records have an ethane reading at or below it. The comparison weights each analysis once. A high-volume well receives the same weight as a small one.',
            f'Half of the {n} qualifying {place} observations sit between {q1:.2f} and {q3:.2f} mole percent ethane, using linearly interpolated quartiles. The middle reading is {med:.2f}%. Across all screened records in {st} the corresponding median is {state_m:.2f}%. There are {len(entire)} retrieved records under the county label. Using that larger count with the smaller set of complete component readings would give the distribution an unwarranted appearance of coverage.',
            f'A researcher choosing a {place} feed on the strength of the state median would start at {state_m:.2f} mole percent ethane. Sorting this county’s {n} eligible analyses produces {med:.2f}% at the middle. The first and third quartiles are {q1:.2f}% and {q3:.2f}%. The wider archive contains {len(entire)} county observations before the component screen. These differences describe material in the sample archive; actual commercial output would require inlet-flow weights for the period in question.',
            f'The historical records give {place} a median ethane concentration of {med:.2f}% and a median propane concentration of {m3:.2f}%. These two marginal medians can belong to different samples. There are {n} screened observations from a retrieved county total of {len(entire)}. Comparing the ethane median with the statewide sample distribution puts {state_rank:.0f}% of the {st} records at or below it. An actual inlet could have drawn on a very different combination.'
            ];sections.append(intros[k])
            v=(k+n)%4
            bands=[
            f'The two end measurements provide a practical range for a fixed-inlet exercise. Sample {gid(lo)} has {lo.C2:.2f}% ethane and {lo.C3:.2f}% propane; sample {gid(hi)} has {hi.C2:.2f}% and {hi.C3:.2f}%, respectively. Switching entirely between them changes the available ethane by a factor of {hi.C2/lo.C2:.2f}. The propane moves by {sig(hi.C3-lo.C3)} percentage points, a visible check on any explanation that assumes the rest of the feed is stationary.',
            f'Consider one hundred standard Mcf of each endpoint gas. Using 1.558 Mcf per liquid barrel, the ethane in archived record {gid(lo)} represents about {lo.C2/SHR:.2f} potential barrels. Record {gid(hi)} gives {hi.C2/SHR:.2f}. The gap has a physical meaning before a recovery efficiency is selected. Recovering sixty percent from either illustration would produce a difference of about {(hi.C2-lo.C2)/SHR*.6:.2f} liquid barrels from the same reference quantity of inlet.',
            f'Take the leanest and richest observations in {place}, IDs {gid(lo)} and {gid(hi)}. Their methane readings are {lo.C1:.2f}% and {hi.C1:.2f}%. Their ethane readings are {lo.C2:.2f}% and {hi.C2:.2f}%. At equal inlet volume the ethane change spans {hi.C2-lo.C2:.2f} percentage points. Normalizing to an equal amount of methane instead yields a factor of {(hi.C2/hi.C1)/(lo.C2/lo.C1):.2f} in ethane. That second calculation answers the different question of what a plant might receive to obtain the same methane.',
            f'The full observed ethane spread in {place} is {hi.C2-lo.C2:.2f} percentage points, from {lo.C2:.2f}% in record {gid(lo)} to {hi.C2:.2f}% in {gid(hi)}. A half-and-half volume blend of just these two endpoint gases would carry {(lo.C2+hi.C2)/2:.2f}% ethane and {(lo.C3+hi.C3)/2:.2f}% propane. Its position relative to the county median shows how readily a specified mixing rule and the midpoint of a distribution can yield different answers.'
            ];sections.append(bands[v])
            if tight:
                sections.append(f'The matched-propane test keeps {tight} of {cnt} distinct pairs. The largest ethane factor among those matches is {factor:.2f}, for records {gid(a)} and {gid(b)}. Propane is {a.C3:.2f}% in the first and {b.C3:.2f}% in the second, a symmetric difference of {dist:.2f}%. Their ethane values are {a.C2:.2f}% and {b.C2:.2f}%. '+(f'This particular archived pair clears the 1.594 scale of the producer’s year-over-year sales change. Same-county data can therefore supply a strong geological counterexample under this relatively loose single-component control.' if factor>=1.59354 else f'Even the strongest qualifying pair in {place} falls short of the producer’s 1.594 sales factor. The exclusion applies only to these sampled single feeds under this propane-matching rule.'))
            else:
                sections.append(f'None of the {cnt} record pairs in {place} meets the ten-percent relative propane tolerance. The closest pair consists of {gid(a)} and {gid(b)}, separated by {dist:.2f}% of mean propane. Their ethane readings differ by a factor of {factor:.2f}. Reporting a zero ethane effect here would mistake an empty comparison set for identical gas. The empirical result is the absence of an admissible same-county pair.')
            h=g.dropna(subset=['BTU']);h=h[h.BTU>0]
            years=g.PUBLICATION_DATE.dropna(); fields=g.FIELD.dropna().nunique();forms=g.FORMATION.dropna().nunique()
            rel=(x-g.C2.median()).abs();r=g.loc[rel.idxmin()]
            if len(h)>=3 and (v in [0,2]):
                closest=min(combinations(h.itertuples(),2),key=lambda ab:(abs(ab[0].BTU-ab[1].BTU),-abs(ab[0].C2-ab[1].C2)))
                l,z=closest
                sections.append(f'The closest archived heat readings under this county label belong to {gid(l)} and {gid(z)}: {l.BTU:.0f} and {z.BTU:.0f} in the archive’s Btu field. Ethane is {l.C2:.2f}% and {z.C2:.2f}%. Even a small difference between heat readings leaves other components to explain the composition. This heat comparison uses {len(h)} records with positive reported heat and gives priority to a larger ethane difference when two heat gaps tie.')
            else:
                without=[x.drop(ix).median() for ix in g.index];sections.append(f'A one-record deletion check moves the {place} median between {min(without):.2f}% and {max(without):.2f}%. The closest observed ethane to the full median belongs to record {gid(r)} at {r.C2:.2f}%. This offers a real sample to inspect when an even sample size produces an interpolated middle. The qualifying rows carry {fields} distinct nonempty field labels and {forms} formation labels; repeated analyses can describe related material.')
            if len(years):
                sections.append(f'The known publication years in the {place} subset extend from {years.min():.0f} to {years.max():.0f} across {len(years)} dated entries. Publication year identifies the vintage of a source; it cannot establish the date the well was producing the sampled mixture. The {omitted} retrieved records outside the composition screen remain in the downloadable five-state file for an alternative missing-data treatment. [G1] [G2] [E2]')
            start[state].append(('## '+place+' County, '+st,sections))
    return start
if __name__=='__main__':
    import argparse
    ar=argparse.ArgumentParser();ar.add_argument('output',type=Path);args=ar.parse_args()
    o=make()
    for n,states,fn,heading in [(10,STATES[:1],'west','West Virginia at sample scale'),(11,STATES[1:3],'north','Across Ohio and Pennsylvania'),(12,STATES[3:],'compare','The Kentucky and New York comparisons')]:
        lines=[f'# Chapter {n} · {heading}', 'These county studies use the five-state USGS archive described in Chapter 9. Each entry is calculated from the county’s own records. The five-record publication threshold keeps the most sparsely observed counties in the data package instead of giving them individual entries. The numbers refer to historical samples and can be reproduced by record ID. [G1] [G2]']
        for st in states:
            for head,blocks in o[st]:lines+=[head]+blocks
        (args.output/(fn+'.md')).write_text('\n\n'.join(lines))
