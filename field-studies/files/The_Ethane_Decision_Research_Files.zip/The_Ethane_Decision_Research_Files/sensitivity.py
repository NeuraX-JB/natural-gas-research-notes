"""Inlet-volume tolerances and pre-event regional calendar comparisons."""
import numpy as np,pandas as pd
from scipy.optimize import linprog
from study import ROOT,lab,case,load_monthly
from blends import blend_data
def tolerances():
    a,_=lab()
    a['heavy_yield']=a.C3/1.498+a.iC4/1.247+a.nC4/1.289+(a.iC5+a.nC5+a.C6plus)/1.050
    a=a.dropna(subset=['C2','C1','heavy_yield'])
    eq=np.vstack([a.heavy_yield,a.C1]);ones=np.ones(len(a));inequal=np.vstack([ones,-ones])
    target=case().loc['2023Q2','ethane_kbbl']/case().loc['2022Q2','ethane_kbbl']
    rows=[]
    for tag,r in blend_data().iterrows():
        totals=[r.heavy_yield,r.C1]
        for band in [0,.0025,.005,.01,.015,.02,.025,.03,.05,.10]:
            bounds=[1+band,-(1-band)]
            lo=linprog(a.C2,A_eq=eq,b_eq=totals,A_ub=inequal,b_ub=bounds)
            hi=linprog(-a.C2,A_eq=eq,b_eq=totals,A_ub=inequal,b_ub=bounds)
            assert lo.success and hi.success
            f=-hi.fun/lo.fun;rows.append((tag,band,f,f+1e-9>=target))
    return pd.DataFrame(rows,columns=['anchor','band_around_common_reference','max_factor','feasible'])
def season():
    d=load_monthly();regional=['RAP_ethane','RAP_propane','R20_ethane','R30_ethane','NUS_ethane']
    rates=d[regional].div(d.index.days_in_month,axis=0);rows=[]
    for yr in range(2014,2026):
        for col in regional:
            mar,apr,jun=[rates.loc[f'{yr}-{mo:02}',col] for mo in (3,4,6)]
            rows.append((yr,col,mar,apr,jun,100*(apr/mar-1),100*(jun/apr-1)))
    return pd.DataFrame(rows,columns=['year','series','march_kbd','april_kbd','june_kbd','mar_apr_pct','apr_jun_pct'])
if __name__=='__main__':
    t=tolerances();t.to_csv(ROOT/'results'/'throughput_tolerances.csv',index=False);print(t.groupby('band_around_common_reference').feasible.sum())
    s=season();s.to_csv(ROOT/'results'/'seasonal_controls.csv',index=False);print(s.query("series=='RAP_ethane'").round(2).to_string(index=False));print(s.query('year==2023').round(2).to_string(index=False))
