"""Recreate the 31 constrained feed examples in the technical workbook."""
import argparse
from pathlib import Path
import numpy as np
from study import ROOT,lab
from blends import evaluate,blend_data
from counterexample import run
def make():
    records=evaluate();variants=run();samples=blend_data(); d,p=lab()
    lines=['# Chapter 8 · Thirty-one attempts to explain the change with geology',
    'Each worked case starts from a measured wet Marcellus sample. The anchor fixes target properties; the solver can use any admissible sample in its before and after blends. Fractions in the fixed-volume experiment are fractions of total inlet. In the free-volume experiment the weights are amounts per common reference volume and need not sum to one. A factor of 1.594 would reproduce the scale of the company’s spring year-over-year sales change with constant ethane recovery. No particular anchor is attributed to the producer. The cases are arranged by measured ethane content so the examples can also be read as a physical transect. [G3] [A7] [E2]']
    for i,(anchor,row) in enumerate(samples.sort_values('C2').iterrows()):
        rec=records[records.anchor.eq(anchor)].set_index('held');prop,heavy,both=[rec.loc[k] for k in ['propane','heavy','heavy_and_methane']]
        w=variants[variants.anchor.eq(anchor)].set_index(['population','total_inlet']);free=w.loc['wet and dry','free'];wetfree=w.loc['wet only','free']
        lines+=['## '+anchor+' · '+f'{row.C2:.2f}% inlet ethane']
        case=[f'{anchor} contains {row.C2:.2f}% ethane, {row.C3:.2f}% propane and {row.C1:.2f}% methane. When only propane must match across equal-volume wet blends, admissible ethane spans {prop.low_c2:.2f}% to {prop.high_c2:.2f}%. The end-to-end factor of {prop.factor:.3f} captures the discretion left by observing one heavier component. At the same anchor, asking that all modeled heavier barrels match instead leaves a factor of {heavy.factor:.3f}.',
              f'The {anchor} analysis fixes a methane reading of {row.C1:.2f}% and a propane reading of {row.C3:.2f}%. Its measured ethane is {row.C2:.2f}%. Using the whole wet library at constant total feed, the same propane reading admits an ethane range from {prop.low_c2:.2f}% to {prop.high_c2:.2f}%. Specifying the heavier-liquid yield of {row.heavy_yield:.2f} barrels per hundred Mcf instead produces a range from {heavy.low_c2:.2f}% to {heavy.high_c2:.2f}%.',
              f'At one hundred Mcf of {anchor} feed the heavier-liquid proxy is {row.heavy_yield:.2f} barrels. The ethane share measured by the laboratory is {row.C2:.2f}%, with propane at {row.C3:.2f}%. Two candidate blends matching only this propane concentration can differ in ethane by {100*(prop.factor-1):.1f}% relative to the lower blend. Asking for equal synthetic heavier-liquid potential changes that maximum difference to {100*(heavy.factor-1):.1f}%.'][i%3];lines.append(case)
        if heavy.factor>1.001:
            lines.append(f'The low-ethane heavier-yield solution is {heavy.low_blend}; the high solution is {heavy.high_blend}. The solver weights standard inlet volume. Adding the methane condition at {row.C1:.2f}% narrows the admissible ethane interval to {both.low_c2:.2f}–{both.high_c2:.2f}%. The added measurement removes {max(0.,(heavy.high_c2-heavy.low_c2)-(both.high_c2-both.low_c2)):.2f} percentage points of uncertainty in the modeled feed concentration.')
        else:
            lines.append(f'The heavier-yield target at {anchor} leaves a single ethane concentration to the precision shown, {heavy.low_c2:.2f}%. A boundary point in the measured library can behave this way even though nearby interior points admit quite different mixtures. The methane condition gives an end-to-end factor of {both.factor:.3f}. These results are conditional on the gases available to the optimizer.')
        if free.feasible:
            lines.append(f'With throughput free, the wet-only maximum at {anchor} is {wetfree.max_ratio:.3f}. Admitting complete dry samples as well lifts the maximum to {free.max_ratio:.3f}. A feasible after-feed matching the target sales ratio uses {free.after_weights}. Its corresponding before-feed uses {free.before_weights}. Both preserve absolute modeled heavier barrels and methane. The weights supply an independently checkable counterexample for this anchor. [G3]')
        else:
            lines.append(f'After allowing inlet throughput to vary, the maximum wet-only factor at {anchor} is {wetfree.max_ratio:.3f}. Adding the complete dry observations gives {free.max_ratio:.3f}. This anchor still falls short of 1.594 under the imposed methane and heavier-liquid totals. The gap describes a particular position in the feasible set. Applying the same tests at a different anchor can produce a different conclusion. [G3]')
    return '\n\n'.join(lines)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);o=p.parse_args().out;(o/'blendatlas.md').write_text(make())
