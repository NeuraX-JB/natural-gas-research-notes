"""Reproduce Book 4 from the CSV snapshots in this directory. Python 3 + pandas, numpy, matplotlib."""
from pathlib import Path
from itertools import combinations
import argparse
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
H=2.783   # EIA current ethane heat conversion, MMBtu/bbl
SHR=1.558 # EIA natural gas extraction volume, Mcf/bbl
def load_monthly():
    d=pd.read_csv(ROOT/'monthly.csv',index_col='month')
    d.index=pd.PeriodIndex(d.index,freq='M')
    return d
def quarter_inputs(d):
    g=d.groupby(d.index.asfreq('Q'))
    o=g.sum(min_count=3)
    heat=[c for c in d if c.endswith('_heat')]+['henry']
    o[heat]=g[heat].mean()
    o['days']=[(p.end_time.date()-p.start_time.date()).days+1 for p in o.index]
    return o
def case():
    c=pd.read_csv(ROOT/'case_quarters.csv').set_index('quarter')
    q=quarter_inputs(load_monthly()); q.index=q.index.astype(str)
    c=c.join(q[['days','henry','RAP_ethane','RAP_propane','exports','SWV_heat','SPA_heat','SOH_heat']])
    c['company_kbd']=c.ethane_kbbl/c.days
    c['c2_per_c3plus']=c.ethane_kbbl/c.c3plus_kbbl
    c['gas_reference_usd_bbl']=c.gas_usd_mcf/1.05*H
    c['headroom_usd_bbl']=c.adjusted_ethane_usd_bbl-c.gas_reference_usd_bbl
    c['hub_headroom_usd_bbl']=c.adjusted_ethane_usd_bbl-H*c.henry
    c['mb_gross_usd_bbl']=42*c.mb_ethane_usd_gal
    c['mb_minus_transport_low']=c.mb_gross_usd_bbl-42*.25
    c['mb_minus_transport_high']=c.mb_gross_usd_bbl-42*.15
    c['implied_payment_musd']=((c.ethane_usd_bbl-c.adjusted_ethane_usd_bbl)*c.ethane_kbbl/1000).where(c.payment_musd.notna())
    return c
def lab():
    d=pd.read_csv(ROOT/'marcellus_assays.csv');d['group']=np.where(d['sample'].str.contains('DG'),'DG','WG')
    for col in ['C1','C2','C3','iC4','nC4','iC5','nC5','C6plus']:
        d[col]=pd.to_numeric(d[col],errors='coerce')
    a=d[d.group.eq('WG')].dropna(subset=['C2','C3']).copy()
    out=[]
    for i,j in combinations(a.itertuples(),2):
        lo,hi=sorted([i,j],key=lambda r:r.C2)
        if min(lo.C3,hi.C3,lo.C2)<=0:continue
        ratio=hi.C2/lo.C2
        delta=200*abs(hi.C3-lo.C3)/(hi.C3+lo.C3)
        out.append((lo.sample,hi.sample,lo.C2,hi.C2,lo.C3,hi.C3,ratio,delta,hi.C2/hi.C3/(lo.C2/lo.C3)))
    pairs=pd.DataFrame(out,columns='low_id high_id low_c2 high_c2 low_c3 high_c3 c2_factor symmetric_c3_pct ratio_factor'.split())
    return d,pairs.sort_values(['symmetric_c3_pct','low_id','high_id'])
def geo():
    d=pd.read_csv(ROOT/'five_state_assays.csv')
    for c in ['C1','C2','C3','BTU','N2','CO2']:
        d[c]=pd.to_numeric(d[c],errors='coerce')
    d['keep']=d.C1.between(50,100)&d.C2.between(0.01,40)&d.C3.between(0.01,30)&((d.C1+d.C2+d.C3)<=101)
    return d
def write(out):
    out.mkdir(parents=True,exist_ok=True)
    c=case();c.to_csv(out/'case_results.csv')
    a,p=lab();p.to_csv(out/'all_wet_pairs.csv',index=False)
    d=geo(); g=d[d.keep].groupby(['STATE','COUNTY']).agg(samples=('C2','size'),c2_median=('C2','median'),c3_median=('C3','median'),c2_min=('C2','min'),c2_max=('C2','max'));g.to_csv(out/'historical_counties.csv')
    q=quarter_inputs(load_monthly());q.to_csv(out/'regional_quarters.csv')
    rows=[]
    for period,z in c.iterrows():
        for heat in [1.,1.025,1.05,1.075,1.10,1.125,1.15]:
            for extra in [0,.5,1,1.5,2,2.5,3,4]:
                gas=H*z.gas_usd_mcf/heat
                rows.append((period,heat,extra,gas,z.adjusted_ethane_usd_bbl-extra,z.adjusted_ethane_usd_bbl-extra-gas))
    pd.DataFrame(rows,columns='quarter assumed_mmbtu_per_mcf assumed_net_extra_cost_per_bbl gas_value_per_bbl liquid_less_net_extra_cost spread_per_bbl'.split()).to_csv(out/'netback_scenarios.csv',index=False)
    print(c[['company_kbd','c2_per_c3plus','gas_reference_usd_bbl','headroom_usd_bbl','mb_gross_usd_bbl','implied_payment_musd']].round(3))
    print('Samples',len(d),'eligible',d.keep.sum(),'Marcellus rows',len(a),'wet pairs',len(p))
if __name__=='__main__':
    ar=argparse.ArgumentParser();ar.add_argument('--out',type=Path,default=ROOT/'results');write(ar.parse_args().out)
