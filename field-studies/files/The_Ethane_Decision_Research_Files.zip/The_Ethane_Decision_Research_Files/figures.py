from pathlib import Path
import argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from study import case,geo,lab,ROOT
from blends import evaluate
CYAN='#11796e';OCHRE='#af5329';INK='#233c49';GRAY='#637982'
def style(ax):
    ax.spines[['top','right','left']].set_visible(False);ax.spines['bottom'].set_color('#a6b7bc');ax.grid(axis='y',color='#dde5e7',linewidth=.65);ax.set_axisbelow(True);ax.tick_params(length=0,labelsize=8,colors=INK);ax.yaxis.label.set_color(INK);ax.xaxis.label.set_color(INK)
def save(fig,out,name):
    fig.tight_layout(pad=.6);fig.savefig(out/(name+'.png'),dpi=190,bbox_inches='tight',facecolor='white');plt.close(fig)
def make(out):
    out.mkdir(exist_ok=True,parents=True);plt.rcParams.update({'font.family':'DejaVu Sans','axes.labelsize':8,'legend.fontsize':7,'text.color':INK});c=case();x=np.arange(len(c))
    fig,ax=plt.subplots(figsize=(4.5,2.9));style(ax);ax.plot(x,c.company_kbd,marker='o',color=CYAN,label='Ethane');ax.plot(x,c.c3plus_kbbl/c.days,marker='s',color=OCHRE,label='C3+ liquids');ax.set_xticks(x,[v.replace('20','',1) for v in c.index],rotation=40);ax.set_ylabel('Thousand barrels per day');ax.set_ylim(0,135);ax.legend(frameon=False,loc='lower right');save(fig,out,'case')
    fig,ax=plt.subplots(figsize=(4.6,2.7));labels=['Gulf price','After posted freight','After freight + plant','Residue heat value'];a=[8.82,8.82-8.0114,8.82-8.0114-.50,2.14/1.05*2.783];pos=np.arange(4);ax.barh(pos,a,color=[INK,CYAN,CYAN,OCHRE]);ax.set_yticks(pos,labels);ax.invert_yaxis();ax.set_xlim(0,10.5);ax.set_xlabel('Dollars per barrel of ethane');ax.tick_params(length=0,labelsize=8);ax.spines[['top','right','left']].set_visible(False)
    for j,v in enumerate(a):ax.text(v+.10,j,f'${v:.2f}',va='center',fontsize=8)
    save(fig,out,'routes')
    fig,ax=plt.subplots(figsize=(4.5,3));style(ax);r=evaluate();labels=['Propane','Heavier yield','Heavier yield\n+ methane']
    for i,rule in enumerate(['propane','heavy','heavy_and_methane']):
        z=r[r.held.eq(rule)].sort_values('factor');ax.scatter(i+np.linspace(-.14,.14,len(z)),z.factor,s=10,alpha=.67,color=[GRAY,OCHRE,CYAN][i])
    ax.axhline(6414/4025,ls='--',lw=1.1,color=INK);ax.text(-.39,1.61,'Observed sales factor 1.594',fontsize=8,color=INK);ax.set_xticks(range(3),labels);ax.set_xlim(-.47,2.47);ax.set_ylim(.975,1.68);ax.set_ylabel('Maximum ethane factor for each anchor');save(fig,out,'blends')
    fig,ax=plt.subplots(figsize=(4.5,3));style(ax);g=geo();s=g[g.keep & g.BTU.gt(0)];colors=['#9d6936','#895870','#346484','#8d9462',CYAN]
    for (name,k),color in zip(s.groupby('STATE'),colors):ax.scatter(k.BTU,k.C2,s=7,label={'NEW YORK':'NY','OHIO':'OH','WEST VIRGINIA':'WV','PENNSYLVANIA':'PA','KENTUCKY':'KY'}[name],alpha=.54,color=color)
    ax.set_xlabel('Heat value in historical assay record');ax.set_ylabel('Ethane (mole %)');ax.legend(frameon=False,ncol=5,loc='upper center',handletextpad=0,columnspacing=.6,markerscale=1.2);save(fig,out,'heat')
    from sensitivity import season
    series=season();a=series.query("series=='RAP_ethane'");fig,ax=plt.subplots(figsize=(4.6,2.85));style(ax)
    ax.axhline(0,color=GRAY,lw=.7);ax.plot(a.year,a.mar_apr_pct,color=OCHRE,marker='o',ms=3,label='March to April');ax.plot(a.year,a.apr_jun_pct,color=CYAN,marker='s',ms=3,label='April to June');ax.axvline(2023,ls=':',color=INK,lw=1);ax.set_xticks([2014,2017,2020,2023,2025]);ax.set_ylabel('Change in daily rate (%)');ax.legend(frameon=False,loc='upper left');save(fig,out,'season')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'figures');make(p.parse_args().out)
