"""Construct the quarterly regional casebook from EIA series, without filling missing observations."""
from pathlib import Path
import numpy as np,pandas as pd,calendar
from study import ROOT,load_monthly,quarter_inputs,H
def make():
    d=load_monthly(); q=quarter_inputs(d); records=[]
    for t in pd.period_range('2014Q1','2025Q4',freq='Q'):
        r=q.loc[t]; lag=q.loc[t-4]; prev=q.loc[t-1]; mm=d[d.index.asfreq('Q')==t].copy()
        date=str(t);name=f'{t.year}, quarter {t.quarter}';n=r.days
        rate=lambda row,series:row[series]/row.days
        e=rate(r,'RAP_ethane');p=rate(r,'RAP_propane');old=rate(lag,'RAP_ethane');oldp=rate(lag,'RAP_propane');last=rate(prev,'RAP_ethane')
        component=(e/old-1)*100 if old>0 else np.nan; ratios=r.RAP_ethane/r.RAP_propane;oldratio=lag.RAP_ethane/lag.RAP_propane
        ds=q.loc[:t].tail(9);hist=q.loc[:t-1].tail(8).copy();ranks=(hist.RAP_ethane/hist.days<e).sum()
        differences=mm.RAP_ethane/mm.index.days_in_month; high=differences.idxmax();low=differences.idxmin()
        hmap={k:mm[k].mean() for k in ['SWV_heat','SPA_heat','SOH_heat']};chg=rate(r,'NUS_ethane')-rate(lag,'NUS_ethane');local=e-old
        blocks=[];k=(t.year+t.quarter)%4
        intro=[
         f'Appalachian No. 1 plants reported {r.RAP_ethane/1000:.3f} million ethane barrels over {int(n)} days, or {e:.1f} thousand barrels per day. The prior quarter ran at {last:.1f} thousand and the year-earlier quarter at {old:.1f} thousand. The distinction between these baselines matters here: the sequential change is {e-last:+.1f} thousand barrels per day, while the same-season change is {local:+.1f} thousand. Seasonal comparisons use rates so a leap day or a longer quarter cannot create output on paper.',
         f'The quarter ended with {r.RAP_ethane/1000:.3f} million recorded ethane barrels in Appalachian No. 1. Converting to a daily mean of {e:.1f} thousand barrels puts it above {ranks} of the previous {len(hist)} quarterly rates. The year-over-year difference was {local:+.1f} thousand barrels per day. A comparison with the immediately preceding {last:.1f} thousand per day would describe a different interval and introduce any seasonal change occurring between the two periods.',
         f'An observer coming into {name} had just seen Appalachian No. 1 produce ethane at {last:.1f} thousand barrels a day. This quarter averaged {e:.1f} thousand, on a total of {r.RAP_ethane/1000:.3f} million barrels. A year earlier the same three calendar months averaged {old:.1f} thousand. Of the prior {len(hist)} quarterly observations available in this comparison, {ranks} came in below the new daily rate. The count measures historical position without assuming a smooth growth trend.',
         f'Following the same three months across years gives an ethane change of {local:+.1f} thousand barrels a day in Appalachian No. 1. The present quarter contributes {e:.1f} thousand per day against {old:.1f} in the comparison period. In the monthly series the quarter contains {r.RAP_ethane/1000:.3f} million barrels. Putting the calendar days back into a chart of totals distinguishes a longer reporting period from an actual increase in plant output.'
        ];blocks.append(intro[k])
        dprop=p-oldp
        if oldp>0:
            counter=oldratio*r.RAP_propane;diff=r.RAP_ethane-counter
            blocks.append(f'Propane averaged {p:.1f} thousand barrels a day against {oldp:.1f} a year earlier. Holding the earlier ratio of {oldratio:.3f} ethane barrels per propane barrel fixed and applying it to this quarter’s propane would predict {counter/1000:.3f} million ethane barrels. The recorded total differs by {diff/1000:+.3f} million. The observed ratio is {ratios:.3f}. '+(f'The change in ethane and propane daily production has opposite signs in this window, which defeats a simple story of uniform scaling at fixed product yields.' if local*dprop<0 else f'The two products move in the same direction on a daily-rate basis. Their common direction alone cannot distinguish changes in feed, processing choice, or the number of plants in service.'))
        ix=t.quarter
        if ix==1:
            loh=min(hmap,key=hmap.get);hih=max(hmap,key=hmap.get); names={'SWV_heat':'West Virginia','SPA_heat':'Pennsylvania','SOH_heat':'Ohio'}
            blocks.append(f'Delivered gas gives a separate downstream test. Among three states the highest simple mean of the monthly heat values is {hmap[hih]:.1f} Btu per cubic foot in {names[hih]}; the lowest is {hmap[loh]:.1f} in {names[loh]}. The span is {hmap[hih]-hmap[loh]:.1f} Btu per cubic foot. These are consumer deliveries across different networks. A plant-specific heat change could therefore go unnoticed even when a state ranks high for the quarter.')
        elif ix==2:
            blocks.append(f'The mean of the three published Henry Hub monthly spot averages is ${r.henry:.2f} per MMBtu. This sets a reference gas value of ${r.henry*H:.2f} per liquid barrel of ethane, or {r.henry*H/42*100:.1f} cents per gallon. A year earlier the corresponding gas value was ${lag.henry*H:.2f} per barrel. The difference of ${(r.henry-lag.henry)*H:+.2f} is the movement of the gas side only. The liquid quote, producer basis and route costs are separate terms in a recovery calculation.')
        elif ix==3:
            national=rate(r,'NUS_ethane');usshare=100*e/national;gulf=rate(r,'R30_ethane');gn=gulf-rate(lag,'R30_ethane')
            blocks.append(f'U.S. field ethane production averaged {national:,.1f} thousand barrels per day, putting the refining district at {usshare:.1f}% of the national total. Gulf Coast PADD 3 averaged {gulf:,.1f} thousand and changed by {gn:+.1f} from its year-earlier rate. The corresponding national change was {chg:+.1f} thousand. These are distinct spatial scales. An Appalachian trend can be visible in the U.S. result while its sign or magnitude is dominated by activity on the Gulf Coast.')
        else:
            if pd.notna(r.exports):
                blocks.append(f'East Coast exports totaled {r.exports/1000:.3f} million barrels, averaging {rate(r,"exports"):.1f} thousand per day. In pure scale terms those shipments equal {100*r.exports/r.RAP_ethane:.1f}% of the district’s ethane output. An export can draw stocks built in another period or supplies from another place, and the districts cover different areas. Reading the ratio as a destination share would assign a physical origin that the export data never identify.')
            else:
                blocks.append(f'The East Coast export history does not supply three numeric monthly entries for {name}. The quarterly export cell is therefore left empty. Plant production is still observed at {e:.1f} thousand barrels per day. Substituting zero for the missing export quarter would make a seemingly exact local consumption balance out of a missing series and a production region with a different footprint.')
        blocks.append(f'Within {name}, {high.strftime("%B")} had the highest ethane daily rate at {differences.max():.1f} thousand barrels, while {low.strftime("%B")} had the lowest at {differences.min():.1f} thousand. The quarter conceals a within-period range of {differences.max()-differences.min():.1f} thousand per day. [E3] [E4] [E5] [E6] [E7]')
        records.append((int(t.year),'## '+str(t.year)+' · '+['January through March','April through June','July through September','October through December'][t.quarter-1],blocks))
    return records
if __name__=='__main__':
    import argparse
    ar=argparse.ArgumentParser();ar.add_argument('out',type=Path);dest=ar.parse_args().out
    records=make()
    for i,(start,end,title) in enumerate([(2014,2017,'The early Appalachian liquids record'),(2018,2021,'Four years before the cracker opened'),(2022,2025,'The startup years and their aftermath')]):
        lines=[f'# Chapter {13+i} · {title}',f'This chronological casebook covers {start}–{end}. Daily rates are thousand barrels per day. A quarterly total is formed only when all three months have a published number. Heat values and Henry Hub observations are simple means of the three reported monthly observations. Controls rotate by season so the record can be read across years as well as along the calendar. Dates identify observation periods in a later EIA data vintage. [E3] [E4] [E5] [E6] [E7] [E8]']
        for year,head,blocks in records:
            if start<=year<=end:lines+=[head]+blocks
        (dest/f'hist{i}.md').write_text('\n\n'.join(lines))
