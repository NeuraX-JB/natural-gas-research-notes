"""Can two synthetic gas feeds reproduce the sales ratio without changing the recovery fraction?"""
import pandas as pd,numpy as np
from scipy.optimize import linprog
from study import ROOT,lab,case
from blends import blend_data

def run():
    a,_=lab()
    a['heavy_yield']=a.C3/1.498+a.iC4/1.247+a.nC4/1.289+(a.iC5+a.nC5+a.C6plus)/1.05
    c=case();before,after=c.loc['2022Q2'],c.loc['2023Q2']
    goal=after.ethane_kbbl/before.ethane_kbbl
    # Fix both before and after methane and heavy totals, anchored to a synthetic wet gas.
    # The observed case measures residue and sales, so matching these proxies is explicitly illustrative.
    output=[]
    for mode,d in [('wet only',a[a.group=='WG']),('wet and dry',a)]:
        d=d.dropna(subset=['heavy_yield','C1','C2']).set_index('sample')
        for key in blend_data().index:
            rec=d.loc[key];fixed=np.vstack([d.heavy_yield,d.C1])
            for volume in ['fixed','free']:
                eq=fixed if volume=='free' else np.vstack([np.ones(len(d)),fixed])
                target=np.array([rec.heavy_yield,rec.C1]) if volume=='free' else np.array([1.,rec.heavy_yield,rec.C1])
                lo=linprog(d.C2,A_eq=eq,b_eq=target);hi=linprog(-d.C2,A_eq=eq,b_eq=target)
                assert lo.success and hi.success
                upper=-hi.fun/lo.fun
                if upper+1e-9>=goal:
                    frac=(goal*lo.fun-lo.fun)/(-hi.fun-lo.fun)
                    after_w=lo.x*(1-frac)+hi.x*frac
                    fmt=lambda a:' + '.join(f'{x:.6f} {s}' for x,s in zip(a,d.index) if x>1e-7)
                    lhs,rhs=fmt(lo.x),fmt(after_w)
                else:lhs=rhs=''
                output.append((mode,volume,key,len(d),lo.fun,-hi.fun,upper,goal,upper>=goal,lhs,rhs))
    return pd.DataFrame(output,columns='population total_inlet anchor rows low high max_ratio target feasible before_weights after_weights'.split())
if __name__=='__main__':
    o=run();o.to_csv(ROOT/'results'/'alternative_feeds.csv',index=False);print(o.groupby(['population','total_inlet']).agg(max_ratio=('max_ratio','max'),feasible=('feasible','sum'),observations=('rows','first')));print(o[o.feasible].head(1).to_string(index=False))
