"""Test prediction of ethane for a county excluded in its entirety from its state's training records."""
from pathlib import Path
import numpy as np,pandas as pd
from study import geo,ROOT
def evaluate():
    d=geo();d=d[d.keep & d.BTU.gt(0) & d.COUNTY.notna()].copy()
    predictions=[]
    for st,g in d.groupby('STATE'):
        for county,test in g.groupby('COUNTY'):
            train=g[g.COUNTY.ne(county)]
            assert len(train)>=5
            base=train.C2.median()
            for o in test.itertuples():
                distance=(train.BTU-o.BTU).abs(); cut=distance.nsmallest(5).max()
                neighbor=train[distance<=cut];estimate=neighbor.C2.median()
                predictions.append((st,county,o.ID,o.BTU,o.C2,base,estimate,len(neighbor),cut))
    z=pd.DataFrame(predictions,columns='state county id heat actual baseline estimate neighbors max_heat_distance'.split());z['baseline_error']=(z.actual-z.baseline).abs();z['heat_error']=(z.actual-z.estimate).abs()
    return z
if __name__=='__main__':
    z=evaluate();z.to_csv(ROOT/'results'/'county_holdouts.csv',index=False)
    print(z.groupby('state')[['baseline_error','heat_error']].mean(),z[['baseline_error','heat_error']].mean(),len(z),z.groupby(['state','county']).ngroups)
