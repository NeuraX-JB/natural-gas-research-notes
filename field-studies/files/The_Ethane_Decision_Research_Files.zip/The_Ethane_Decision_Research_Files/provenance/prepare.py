from pathlib import Path
import pandas as pd,numpy as np,json,re,calendar
from lxml import html
from get_start import u
from datetime import date
K=Path('kit'); R=Path('raw')
def clean(s):return ' '.join(str(s).replace('\u200b','').replace('\xa0',' ').split())
sources=[]
def src(code,title,url):sources.append((code,title,url))
for i,q in enumerate(('q1','q2','q3','q4','q322','q422')):
 src('A'+str(i+1),'Antero Resources quarterly results, '+{'q1':'2023 Q1','q2':'2023 Q2','q3':'2023 Q3','q4':'2023 Q4','q322':'2022 Q3','q422':'2022 Q4'}[q],u[q])
urls=json.loads(Path('more_urls.json').read_text())
for n,name,title in [(7,'ar2023-06-30','2023 Q2 Form 10-Q, operating data and take-or-pay note'),(8,'ar2023-03-31','2023 Q1 Form 10-Q'),(9,'ar2023-09-30','2023 Q3 Form 10-Q'),(10,'ar2022-12-31','2022 Form 10-K, contracts and marketing'),(11,'ar2024-12-31','2024 Form 10-K, ethane decisions and operational scope'),(12,'q222','2022 Q2 operations and commissioning guidance'),(13,'ar2023-12-31','2023 Form 10-K, operating results and processing commitments')]:
 src('A'+str(n),'Antero Resources, '+title,urls[name])
for x in [
('A14','Antero Resources, May 2023 NGL Fundamentals presentation','https://d1io3yog0oux5.cloudfront.net/_2576c178ea8222831b68cbc223f1b22a/anteroresources/db/819/7284/pdf/NGL_Fundies_May_2023_vF.pdf'),
('A15','Range Resources, 2022 and 2023 Mont Belvieu quarterly settlement comparisons','https://ir.rangeresources.com/static-files/3ac7ec76-6a2b-471a-ad69-f0ac03d3f8cc'),
('A16','Enterprise Products Partners, 2023 Q2 supplemental financial and operational data','https://enterpriseproductspartnerslp.gcs-web.com/static-files/20caa5eb-fd8c-455f-80c0-7c480a7805bb'),
('A17','MPLX presentation at West Virginia energy summit, 2017, slide 17, illustrative transportation rates','https://energywv.org/wp-content/uploads/2024/07/https_energywv.org_assets_files_Energy-Summit-Presentations_2017_25_Jim_Crews.pdf'),
('A18','Shell, November 15, 2022 commencement release, in 2022 press archive','https://www.shell.com/news-and-insights/newsroom/news-and-media-releases/_jcr_content/root/main/section/simple_1285915735/call_to_action_copy__876059154/links/item0.stream/1742566955507/e7fdc6470f3fac2d5279ce45b136e5d54038947e/2022-press-releases.pdf'),
('A19','Pennsylvania DEP and Shell, May 24, 2023 consent order and agreement','https://files.dep.state.pa.us/RegionalResources/SWRO/SWROPortalFiles/Shell/5-24-23/Shell_Chem_Appalachia-Monaca_final_COA_05-24-23_Redacted.pdf'),
('A20','Shell report to Pennsylvania DEP, March 25–April 2023 operating event','https://files.dep.state.pa.us/RegionalResources/SWRO/SWROPortalFiles/Shell/5-22-23/Visible_Emissions_Malfunction_Report_20230425.pdf'),
('E1','EIA, British thermal unit conversion factors, ethane series EQTCKUS','https://www.eia.gov/totalenergy/conversion/factors/'),
('E2','EIA, technical notes on gas processing, survey boundaries and shrinkage factors','https://www.eia.gov/dnav/ng/TblDefs/ng_prod_sum_tbldef.asp'),
('E3','EIA, ethane monthly field production by district, original history','https://www.eia.gov/dnav/pet/xls/PET_PNP_GP_A_EPLLEA_FPF_MBBL_M.xls'),
('E4','EIA, propane monthly field production by district, original history','https://www.eia.gov/dnav/pet/xls/PET_PNP_GP_A_EPLLPA_FPF_MBBL_M.xls'),
('E5','EIA, East Coast monthly ethane exports in thousand barrels','https://www.eia.gov/dnav/pet/hist_xls/M_EPLLEA_EEX_R10-Z00_1m.xls'),
('E6','EIA, monthly heat content of gas delivered to consumers by state','https://www.eia.gov/dnav/ng/xls/NG_CONS_HEAT_A_EPG0_VGTH_BTUCF_M.xls'),
('E7','EIA, Henry Hub monthly spot price','https://www.eia.gov/dnav/ng/hist_xls/RNGWHHDm.xls'),
('E8','EIA, Petroleum Supply Monthly, definitions of refining districts','https://www.eia.gov/petroleum/supply/monthly/pdf/psmall.pdf'),
('E9','DOE, Appalachian energy and petrochemical report, Figure 14 and discussion','https://www.energy.gov/sites/default/files/2020/06/f76/Appalachian%20Energy%20and%20Petrochemical%20Report_063020_v3.pdf'),
('E10','EIA, geographic interpretation of dry gas heat content in 2023','https://www.eia.gov/todayinenergy/detail.php?id=63144'),
('E11','EIA, ethane recovery and Appalachian fractionation, 2017','https://www.eia.gov/TodayinEnergy/detail.php?id=32692'),
('E12','EIA, exported ethane and gas heating value, 2016','https://www.eia.gov/TodayinEnergy/detail.php?id=28052'),
('G1','USGS, Natural Gas Compositional Analyses Dataset of Gases from United States Wells','https://www.usgs.gov/data/natural-gas-compositional-analyses-dataset-gases-united-states-wells'),
('G2','USGS public ArcGIS service for the compositional analyses dataset','https://www.arcgis.com/home/item.html?id=245d22ce1c2a461da042da6c4a40672a'),
('G3','Laughrey, 2022, Produced Gas and Condensate Geochemistry of the Marcellus Formation, Minerals 12, 1222, Table 1','https://doi.org/10.3390/min12101222'),
]:src(*x)
src('A21','Enterprise TE Products Pipeline Company, FERC 59.23.0, effective July 1, 2022, ATEX Items 200, 300 and 310','https://enterpriseproducts.com/media-library/epd/8c9b81fa-b06a-4fff-934f-6dc8b7577848.pdf')
src('A22','Enterprise TE Products Pipeline Company, FERC 59.24.0, effective July 1, 2023, ATEX Item 300','https://enterpriseproducts.com/media-library/epd/888f203f-b9e4-4633-86ee-a4c936e1c7c5.pdf')
pd.DataFrame(sources).to_csv(K/'sources.tsv',sep='\t',header=False,index=False)
t=html.fromstring((R/'mdpi').read_bytes())
rows=[[clean(c.text_content()).replace('−','-') for c in r.xpath('./td|./th')] for r in t.xpath('//table')[0].xpath('.//tr')]
offset=next(i for i,r in enumerate(rows) if r[0]=='WG10 WG11')
pair=rows[offset]
assert all(len(z.split())==2 for z in pair)
rows[offset:offset+1]=[[z.split()[j] for z in pair] for j in (0,1)]
print('rows of length other',[(r[0],len(r)) for r in rows if len(r)!=16])
pd.DataFrame([r for r in rows[1:] if len(r)==16],columns=['sample','O2','CO2','N2','C1','C2','C3','iC4','nC4','iC5','nC5','C6plus','isoC1','isoHC1','isoC2','isoC3']).to_csv(K/'marcellus_assays.csv',index=False)
geo=pd.read_json(R/'geo.json');geo.to_csv(K/'five_state_assays.csv',index=False)
def readxls(f):
 t=pd.read_excel(R/(f+'.xls'),sheet_name=1,header=None);d=t.iloc[3:].copy();d.columns=t.iloc[1];d=d.rename(columns={'Sourcekey':'date'}).set_index('date');d.index=pd.to_datetime(d.index).to_period('M');return d.apply(pd.to_numeric,errors='coerce')
a=[]
for f in ['ethane','propane','exports','henry','heat']:
 d=readxls(f)
 if f in ('ethane','propane'):d.columns=[c.split('_')[-2]+'_'+f for c in d.columns]
 if f in ('heat',):d=d[[k for k in d if any(g in k for g in ['_SWV_','_SOH_','_SPA_','_STX_','_NUS_'])]];d.columns=[c.split('_')[-2]+'_heat' for c in d.columns]
 if f in ('exports','henry'):d.columns=[f]
 a.append(d)
d=pd.concat(a,axis=1).loc['2012-01':'2025-12'];d.index.name='month';d.to_csv(K/'monthly.csv')
print(d.loc['2022-04':'2023-06',['RAP_ethane','RAP_propane','exports','henry','SWV_heat','SPA_heat','SOH_heat']].to_string())
# These quarter-only operating tables are comparative. First monetary row precedes the derivative section.
cols={'Natural gas (Bcf)':'gas_bcf','C2 Ethane (MBbl)':'ethane_kbbl','C3+ NGLs (MBbl)':'c3plus_kbbl','Oil (MBbl)':'oil_kbbl','Natural gas (per Mcf)':'gas_usd_mcf','C2 Ethane (per Bbl)':'ethane_usd_bbl','C3+ NGLs (per Bbl)':'c3plus_usd_bbl','Oil (per Bbl)':'oil_usd_bbl'}
qrows=[]
for j,name in enumerate(['q1','q2','q3','q4']):
 tree=html.fromstring((R/name).read_bytes()); out=[{'quarter':f'{y}Q{j+1}','source':'A'+str(j+1)} for y in [2022,2023]]
 seen=set()
 for r in tree.xpath('//tr'):
  cells=[clean(c.text_content()) for c in r.xpath('./td|./th')];cells=[c for c in cells if c not in ('','$','%')]
  if not cells:continue
  for prefix,key in cols.items():
   if cells[0].startswith(prefix) and key not in seen and len(cells)>2:
    for i in range(2):out[i][key]=float(cells[i+1].replace(',',''))
    seen.add(key)
 assert set(cols.values())==seen
 for i,b in enumerate(out):
  b['adjusted_ethane_usd_bbl']=([16.74,22.42,23.40,17.22],[10.76,7.65,10.88,8.78])[i][j]
  b['payment_musd']=([None,None,None,10],[6,1,6,2])[i][j]
  b['mb_ethane_usd_gal']=([.40,.59,.55,.39],[.25,.21,.30,.23])[i][j]
 qrows+=out
pd.DataFrame(qrows).sort_values('quarter').to_csv(K/'case_quarters.csv',index=False)
