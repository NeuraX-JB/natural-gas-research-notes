from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
from pathlib import Path
from lxml import html
u={
'usgs':'https://pubs.usgs.gov/of/2014/1207/',
'q1':'https://www.anteroresources.com/investors/press-releases/detail/227/antero-resources-announces-first-quarter-2023-financial-and',
'q2':'https://www.anteroresources.com/news-events/press-releases/detail/229/antero-resources-announces-second-quarter-2023-financial',
'q3':'https://www.anteroresources.com/news-events/press-releases/detail/231/antero-resources-announces-third-quarter-2023-financial-and',
'q4':'https://www.anteroresources.com/investors/press-releases/detail/233/antero-resources-announces-fourth-quarter-2023-results',
'q422':'https://www.anteroresources.com/news-events/press-releases/detail/225/antero-resources-announces-fourth-quarter-2022-results',
'q322':'https://www.anteroresources.com/investors/press-releases/detail/223/antero-resources-reports-third-quarter-2022-results-and',
'sec':'https://data.sec.gov/submissions/CIK0001433270.json',
'west':'https://www.eia.gov/dnav/ng/hist/n3010wv3m.htm',
'plant':'https://www.eia.gov/dnav/pet/pet_pnp_gp_a_epllea_fpf_mbbl_m.htm',
'export':'https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?f=M&n=PET&s=M_EPLLEA_EEX_R10-Z00_1',
'usgsdoc':'https://pubs.usgs.gov/of/2014/1207/pdf/ofr2014-1207.pdf',
}
def get(p):
 k,url=p
 try:
  d=urlopen(Request(url,headers={'User-Agent':'FieldResearch/1.2 data desk contact gasresearch@example.com'}),timeout=22).read()
  Path('raw',k).write_bytes(d)
  if d.lstrip().startswith(b'<'):
   tree=html.fromstring(d)
   if k in ['usgs','plant','export']:print(k,[(t.text_content().strip()[:65],t.get('href')) for t in tree.xpath('//a[@href]') if any(w in t.get('href','').lower() for w in ['.xls','leafhandler','hist/','table1'])][:22])
  print(k,len(d))
 except Exception as e:print(k,str(e))
if __name__=='__main__':
 list(ThreadPoolExecutor(6).map(get,u.items()))
