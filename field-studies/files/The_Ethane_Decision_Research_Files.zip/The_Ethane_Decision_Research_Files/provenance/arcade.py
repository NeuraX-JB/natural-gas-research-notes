import json,urllib.request,urllib.parse,time,concurrent.futures
from pathlib import Path
base=json.loads(Path('raw/arc_meta').read_text())['url']+'/0/query?'
def fetch(**k):
 u=base+urllib.parse.urlencode(dict(f='json',**k))
 for i in range(3):
  try:
   d=json.load(urllib.request.urlopen(u,timeout=35));assert 'error' not in d,d;return d
  except Exception:
   if i==2:raise
   time.sleep(1)
def main():
 d=fetch(where='1=1',returnDistinctValues='true',outFields='STATE',returnGeometry='false');print([k['attributes']['STATE'] for k in d['features']])
 states=[k['attributes']['STATE'] for k in d['features'] if str(k['attributes']['STATE']).strip().upper() in ('OH','WV','PA','OHIO','PENNSYLVANIA','WEST VIRGINIA','KENTUCKY','NEW YORK','KY','NY')]
 where="STATE IN ("+','.join("'"+x+"'" for x in states)+')'
 ids=sorted(fetch(where=where,returnIdsOnly='true')['objectIds'])
 print('records',len(ids),flush=True)
 fields='OBJECTID,ID,STATE,COUNTY,FIELD,FORMATION,AGE,SOURCE,C1,C2,C3,N_C4,I_C4,N_C5,I_C5,C6_Plus,BTU,N2,CO2,FINAL_SAMPLING_DATE,PUBLICATION_DATE'
 def chunk(i):
  ds=fetch(where=where+' AND OBJECTID >= '+str(ids[i])+' AND OBJECTID <= '+str(ids[min(i+499,len(ids)-1)]),returnGeometry='false',outFields=fields,orderByFields='OBJECTID');return [z['attributes'] for z in ds['features']]
 with concurrent.futures.ThreadPoolExecutor(5) as pool: rows=sum(list(pool.map(chunk,range(0,len(ids),500))),[])
 assert len(rows)==len(ids)
 Path('raw/geo.json').write_text(json.dumps(rows));print(len(rows),rows[:1])
if __name__=='__main__':main()
