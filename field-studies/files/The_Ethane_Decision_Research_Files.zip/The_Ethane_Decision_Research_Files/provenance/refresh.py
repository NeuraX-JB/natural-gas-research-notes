"""Optional online rebuild of the *inputs*. Run from a fresh directory; see README."""
from pathlib import Path
from shutil import copy2
import json
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
from get_start import u
from arcade import main as get_geo
import runpy
here=Path(__file__).resolve().parent
root=here.parent
def main():
    raw=Path('raw');raw.mkdir(exist_ok=True);Path('kit').mkdir(exist_ok=True)
    refs={}
    for line in (root/'sources.tsv').read_text().splitlines():
        k,label,url=line.split('\t',2);refs[k]=url
    pages={key:u[key] for key in ('q1','q2','q3','q4')}
    pages.update({'mdpi':'https://www.mdpi.com/2075-163X/12/10/1222','arc_meta':'https://www.arcgis.com/sharing/rest/content/items/245d22ce1c2a461da042da6c4a40672a?f=json'})
    def get(item):
        key,url=item;req=Request(url,headers={'User-Agent':'gasTerminal Research historical data replication'})
        blob=urlopen(req,timeout=60).read()
        (raw/key).write_bytes(blob)
    with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(get,pages.items()))
    get_geo()
    for name in ('ethane','propane','exports','henry','heat'):
        copy2(root/'raw_eia'/(name+'.xls'),raw/(name+'.xls'))
    copy2(here/'more_urls.json',Path('more_urls.json'))
    runpy.run_path(str(here/'prepare.py'),run_name='__main__')
if __name__=='__main__':main()
