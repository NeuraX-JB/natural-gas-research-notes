"""Rebuild every quantitative result in Book 4 locally from the included inputs."""
from pathlib import Path
import argparse
import sys
import pandas as pd
from study import ROOT,case,write
from blends import evaluate as blend_bounds
from counterexample import run as alternative_feeds
from heat_test import evaluate as held_out
from sensitivity import tolerances,season
from figures import make as figures
def run(out):
    write(out)
    panels={'blend_bounds':blend_bounds(),'alternative_feeds':alternative_feeds(),'county_holdouts':held_out(),'throughput_tolerances':tolerances(),'seasonal_controls':season()}
    for name,df in panels.items():df.to_csv(out/(name+'.csv'),index=False)
    c=case();p=c.loc['2023Q2'];rates=pd.read_csv(ROOT/'tariff_observations.csv')
    rate=rates.loc[rates.series.eq('ordinary 20000 and above') & rates.effective_date.eq('2022-07-01'),'usd_per_bbl'].item()
    checks=[]
    for cost in [0.,.5,1.,2.]:
        for share in [0.,.25,.5,.75,1.]:
            liquid=p.mb_gross_usd_bbl-rate*share-cost
            checks.append((p.mb_gross_usd_bbl,rate,share,cost,p.gas_reference_usd_bbl,liquid,liquid-p.gas_reference_usd_bbl))
    pd.DataFrame(checks,columns='mb_usd_bbl posted_freight assumed_avoidable_share assumed_plant_cost gas_value liquid_after_cost net_advantage'.split()).to_csv(out/'atex_2023Q2.csv',index=False)
    a=c.loc['2023Q2'];b=c.loc['2022Q2']
    details={'delta_kbbl':a.ethane_kbbl-b.ethane_kbbl,'delta_bpd':(a.company_kbd-b.company_kbd)*1000,'delta_c3_kbbl':a.c3plus_kbbl-b.c3plus_kbbl,'held_c3_residual_kbbl':a.ethane_kbbl-a.c3plus_kbbl*b.c2_per_c3plus,'all_switch_heat_million_mmbtu':(a.ethane_kbbl-b.ethane_kbbl)*2.783/1000,'all_switch_gas_bcf':(a.ethane_kbbl-b.ethane_kbbl)*1.558/1000,'rank_corr_volume_realization_headroom':c.company_kbd.corr(c.headroom_usd_bbl,method='spearman'),'rank_corr_volume_hub_headroom':c.company_kbd.corr(c.hub_headroom_usd_bbl,method='spearman')}
    pd.Series(details,name='value').to_csv(out/'spring_bridge.csv')
    figures(out/'figures')
    assert round(a.implied_payment_musd,3)==1.090
    assert sum(panels['alternative_feeds'].query("population=='wet and dry' and total_inlet=='free'").feasible)==26
    assert len(panels['county_holdouts'])==896 and len(panels['blend_bounds'])==93
    print('Verified the price reconciliation, blend results and held-out assay count.')
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,default=ROOT/'results');run(parser.parse_args().out)
