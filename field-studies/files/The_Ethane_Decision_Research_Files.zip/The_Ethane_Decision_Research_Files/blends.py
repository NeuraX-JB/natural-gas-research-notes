"""Constant-feed counterexamples. Mixture weights are shares of equal standard inlet volume."""
from itertools import combinations
from pathlib import Path
import pandas as pd, numpy as np
from scipy.optimize import linprog
from study import ROOT,lab
def blend_data():
    a,_=lab(); w=a.query("group == 'WG'").copy()
    # Standard gaseous volume per liquid barrel, EIA processing notes. C5+ is treated as natural gasoline.
    w['heavy_yield']=(w.C3/1.498+w.iC4/1.247+w.nC4/1.289+(w.iC5+w.nC5+w.C6plus)/1.050)
    w=w.dropna(subset=['heavy_yield','C1','C2','C3']).set_index('sample'); return w
def evaluate():
    w=blend_data(); out=[]
    for name,rec in w.iterrows():
        for label,conds in [('propane',['C3']),('heavy',['heavy_yield']),('heavy_and_methane',['heavy_yield','C1'])]:
            eq=np.vstack([np.ones(len(w)),*[w[c] for c in conds]])
            rhs=np.r_[1.,[rec[c] for c in conds]]
            low=linprog(w.C2,A_eq=eq,b_eq=rhs,method='highs');hi=linprog(-w.C2,A_eq=eq,b_eq=rhs,method='highs');assert low.success and hi.success
            def fmt(arr):return ' + '.join(f'{val:.5f} {ix}' for ix,val in zip(w.index,arr) if val>1e-7)
            out.append((name,label,rec.C3,rec.heavy_yield,rec.C1,low.fun,-hi.fun,(-hi.fun)/low.fun,fmt(low.x),fmt(hi.x)))
    return pd.DataFrame(out,columns='anchor held propane_mol heavy_bbl_per_100mcf methane_mol low_c2 high_c2 factor low_blend high_blend'.split())
if __name__=='__main__':
    out=ROOT/'results';out.mkdir(exist_ok=True);r=evaluate();r.to_csv(out/'blend_bounds.csv',index=False)
    print(r.groupby('held').factor.agg(['size','min','median','max']))
    print(r.nlargest(2,'factor').to_string(index=False))
