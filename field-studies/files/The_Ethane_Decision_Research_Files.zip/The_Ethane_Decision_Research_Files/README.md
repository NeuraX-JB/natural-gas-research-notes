# The Ethane Decision
## Book 4 research files

Start with `results/spring_bridge.csv` and `results/atex_2023Q2.csv` for the central case. All input snapshots are included. An internet connection is unnecessary for running the analysis once the four Python dependencies are available.

### Reproduce the results

Unzip the whole folder, navigate into it in a terminal and run the following commands with Python 3.10 or later.

```sh
python -m pip install -r requirements.txt
python run.py --out reproduced
```

Compare the CSV files in `reproduced` with the delivered `results` directory. Different mathematical library versions can choose a different set of mixture weights when several blends share one optimal value. The maximum and minimum values are the quantities of interest. To regenerate the reference-case prose, run `python county_profiles.py .`, `python quarters.py .`, or `python blend_profiles.py .` in a working copy. Each writes Markdown files for its own sections.

### Data and units

| File | Contents and conventions |
|---|---|
| case_quarters.csv | Eight comparative quarters from Antero releases and financial filings. Ethane, C3+ and oil in thousand barrels. Gas in Bcf. Product prices in USD per named unit before derivatives. Supplemental ethane price removes the published take-or-pay proceeds where separately identified. Unspecified proceeds remain empty. |
| monthly.csv | EIA monthly observations from January 2012 through December 2025, drawn from the listed historical series; early years provide comparison baselines. Ethane, propane and East Coast exports are thousand barrels per month. Henry Hub is USD/MMBtu. State heat is Btu/cf at consumer delivery. The producer and region do not have the same boundary. Missing cells stay missing. |
| five_state_assays.csv | All 1,214 USGS ArcGIS records labeled Kentucky, New York, Ohio, Pennsylvania, or West Virginia. Fields follow the service, with composition in percent and archive record ID for traceability. Raw service dates, where populated, are UTC epoch milliseconds. PUBLICATION_DATE is a year. The analysis uses the suggested screen in study.py; the CSV retains excluded rows. |
| marcellus_assays.csv | Table 1 of Laughrey (2022), DOI 10.3390/min12101222. Values retain published rounding, original labels and textual indicators. The two printed lines of the WG10/WG11 row are separate observations. WV28 is retained as printed and assigned to the wet group. Repeat samples do not identify independent wells. Article distributed under CC BY 4.0. Numeric transcription and analysis by gasTerminal Research. |
| tariff_observations.csv | Two public ordinary contract-tier rates from Item 300, linked in sources.tsv. Contract applicability and avoidable freight are assumptions, not a reported Antero invoice. |
| sources.tsv | Source ID, title and original public URL. A identifies corporate, operating, regulatory and tariff records, E identifies statistical definitions and series, and G identifies geological records. |
| snapshot_manifest.csv | SHA-256 digests of the delivered input snapshots. Collection and compilation date is 2026-11-24. |

### Regional codes

RAP is EIA refining district Appalachian No. 1. Ohio is excluded. R10, R20, R30, R40 and R50 are PADD 1 through 5. NUS is the whole United States. Other R-series codes are individual refining districts; authoritative labels and source keys are in series_dictionary.csv. SWV, SPA, SOH, STX and NUS heat series are delivered-to-consumer measures. Combining producer, district, state and export records into a single material balance would require additional evidence.

### Results map

- `case_results.csv` aligns company prices and volumes with regional evidence. Headroom is the pre-incremental-cost spread at an illustrative 1.05 MMBtu/Mcf. The historical transport range columns use the 2017 meeting presentation as a scenario.
- `netback_scenarios.csv` varies gas heat and net incremental route costs for each company quarter. `atex_2023Q2.csv` uses the contemporary posted carrier tariff and varies its assumed avoidable share.
- `spring_bridge.csv` contains the volume and heat calculations and the descriptive eight-quarter correlations. `regional_quarters.csv` and `seasonal_controls.csv` preserve the dates and daily-rate adjustments.
- `all_wet_pairs.csv` compares all 465 pairs of wet Marcellus samples. `blend_bounds.csv` matches propane, modeled heavier yield or heavier yield and methane at fixed volume.
- `alternative_feeds.csv` varies the inlet-volume assumption and availability of dry samples. Weights are inlet quantities per common reference volume. `throughput_tolerances.csv` places upper and lower bounds on each period's inlet volume.
- `historical_counties.csv` contains the screened county summaries. `county_holdouts.csv` preserves all 896 held-out predictions, including the largest misses. County profiles in the book require five qualifying records; the prediction contest includes smaller named counties.
- `figures/` contains the five charts in the book.

### Source selection and historical use

The Q2 2023 earnings release says $6 million of contract proceeds. Its 10-Q states $1 million; the six-month rolled amount and a price times volume check support the filing. The adjusted price of $7.65/bbl appears in both. The Q2 realization and reported volumes are published values. Historical product-price observations for Mont Belvieu, including Q4 2023 at $0.23/gal, are the rounded quarterly values in Range Resources Table 9. The fully charged $8.0114 scenario is distinct from Antero's average realized price. Gas route costs and the physical recovery charge are not separately published for the marginal barrel.

Data are historical snapshots assembled after the events, not point-in-time inputs for a trading test. The regional experiment ends with the last calendar year selected for this study, 2025. No claim of plant-day attribution is made. Original EIA workbooks used to compile the panel are supplied in raw_eia. The optional provenance scripts and their README document the construction of the input snapshots.
